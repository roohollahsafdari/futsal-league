/* ورود کاربران، مدیریت حساب‌ها و ثبت فعالیت‌ها */
(function () {
  'use strict';
  const KEY = 'futsal_auth_v1';
  const ADMIN = {
    id: 'admin', username: 'rohollahsafdary@gmail.com', name: 'روح‌الله صفدری', role: 'admin', active: true,
    salt: 'fl-a4a95df7caa387fa', hash: 'f5528dcf0c877353ea73820bd4c3466d71b326eaa5b35ed9978a967c00eb09bd', createdAt: 0
  };
  const MAX_LOG = 3000;

  /* SHA-256 (بدون وابستگی؛ روی همه مرورگرها و WebViewها کار می‌کند) */
  const sha256 = (function () {
    const primes = [];
    for (let n = 2; primes.length < 64; n++) if (primes.every((p) => n % p)) primes.push(n);
    const frac = (x) => Math.floor((x - Math.floor(x)) * 4294967296);
    const K = primes.map((p) => frac(Math.cbrt(p)));
    const H0 = primes.slice(0, 8).map((p) => frac(Math.sqrt(p)));
    const rr = (x, n) => (x >>> n) | (x << (32 - n));
    return function (str) {
      const b = Array.from(new TextEncoder().encode(str));
      const bits = b.length * 8;
      b.push(0x80);
      while (b.length % 64 !== 56) b.push(0);
      const hi = Math.floor(bits / 4294967296), lo = bits >>> 0;
      [hi, lo].forEach((w) => { for (let s = 24; s >= 0; s -= 8) b.push((w >>> s) & 255); });
      const H = H0.slice();
      for (let i = 0; i < b.length; i += 64) {
        const w = new Array(64);
        for (let t = 0; t < 16; t++) w[t] = (b[i + 4 * t] << 24) | (b[i + 4 * t + 1] << 16) | (b[i + 4 * t + 2] << 8) | b[i + 4 * t + 3];
        for (let t = 16; t < 64; t++) {
          const s0 = rr(w[t - 15], 7) ^ rr(w[t - 15], 18) ^ (w[t - 15] >>> 3);
          const s1 = rr(w[t - 2], 17) ^ rr(w[t - 2], 19) ^ (w[t - 2] >>> 10);
          w[t] = (w[t - 16] + s0 + w[t - 7] + s1) | 0;
        }
        let [a, bb, c, d, e, f, g, h] = H;
        for (let t = 0; t < 64; t++) {
          const S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25), ch = (e & f) ^ (~e & g);
          const t1 = (h + S1 + ch + K[t] + w[t]) | 0;
          const S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22), mj = (a & bb) ^ (a & c) ^ (bb & c);
          const t2 = (S0 + mj) | 0;
          h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = bb; bb = a; a = (t1 + t2) | 0;
        }
        [a, bb, c, d, e, f, g, h].forEach((v, k) => { H[k] = (H[k] + v) | 0; });
      }
      return H.map((v) => (v >>> 0).toString(16).padStart(8, '0')).join('');
    };
  })();

  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  const hashPw = (salt, pw) => sha256(salt + ':' + pw);
  const norm = (u) => String(u || '').trim().toLowerCase();

  let st = load();
  function load() {
    let s = null;
    try { s = JSON.parse(localStorage.getItem(KEY)); } catch (e) { /* خالی */ }
    if (!s || !Array.isArray(s.users)) s = { users: [], activity: [], session: null, fails: {} };
    if (!s.users.some((u) => u.id === 'admin')) s.users.unshift(Object.assign({}, ADMIN));
    if (!Array.isArray(s.activity)) s.activity = [];
    if (!s.fails) s.fails = {};
    return s;
  }
  function save() {
    if (st.activity.length > MAX_LOG) st.activity = st.activity.slice(-MAX_LOG);
    try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) { /* خالی */ }
  }

  const A = {};
  A.sha256 = sha256;
  A.current = () => {
    const u = st.users.find((x) => x.id === st.session);
    return u && u.active ? u : null;
  };
  A.isAdmin = () => { const u = A.current(); return !!u && u.role === 'admin'; };
  A.users = () => st.users.slice();
  A.log = (action, entity, text, extra) => {
    const u = A.current();
    st.activity.push(Object.assign({ id: uid(), ts: Date.now(), uid: u ? u.id : null, username: u ? u.username : (extra && extra.username) || '', name: u ? u.name : '', action, entity: entity || '', text }, extra || {}));
    save();
  };
  A.activity = () => st.activity.slice().reverse();

  A.login = (username, password) => {
    const key = norm(username);
    if (!key || !password) return { ok: false, error: 'نام کاربری و رمز عبور را وارد کن' };
    const f = st.fails[key] || { n: 0, until: 0 };
    if (f.until > Date.now()) return { ok: false, error: 'تلاش‌های ناموفق زیاد بود. ' + Math.ceil((f.until - Date.now()) / 1000) + ' ثانیه صبر کن' };
    const u = st.users.find((x) => norm(x.username) === key);
    if (!u || hashPw(u.salt, password) !== u.hash) {
      f.n += 1;
      if (f.n >= 5) { f.until = Date.now() + 30000; f.n = 0; }
      st.fails[key] = f;
      A.log('fail', 'auth', 'تلاش ناموفق برای ورود با «' + String(username).trim().slice(0, 60) + '»', { username: String(username).trim().slice(0, 60) });
      return { ok: false, error: 'نام کاربری یا رمز عبور درست نیست' };
    }
    if (!u.active) return { ok: false, error: 'این حساب غیرفعال شده است' };
    delete st.fails[key];
    st.session = u.id;
    save();
    A.log('login', 'auth', 'وارد برنامه شد');
    return { ok: true, user: u };
  };
  A.logout = () => {
    if (A.current()) A.log('logout', 'auth', 'از برنامه خارج شد');
    st.session = null; save();
  };

  A.addUser = (o) => {
    if (!A.isAdmin()) return { ok: false, error: 'فقط مدیر اصلی می‌تواند کاربر بسازد' };
    const username = String(o.username || '').trim();
    if (username.length < 3) return { ok: false, error: 'نام کاربری حداقل ۳ حرف باشد' };
    if (/\s/.test(username)) return { ok: false, error: 'نام کاربری نباید فاصله داشته باشد' };
    if (st.users.some((x) => norm(x.username) === norm(username))) return { ok: false, error: 'این نام کاربری قبلاً ثبت شده' };
    if (String(o.password || '').length < 6) return { ok: false, error: 'رمز عبور حداقل ۶ کاراکتر باشد' };
    const salt = 'fl-' + uid();
    const u = { id: uid(), username, name: String(o.name || '').trim() || username, role: 'user', active: true, salt, hash: hashPw(salt, o.password), createdAt: Date.now() };
    st.users.push(u); save();
    A.log('create', 'user', 'کاربر «' + u.name + '» (' + u.username + ') را ساخت');
    return { ok: true, user: u };
  };
  A.setActive = (id, on) => {
    const u = st.users.find((x) => x.id === id);
    if (!A.isAdmin() || !u || u.id === 'admin') return false;
    u.active = !!on; save();
    A.log('edit', 'user', 'حساب «' + u.name + '» را ' + (on ? 'فعال' : 'غیرفعال') + ' کرد');
    return true;
  };
  A.removeUser = (id) => {
    const u = st.users.find((x) => x.id === id);
    if (!A.isAdmin() || !u || u.id === 'admin') return false;
    st.users = st.users.filter((x) => x.id !== id); save();
    A.log('delete', 'user', 'حساب «' + u.name + '» (' + u.username + ') را حذف کرد');
    return true;
  };
  A.resetPassword = (id, pw) => {
    const u = st.users.find((x) => x.id === id);
    if (!A.isAdmin() || !u) return { ok: false, error: 'اجازه این کار را نداری' };
    if (String(pw || '').length < 6) return { ok: false, error: 'رمز عبور حداقل ۶ کاراکتر باشد' };
    u.salt = 'fl-' + uid(); u.hash = hashPw(u.salt, pw); save();
    A.log('edit', 'user', 'رمز عبور «' + u.name + '» را تغییر داد');
    return { ok: true };
  };
  A.changeOwnPassword = (oldPw, newPw) => {
    const u = A.current();
    if (!u) return { ok: false, error: 'وارد نشده‌ای' };
    if (hashPw(u.salt, oldPw) !== u.hash) return { ok: false, error: 'رمز فعلی درست نیست' };
    if (String(newPw || '').length < 6) return { ok: false, error: 'رمز جدید حداقل ۶ کاراکتر باشد' };
    u.salt = 'fl-' + uid(); u.hash = hashPw(u.salt, newPw); save();
    A.log('edit', 'user', 'رمز عبور خودش را تغییر داد');
    return { ok: true };
  };
  A.rename = (name) => {
    const u = A.current();
    if (u && name) { u.name = String(name).trim().slice(0, 40); save(); }
  };

  window.Auth = A;
})();
