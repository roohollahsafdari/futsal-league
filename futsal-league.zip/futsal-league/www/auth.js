/* ارتباط با سرور: ورود، نشست، مرا به خاطر بسپار، ورود آفلاین مدیر اصلی */
(function () {
  'use strict';
  const TK = 'futsal_token_v2', MK = 'futsal_me_v2', XK = 'futsal_login_meta', OK = 'futsal_owner_cred', OM = 'futsal_owner_me';
  const OFFLINE = 'OFFLINE';
  const SEED = { u: 'roohollahsafdari@gmail.com', salt: 'fl-owner-1', hash: 'd2148fbce789136fea53df8ace9959d6ae673138b5c1b0a000275135f85e419f' };
  const DAY = 86400000;

  /* SHA-256 بدون وابستگی (برای تایید محلی رمز مدیر اصلی) */
  const sha256 = (function () {
    const primes = [];
    for (let n = 2; primes.length < 64; n++) if (primes.every((p) => n % p)) primes.push(n);
    const frac = (x) => Math.floor((x - Math.floor(x)) * 4294967296);
    const K = primes.map((p) => frac(Math.cbrt(p)));
    const H0 = primes.slice(0, 8).map((p) => frac(Math.sqrt(p)));
    const rr = (x, n) => (x >>> n) | (x << (32 - n));
    return function (str) {
      const b = Array.from(new TextEncoder().encode(str));
      const bits = b.length * 8;
      b.push(0x80);
      while (b.length % 64 !== 56) b.push(0);
      [Math.floor(bits / 4294967296), bits >>> 0].forEach((w) => { for (let s = 24; s >= 0; s -= 8) b.push((w >>> s) & 255); });
      const H = H0.slice();
      for (let i = 0; i < b.length; i += 64) {
        const w = new Array(64);
        for (let t = 0; t < 16; t++) w[t] = (b[i + 4 * t] << 24) | (b[i + 4 * t + 1] << 16) | (b[i + 4 * t + 2] << 8) | b[i + 4 * t + 3];
        for (let t = 16; t < 64; t++) {
          const s0 = rr(w[t - 15], 7) ^ rr(w[t - 15], 18) ^ (w[t - 15] >>> 3), s1 = rr(w[t - 2], 17) ^ rr(w[t - 2], 19) ^ (w[t - 2] >>> 10);
          w[t] = (w[t - 16] + s0 + w[t - 7] + s1) | 0;
        }
        let [a, bb, c, d, e, f, g, h] = H;
        for (let t = 0; t < 64; t++) {
          const S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25), ch = (e & f) ^ (~e & g), t1 = (h + S1 + ch + K[t] + w[t]) | 0;
          const S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22), mj = (a & bb) ^ (a & c) ^ (bb & c), t2 = (S0 + mj) | 0;
          h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = bb; bb = a; a = (t1 + t2) | 0;
        }
        [a, bb, c, d, e, f, g, h].forEach((v, k) => { H[k] = (H[k] + v) | 0; });
      }
      return H.map((v) => (v >>> 0).toString(16).padStart(8, '0')).join('');
    };
  })();

  const jget = (k) => { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } };
  let token = localStorage.getItem(TK) || '';
  let me = jget(MK);
  let meta = jget(XK) || { at: Date.now(), remember: true, offline: false };
  if (!token) me = null;
  let lastId = me ? me.id : 0;
  let expiredFlag = false;
  const A = { onExpire: null };

  const persist = () => {
    try {
      if (token && me) { localStorage.setItem(TK, token); localStorage.setItem(MK, JSON.stringify(me)); localStorage.setItem(XK, JSON.stringify(meta)); }
      else { localStorage.removeItem(TK); localStorage.removeItem(MK); localStorage.removeItem(XK); }
    } catch (e) { /* خالی */ }
  };
  const expired = () => !!me && Date.now() - (meta.at || 0) > (meta.remember ? 90 * DAY : DAY);

  async function post(body, ms) {
    const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const tm = ctl ? setTimeout(() => ctl.abort(), ms || 15000) : 0;
    try {
      // text/plain یعنی درخواست ساده و بدون preflight (سازگار با هاست‌های اشتراکی)
      const r = await fetch(window.APP_API, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=UTF-8' }, body: JSON.stringify(body), signal: ctl ? ctl.signal : undefined });
      return await r.json();
    } catch (e) { const err = new Error('network'); err.network = true; throw err; } finally { if (tm) clearTimeout(tm); }
  }

  A.api = async (a, payload) => {
    if (token === OFFLINE) {
      const u = await A.upgrade();
      if (u !== 'ok') { const err = new Error('network'); err.network = true; err.upgrade = u; throw err; }
    }
    const j = await post(Object.assign({}, payload || {}, { a, token }));
    if (j && j.code === 'auth') {
      const reason = j.reason || 'invalid';
      lastId = me ? me.id : lastId;
      A.clear();
      if (A.onExpire) A.onExpire(reason);
      const err = new Error('auth'); err.auth = true; throw err;
    }
    return j;
  };
  A.clear = () => { token = ''; me = null; persist(); };
  A.lastId = () => lastId;
  A.current = () => {
    if (!(token && me)) return null;
    if (expired()) {
      lastId = me.id; A.clear(); expiredFlag = true;
      if (A.onExpire) setTimeout(() => A.onExpire('expired'), 0);
      return null;
    }
    return me;
  };
  A.takeExpired = () => { const x = expiredFlag; expiredFlag = false; return x; };
  A.setMe = (m) => { me = m; persist(); };
  // بعد از تغییر نام کاربری یا رمز، ورود آفلاین مدیر اصلی هم با اطلاعات جدید کار کند
  A.setOwnerCred = (u, p, m) => {
    try {
      const salt = 'fl-' + Math.random().toString(36).slice(2, 10);
      localStorage.setItem(OK, JSON.stringify({ u, salt, hash: sha256(salt + ':' + p) }));
      localStorage.setItem(OM, JSON.stringify(m || me));
      if (token === OFFLINE) sessionStorage.setItem('fl_pw', p);
    } catch (x) { /* خالی */ }
  };
  A.isAdmin = () => !!me && me.role === 'admin';
  A.isOfflineSession = () => !!me && token === OFFLINE;
  A.can = (p) => !!me && (me.role === 'admin' || (me.perms || []).indexOf(p) >= 0);

  const ownerCred = () => jget(OK) || SEED;
  const norm = (u) => String(u || '').trim().toLowerCase();

  A.login = async (u, p, remember) => {
    if (!String(u || '').trim() || !p) return { ok: false, error: 'نام کاربری و رمز عبور را وارد کن' };
    let j;
    try { j = await post({ a: 'login', u: String(u).trim(), p, remember: !!remember }); }
    catch (e) {
      // بدون اینترنت: فقط مدیر اصلی با نام کاربری و رمز خودش وارد می‌شود
      const oc = ownerCred();
      if (norm(u) === norm(oc.u) && sha256(oc.salt + ':' + p) === oc.hash) {
        me = jget(OM) || { id: 1, username: oc.u, first_name: 'روح‌الله', last_name: 'صفدری', phone: '', email: '', role_title: 'مدیر اصلی', role: 'admin', perms: [], require_approval: false, active: true };
        token = OFFLINE; lastId = me.id;
        meta = { at: Date.now(), remember: !!remember, offline: true };
        try { sessionStorage.setItem('fl_pw', p); } catch (x) { /* خالی */ }
        persist();
        return { ok: true, offline: true };
      }
      return { ok: false, error: 'برای اولین ورود باید به اینترنت وصل باشی. ارتباط با سرور برقرار نشد.' };
    }
    if (j && j.ok) {
      token = j.token; me = j.me; lastId = me.id;
      meta = { at: Date.now(), remember: !!remember, offline: false };
      persist();
      if (me.role === 'admin') {
        try {
          const salt = 'fl-' + Math.random().toString(36).slice(2, 10);
          localStorage.setItem(OK, JSON.stringify({ u: me.username, salt, hash: sha256(salt + ':' + p) }));
          localStorage.setItem(OM, JSON.stringify(me));
        } catch (x) { /* خالی */ }
      }
    }
    return j || { ok: false, error: 'پاسخ سرور معتبر نیست' };
  };

  // تبدیل ورود آفلاین مدیر به نشست واقعی سرور: 'ok' | 'net' | 'need' (رمز لازم است) | 'bad'
  A.upgradeWith = async (pw) => {
    if (token !== OFFLINE || !me) return 'ok';
    let j;
    try { j = await post({ a: 'login', u: me.username, p: pw, remember: !!meta.remember }); } catch (e) { return 'net'; }
    if (!j || !j.ok) return 'bad';
    token = j.token; me = j.me; meta = { at: meta.at, remember: !!meta.remember, offline: false };
    persist();
    try { sessionStorage.removeItem('fl_pw'); localStorage.setItem(OM, JSON.stringify(me)); } catch (x) { /* خالی */ }
    return 'ok';
  };
  A.upgrade = async () => {
    let pw = '';
    try { pw = sessionStorage.getItem('fl_pw') || ''; } catch (e) { /* خالی */ }
    if (!pw) return 'need';
    const r = await A.upgradeWith(pw);
    if (r === 'bad') { try { sessionStorage.removeItem('fl_pw'); } catch (e) { /* خالی */ } return 'need'; }
    return r;
  };

  A.logout = async () => {
    if (token && token !== OFFLINE) { try { await A.api('logout'); } catch (e) { /* خالی */ } }
    lastId = me ? me.id : lastId;
    try { sessionStorage.removeItem('fl_pw'); } catch (e) { /* خالی */ }
    A.clear();
  };
  window.Auth = A;
})();
