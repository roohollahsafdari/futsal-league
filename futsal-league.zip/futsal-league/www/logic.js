/* منطق برنامه: بدون وابستگی به صفحه (قابل تست در Node) */
(function (root) {
  'use strict';
  const L = {};

  L.uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  L.shuffle = (arr) => {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  };
  L.fa = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]);

  /* ---------- تاریخ شمسی (با Intl خود مرورگر) ---------- */
  const JM = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  L.JM = JM;
  const jf = new Intl.DateTimeFormat('en-US-u-ca-persian-nu-latn', { timeZone: 'UTC', year: 'numeric', month: 'numeric', day: 'numeric' });
  const wf = new Intl.DateTimeFormat('fa-IR', { timeZone: 'UTC', weekday: 'long' });
  const jParts = (date) => {
    const p = {};
    jf.formatToParts(date).forEach((x) => { p[x.type] = x.value; });
    return { y: Number(p.year || p.relatedYear), m: Number(p.month), d: Number(p.day) };
  };
  const isoToDate = (iso) => { const [y, m, d] = iso.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d)); };
  L.toJalali = (iso) => jParts(isoToDate(iso));
  L.fromJalali = (jy, jm, jd) => {
    const start = Date.UTC(jy + 621, 2, 1);
    for (let i = 0; i < 400; i++) {
      const dt = new Date(start + i * 864e5);
      const j = jParts(dt);
      if (j.y === jy && j.m === jm && j.d === jd) return dt.toISOString().slice(0, 10);
    }
    return null;
  };
  L.fmtDate = (iso) => {
    if (!iso) return '';
    const j = L.toJalali(iso);
    return L.fa(j.d) + ' ' + JM[j.m - 1] + ' ' + L.fa(j.y);
  };
  L.weekday = (iso) => wf.format(isoToDate(iso));
  L.fmtTime = (t) => (t ? L.fa(t) : '');
  L.dayInfo = (iso, time) => (iso ? L.weekday(iso) + ' ' + L.fmtDate(iso) + (time ? ' • ساعت ' + L.fmtTime(time) : '') : '');
  L.today = () => {
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  };

  /* ---------- ساخت بازی‌ها ---------- */
  L.newMatch = (o) => Object.assign({ id: L.uid(), played: false, hg: null, ag: null, hp: null, ap: null, date: null, time: null, bye: false }, o);

  L.roundRobin = (ids, double) => {
    const t = ids.slice();
    if (t.length % 2) t.push(null);
    const n = t.length;
    const rounds = [];
    for (let r = 0; r < n - 1; r++) {
      const games = [];
      for (let i = 0; i < n / 2; i++) {
        const a = t[i], b = t[n - 1 - i];
        if (a && b) games.push(r % 2 ? [b, a] : [a, b]);
      }
      rounds.push(games);
      t.splice(1, 0, t.pop());
    }
    if (double) return rounds.concat(rounds.map((g) => g.map(([a, b]) => [b, a])));
    return rounds;
  };

  L.genLeagueMatches = (lg) =>
    L.roundRobin(L.shuffle(lg.teamIds), lg.double).flatMap((games, r) =>
      games.map(([h, a]) => L.newMatch({ leagueId: lg.id, stage: 'league', round: r + 1, home: h, away: a })));

  L.emptyGroups = (lg) => {
    const groups = [];
    for (let i = 0; i < lg.groupCount; i++) groups.push({ id: 'g' + (i + 1), name: 'گروه ' + 'ABCDEFGH'[i], teamIds: [] });
    return groups;
  };
  L.drawGroups = (lg) => {
    const groups = L.emptyGroups(lg);
    L.shuffle(lg.teamIds).forEach((id, i) => groups[i % lg.groupCount].teamIds.push(id));
    return groups;
  };
  L.groupsFromAssignment = (lg, assign) => {
    const groups = L.emptyGroups(lg);
    lg.teamIds.forEach((id) => { if (groups[assign[id]]) groups[assign[id]].teamIds.push(id); });
    return groups;
  };
  L.validateGroups = (groups) => {
    for (const g of groups) if (g.teamIds.length < 2) return 'هر گروه حداقل ۲ تیم لازم دارد (' + g.name + ').';
    return null;
  };
  L.groupMatches = (lg, groups) => {
    const matches = [];
    groups.forEach((gr) => {
      L.roundRobin(gr.teamIds, lg.double).forEach((games, r) =>
        games.forEach(([h, a]) => matches.push(L.newMatch({ leagueId: lg.id, stage: 'group', groupId: gr.id, round: r + 1, home: h, away: a }))));
    });
    return matches;
  };
  L.genGroups = (lg) => { const groups = L.drawGroups(lg); return { groups, matches: L.groupMatches(lg, groups) }; };

  L.nextPow2 = (n) => { let s = 2; while (s < n) s *= 2; return s; };
  L.seedOrder = (S) => {
    let a = [1];
    while (a.length < S) { const n = a.length * 2; a = a.flatMap((x) => [x, n + 1 - x]); }
    return a;
  };
  L.roundName = (R, i) => {
    const rem = Math.pow(2, R - i);
    return rem === 2 ? 'فینال' : rem === 4 ? 'نیمه‌نهایی' : rem === 8 ? 'یک‌چهارم نهایی' : rem === 16 ? 'یک‌هشتم نهایی' : 'دور ' + L.fa(rem) + ' تیم';
  };

  L.koRounds = (ms) => {
    const ko = ms.filter((x) => x.stage === 'ko');
    return ko.length ? Math.max.apply(null, ko.map((x) => x.round)) + 1 : 0;
  };

  L.advance = (ms, m, w, l) => {
    if (m.stage !== 'ko') return;
    const R = L.koRounds(ms);
    const slot = m.pos % 2 === 0 ? 'home' : 'away';
    if (m.round < R - 1) {
      const nx = ms.find((x) => x.stage === 'ko' && x.round === m.round + 1 && x.pos === Math.floor(m.pos / 2));
      if (nx) nx[slot] = w;
    }
    if (m.round === R - 2) {
      const th = ms.find((x) => x.stage === 'third');
      if (th) th[slot] = l;
    }
  };

  L.dependents = (ms, m) => {
    if (m.stage !== 'ko') return [];
    const R = L.koRounds(ms);
    const out = [];
    const nx = ms.find((x) => x.stage === 'ko' && x.round === m.round + 1 && x.pos === Math.floor(m.pos / 2));
    if (nx) out.push(nx);
    if (m.round === R - 2) { const th = ms.find((x) => x.stage === 'third'); if (th) out.push(th); }
    return out;
  };

  L.fixClashes = (pairs, groupOf) => {
    const bad = (a, b) => a && b && groupOf[a] !== undefined && groupOf[a] === groupOf[b];
    for (let i = 0; i < pairs.length; i++) {
      if (!bad(pairs[i][0], pairs[i][1])) continue;
      for (let j = 0; j < pairs.length; j++) {
        if (j === i) continue;
        const b = pairs[i][1], c = pairs[j][1];
        if (!b || !c) continue;
        if (!bad(pairs[i][0], c) && !bad(pairs[j][0], b)) { pairs[i][1] = c; pairs[j][1] = b; break; }
      }
    }
    return pairs;
  };
  // seeds: تیم‌ها به ترتیب قدرت (قوی‌ترین اول). تعداد غیر توان ۲ = بای برای نفرات اول
  L.suggestPairs = (seeds, groupOf) => {
    const n = seeds.length, S = L.nextPow2(n);
    const padded = seeds.concat(Array(S - n).fill(null));
    const order = L.seedOrder(S);
    const pairs = [];
    for (let p = 0; p < S / 2; p++) pairs.push([padded[order[2 * p] - 1], padded[order[2 * p + 1] - 1]]);
    return groupOf ? L.fixClashes(pairs, groupOf) : pairs;
  };
  // pairs: [[تیم|null, تیم|null], ...] دور اول؛ null = بای
  L.validatePairs = (teamIds, pairs) => {
    const n = teamIds.length, S = L.nextPow2(n);
    if (pairs.length !== S / 2) return 'تعداد بازی‌های دور اول باید ' + L.fa(S / 2) + ' باشد.';
    const used = {};
    let dup = false;
    for (const [a, b] of pairs) {
      if (!a && !b) return 'هر بازی حداقل یک تیم لازم دارد.';
      if (a && b && a === b) return 'یک تیم نمی‌تواند با خودش بازی کند.';
      [a, b].forEach((x) => { if (x) { if (used[x] || teamIds.indexOf(x) < 0) dup = true; used[x] = 1; } });
    }
    if (dup) return 'هر تیم فقط یک بار می‌تواند در دور اول باشد.';
    if (Object.keys(used).length !== n) return 'همه تیم‌ها باید در جدول قرار بگیرند.';
    return null;
  };
  L.buildBracketPairs = (leagueId, pairs) => {
    const S = pairs.length * 2, R = Math.log2(S);
    const n = pairs.reduce((c, p) => c + (p[0] ? 1 : 0) + (p[1] ? 1 : 0), 0);
    const ms = [];
    for (let r = 0; r < R; r++) {
      for (let p = 0; p < S / Math.pow(2, r + 1); p++) {
        ms.push(L.newMatch({ leagueId, stage: 'ko', round: r, pos: p, roundName: L.roundName(R, r) }));
      }
    }
    ms.filter((m) => m.round === 0).forEach((m) => { m.home = pairs[m.pos][0] || null; m.away = pairs[m.pos][1] || null; });
    if (S >= 8 || n === 4) ms.push(L.newMatch({ leagueId, stage: 'third', round: R - 1, pos: 0, roundName: 'رده‌بندی (سوم و چهارم)' }));
    ms.filter((m) => m.stage === 'ko' && m.round === 0).forEach((m) => {
      if ((m.home && !m.away) || (!m.home && m.away)) {
        m.bye = true; m.played = true;
        L.advance(ms, m, m.home || m.away, null);
      }
    });
    return ms;
  };
  L.buildBracket = (leagueId, seeds, groupOf) => L.buildBracketPairs(leagueId, L.suggestPairs(seeds, groupOf));

  /* ---------- نتایج و جدول ---------- */
  L.outcome = (m) => {
    if (!m.played || m.bye) return null;
    if (m.hg > m.ag) return { w: m.home, l: m.away };
    if (m.hg < m.ag) return { w: m.away, l: m.home };
    if (m.hp != null && m.ap != null) return m.hp > m.ap ? { w: m.home, l: m.away } : { w: m.away, l: m.home };
    return { w: null, l: null };
  };

  L.standings = (teamIds, matches) => {
    const t = {};
    teamIds.forEach((id) => { t[id] = { teamId: id, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, gd: 0, pts: 0 }; });
    matches.forEach((m) => {
      if (!m.played || m.bye || !t[m.home] || !t[m.away]) return;
      const h = t[m.home], a = t[m.away];
      h.p++; a.p++;
      h.gf += m.hg; h.ga += m.ag; a.gf += m.ag; a.ga += m.hg;
      if (m.hg > m.ag) { h.w++; a.l++; h.pts += 3; }
      else if (m.hg < m.ag) { a.w++; h.l++; a.pts += 3; }
      else { h.d++; a.d++; h.pts++; a.pts++; }
    });
    const rows = Object.keys(t).map((k) => { t[k].gd = t[k].gf - t[k].ga; return t[k]; });
    rows.sort((x, y) => y.pts - x.pts || y.gd - x.gd || y.gf - x.gf);
    return rows;
  };

  L.podium = (db, lg) => {
    const ms = db.matches.filter((m) => m.leagueId === lg.id);
    const out = { champion: null, runnerUp: null, third: null, fourth: null };
    if (lg.format === 'league') {
      if (ms.length && ms.every((m) => m.played)) {
        const st = L.standings(lg.teamIds, ms).map((r) => r.teamId);
        out.champion = st[0] || null; out.runnerUp = st[1] || null; out.third = st[2] || null; out.fourth = st[3] || null;
      }
    } else {
      const R = L.koRounds(ms);
      const fin = ms.find((m) => m.stage === 'ko' && m.round === R - 1);
      if (fin && fin.played) { const o = L.outcome(fin); out.champion = o.w; out.runnerUp = o.l; }
      const th = ms.find((m) => m.stage === 'third');
      if (th && th.played) { const o = L.outcome(th); out.third = o.w; out.fourth = o.l; }
    }
    return out;
  };

  L.syncStatus = (db, lg) => {
    const p = L.podium(db, lg);
    if (p.champion && lg.status !== 'finished') { lg.status = 'finished'; lg.autoFinished = true; }
    else if (!p.champion && lg.autoFinished) { lg.status = 'running'; lg.autoFinished = false; }
    else if (lg.status === 'upcoming' && db.matches.some((m) => m.leagueId === lg.id && m.played && !m.bye)) lg.status = 'running';
  };

  // d: {hg, ag, hp, ap, date, events:[{teamId, playerId, type}], mvp}
  L.saveResult = (db, m, d) => {
    const lg = db.leagues.find((x) => x.id === m.leagueId);
    const ms = db.matches.filter((x) => x.leagueId === m.leagueId);
    const isKo = m.stage === 'ko' || m.stage === 'third';
    if (!m.home || !m.away) return 'تیم‌های این بازی هنوز مشخص نشده‌اند.';
    if (!(d.hg >= 0) || !(d.ag >= 0)) return 'گل هر دو تیم را وارد کن.';
    const ce = L.validateCards(d.events || []);
    if (ce) return ce;
    let hp = null, ap = null;
    if (isKo && d.hg === d.ag) {
      if (d.hp == null || d.ap == null || d.hp === d.ap) return 'در حذفی، نتیجه مساوی باید با پنالتی مشخص شود.';
      hp = d.hp; ap = d.ap;
    }
    const old = m.played ? L.outcome(m) : null;
    const nw = d.hg > d.ag ? { w: m.home, l: m.away } : d.hg < d.ag ? { w: m.away, l: m.home } : hp > ap ? { w: m.home, l: m.away } : { w: m.away, l: m.home };
    if (old && old.w !== nw.w && L.dependents(ms, m).some((x) => x.played)) return 'ابتدا نتیجه دور بعد را پاک کن.';
    m.hg = d.hg; m.ag = d.ag; m.hp = hp; m.ap = ap; m.played = true;
    if (d.date) m.date = d.date;
    if (d.time !== undefined) m.time = d.time || null;
    db.events = db.events.filter((e) => e.matchId !== m.id);
    (d.events || []).forEach((e) => db.events.push({ id: L.uid(), matchId: m.id, leagueId: m.leagueId, teamId: e.teamId, playerId: e.playerId || null, type: e.type }));
    db.awards = db.awards.filter((a) => !(a.matchId === m.id && a.type === 'mvp'));
    if (d.mvp) db.awards.push({ id: L.uid(), matchId: m.id, leagueId: m.leagueId, playerId: d.mvp, type: 'mvp' });
    if (isKo) L.advance(ms, m, nw.w, nw.l);
    L.syncStatus(db, lg);
    return null;
  };

  L.clearResult = (db, m) => {
    const ms = db.matches.filter((x) => x.leagueId === m.leagueId);
    const lg = db.leagues.find((x) => x.id === m.leagueId);
    if (m.bye) return 'این بازی بای است.';
    if (L.dependents(ms, m).some((x) => x.played)) return 'ابتدا نتیجه دور بعد را پاک کن.';
    if (m.stage === 'ko') L.advance(ms, m, null, null);
    m.played = false; m.hg = m.ag = m.hp = m.ap = null;
    db.events = db.events.filter((e) => e.matchId !== m.id);
    db.awards = db.awards.filter((a) => a.matchId !== m.id);
    L.syncStatus(db, lg);
    return null;
  };

  L.groupAdvance = (lg, g) => (g && g.advance != null ? g.advance : lg.advance);
  L.groupOfMap = (lg) => { const m = {}; (lg.groups || []).forEach((g) => g.teamIds.forEach((id) => { m[id] = g.id; })); return m; };
  // تیم‌های صعودکننده به ترتیب رتبه (اول‌ها، بعد دوم‌ها، ...) با تعداد صعود هر گروه
  L.qualified = (db, lg) => {
    const gm = db.matches.filter((m) => m.leagueId === lg.id && m.stage === 'group');
    const tables = lg.groups.map((g) => L.standings(g.teamIds, gm.filter((m) => m.groupId === g.id)));
    const max = Math.max.apply(null, [0].concat(lg.groups.map((g) => L.groupAdvance(lg, g))));
    const seeds = [];
    for (let r = 0; r < max; r++) tables.forEach((t, i) => { if (r < L.groupAdvance(lg, lg.groups[i]) && t[r]) seeds.push(t[r].teamId); });
    return seeds;
  };
  // pairs اختیاری: چیدمان دستی دور اول
  L.groupsToKo = (db, lg, pairs) => {
    const ms = db.matches.filter((m) => m.leagueId === lg.id);
    if (ms.some((m) => m.stage === 'ko')) return { error: 'مرحله حذفی قبلاً ساخته شده.' };
    const gm = ms.filter((m) => m.stage === 'group');
    if (!gm.length || !gm.every((m) => m.played)) return { error: 'بازی‌های گروهی هنوز تمام نشده.' };
    const seeds = L.qualified(db, lg);
    if (seeds.length < 2) return { error: 'تیم کافی برای مرحله حذفی نیست.' };
    if (pairs) {
      const e = L.validatePairs(seeds, pairs);
      return e ? { error: e } : { matches: L.buildBracketPairs(lg.id, pairs) };
    }
    return { matches: L.buildBracket(lg.id, seeds, L.groupOfMap(lg)) };
  };

  // ورود دستی بازی‌های یک هفته. pairs: [[میزبان, مهمان], ...]
  L.addWeek = (db, lg, round, date, pairs) => {
    if (!(round >= 1)) return 'شماره هفته معتبر نیست.';
    if (!pairs.length) return 'حداقل یک بازی وارد کن.';
    const stage = lg.format === 'groups' ? 'group' : 'league';
    const busy = {};
    db.matches.filter((m) => m.leagueId === lg.id && m.stage === stage && m.round === round).forEach((m) => { busy[m.home] = 1; busy[m.away] = 1; });
    const out = [];
    for (const [h, a, t] of pairs) {
      if (!h || !a) return 'تیم‌های همه ردیف‌ها را انتخاب کن.';
      if (h === a) return 'یک تیم نمی‌تواند با خودش بازی کند.';
      if (lg.teamIds.indexOf(h) < 0 || lg.teamIds.indexOf(a) < 0) return 'تیم انتخاب‌شده عضو این لیگ نیست.';
      if (busy[h] || busy[a]) return 'در یک هفته هر تیم فقط یک بازی دارد.';
      busy[h] = 1; busy[a] = 1;
      let groupId;
      if (stage === 'group') {
        const g = lg.groups.find((x) => x.teamIds.indexOf(h) >= 0 && x.teamIds.indexOf(a) >= 0);
        if (!g) return 'دو تیم باید در یک گروه باشند.';
        groupId = g.id;
      }
      out.push(L.newMatch({ leagueId: lg.id, stage, round, groupId, home: h, away: a, date: date || null, time: t || null }));
    }
    out.forEach((m) => db.matches.push(m));
    return null;
  };

  /* ---------- آمار ---------- */
  L.topScorers = (db, leagueId) => {
    const c = {};
    db.events.forEach((e) => { if (e.leagueId === leagueId && e.type === 'goal' && e.playerId) c[e.playerId] = (c[e.playerId] || 0) + 1; });
    return Object.keys(c).map((id) => ({ playerId: id, n: c[id] })).sort((a, b) => b.n - a.n);
  };
  L.mvpCounts = (db, leagueId) => {
    const c = {};
    db.awards.forEach((a) => { if (a.leagueId === leagueId && a.type === 'mvp') c[a.playerId] = (c[a.playerId] || 0) + 1; });
    return Object.keys(c).map((id) => ({ playerId: id, n: c[id] })).sort((a, b) => b.n - a.n);
  };

  /* ---------- تاریخ ---------- */
  L.addDays = (iso, n) => { const d = isoToDate(iso); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
  L.diffDays = (a, b) => Math.round((isoToDate(a) - isoToDate(b)) / 864e5);

  /* ---------- کارت و محرومیت ----------
     هر ۳ زرد = ۱ جلسه | قرمز مستقیم = ۲ جلسه | دو زرد (قرمز) در یک بازی = ۱ جلسه */
  L.CARD_TYPES = ['yellow', 'yy', 'red'];
  L.validateCards = (evs) => {
    const by = {};
    evs.forEach((e) => {
      if (L.CARD_TYPES.indexOf(e.type) < 0 || !e.playerId) return;
      const s = by[e.playerId] || (by[e.playerId] = { y: 0, yy: 0, r: 0 });
      if (e.type === 'yellow') s.y++; else if (e.type === 'yy') s.yy++; else s.r++;
    });
    for (const id in by) {
      const s = by[id];
      if (s.y > 1) return 'هر بازیکن در یک بازی فقط یک کارت زرد ساده می‌گیرد. برای دو زرد از «دو زرد (اخراج)» استفاده کن.';
      if (s.yy + s.r > 1) return 'یک بازیکن در یک بازی فقط یک بار اخراج می‌شود.';
      if (s.yy && s.y) return 'دو زرد (اخراج) را همراه کارت زرد جدا ثبت نکن.';
    }
    return null;
  };

  L.matchOrder = (a, b) => {
    const k = (m) => [m.date || '9999-12-31', m.time || '00:00', (m.stage === 'ko' || m.stage === 'third') ? 1 : 0, m.round || 0, m.stage === 'third' ? -1 : (m.pos || 0)];
    const x = k(a), y = k(b);
    for (let i = 0; i < 5; i++) { if (x[i] < y[i]) return -1; if (x[i] > y[i]) return 1; }
    return 0;
  };

  // وضعیت کارت و محرومیت هر بازیکن قبل از بازی «before» (یا بعد از همه بازی‌های انجام‌شده)
  L.cardState = (db, leagueId, before) => {
    const st = {};
    const get = (id) => st[id] || (st[id] = { yc: 0, pend: 0, y: 0, yy: 0, r: 0 });
    const ms = db.matches.filter((m) => m.leagueId === leagueId && m.played && !m.bye).sort(L.matchOrder);
    for (const m of ms) {
      if (before && (m.id === before.id || L.matchOrder(m, before) > 0)) break;
      [m.home, m.away].forEach((tid) => {
        db.players.forEach((p) => { if (p.teamId === tid && st[p.id] && st[p.id].pend > 0) st[p.id].pend--; });
      });
      db.events.filter((e) => e.matchId === m.id && e.playerId).forEach((e) => {
        if (e.type === 'yellow') { const s = get(e.playerId); s.y++; s.yc++; if (s.yc >= 3) { s.yc = 0; s.pend += 1; } }
        else if (e.type === 'yy') { const s = get(e.playerId); s.yy++; s.pend += 1; }
        else if (e.type === 'red') { const s = get(e.playerId); s.r++; s.pend += 2; }
      });
    }
    return st;
  };
  L.suspendedFor = (db, m) => {
    const st = L.cardState(db, m.leagueId, m);
    const out = {};
    db.players.forEach((p) => { if ((p.teamId === m.home || p.teamId === m.away) && st[p.id] && st[p.id].pend > 0) out[p.id] = st[p.id].pend; });
    return out;
  };

  /* ---------- صعود و سقوط ---------- */
  L.pickLeague = (db, level, exceptId) => {
    const c = db.leagues.filter((l) => l.level === level && l.id !== exceptId);
    return c.find((l) => l.status !== 'finished') || c[0] || null;
  };
  L.promotionPlan = (db, lg) => {
    const out = { up: [], down: [], upLeague: null, downLeague: null, ready: false };
    if (lg.format !== 'league' || !(lg.promote || lg.relegate)) return out;
    const ms = db.matches.filter((m) => m.leagueId === lg.id);
    out.ready = ms.length > 0 && ms.every((m) => m.played);
    const rows = L.standings(lg.teamIds, ms).map((r) => r.teamId);
    out.up = rows.slice(0, lg.promote);
    out.down = lg.relegate ? rows.slice(Math.max(rows.length - lg.relegate, lg.promote)) : [];
    out.upLeague = L.pickLeague(db, lg.level - 1, lg.id);
    out.downLeague = L.pickLeague(db, lg.level + 1, lg.id);
    return out;
  };
  L.applyPromotion = (db, lg) => {
    const p = L.promotionPlan(db, lg);
    if (!p.ready) return 'لیگ هنوز تمام نشده است.';
    if (lg.promotionApplied) return 'صعود و سقوط قبلاً اعمال شده است.';
    if (p.up.length && !p.upLeague) return 'لیگ بالاتر (سطح ' + L.fa(lg.level - 1) + ') پیدا نشد.';
    if (p.down.length && !p.downLeague) return 'لیگ پایین‌تر (سطح ' + L.fa(lg.level + 1) + ') پیدا نشد.';
    const move = (ids, target) => ids.forEach((id) => {
      const t = db.teams.find((x) => x.id === id);
      if (!t) return;
      t.leagueId = target.id;
      if (!db.matches.some((m) => m.leagueId === target.id) && target.teamIds.indexOf(id) < 0) target.teamIds.push(id);
    });
    if (p.up.length) move(p.up, p.upLeague);
    if (p.down.length) move(p.down, p.downLeague);
    lg.promotionApplied = true;
    return null;
  };

  /* ---------- داده نمونه ---------- */
  L.emptyDb = () => ({ v: 2, teams: [], players: [], leagues: [], matches: [], events: [], awards: [], settings: { dark: false } });

  L.normalize = (d) => {
    const db = Object.assign(L.emptyDb(), d, { settings: Object.assign({ dark: false }, d && d.settings) });
    db.leagues.forEach((l) => {
      if (l.level == null) l.level = 1;
      if (l.promote == null) l.promote = 0;
      if (l.relegate == null) l.relegate = 0;
      if (!l.groups) l.groups = [];
    });
    db.teams.forEach((t) => { if (t.leagueId === undefined) t.leagueId = null; });
    return db;
  };

  L.demo = () => {
    const db = L.emptyDb();
    const first = ['علی', 'رضا', 'حسین', 'مهدی', 'امیر', 'سجاد', 'محمد', 'پویا', 'سعید', 'کیان', 'آرش', 'بهنام'];
    const last = ['احمدی', 'رضایی', 'کریمی', 'موسوی', 'حسینی', 'صادقی', 'نوری', 'قاسمی', 'جعفری', 'رحیمی'];
    const pos = ['دروازه‌بان', 'فیکسو', 'آلا', 'آلا', 'پیوت'];
    const today = L.today();
    const mk = (name, level, teamNames, o) => {
      const lg = Object.assign({ id: L.uid(), name, province: 'تهران', venue: 'سالن آزادی', status: 'running', date: today, format: 'league', double: false, groupCount: 2, advance: 2, level, promote: 0, relegate: 0, teamIds: [], groups: [], bestPlayerId: null, autoFinished: false, promotionApplied: false }, o || {});
      teamNames.forEach((tn) => {
        const t = { id: L.uid(), name: tn, leagueId: lg.id, staff: { manager: '', head: '', coach: '', assistant: '', media: '' } };
        db.teams.push(t); lg.teamIds.push(t.id);
        for (let i = 0; i < 9; i++) db.players.push({ id: L.uid(), teamId: t.id, name: first[Math.floor(Math.random() * first.length)] + ' ' + last[Math.floor(Math.random() * last.length)], number: i + 1, pos: pos[i % pos.length] });
      });
      db.leagues.push(lg);
      return lg;
    };
    const l1 = mk('لیگ برتر', 1, ['پاس', 'گلسار', 'آراد', 'نیکان', 'سپهر', 'تیام'], { relegate: 1 });
    const l2 = mk('دسته یک', 2, ['ققنوس', 'رعد', 'البرز', 'آتا', 'فجر', 'ماهان'], { promote: 1, status: 'upcoming' });
    db.matches = L.genLeagueMatches(l1).concat(L.genLeagueMatches(l2));
    db.matches.forEach((m) => { m.date = L.addDays(today, m.leagueId === l1.id ? (m.round - 3) * 3 : (m.round - 1) * 3 + 1); });
    const plist = (tid) => L.shuffle(db.players.filter((p) => p.teamId === tid));
    db.matches.filter((m) => m.leagueId === l1.id && m.round <= 2).forEach((m) => {
      const hg = Math.floor(Math.random() * 6), ag = Math.floor(Math.random() * 6);
      const ev = [];
      const hp = plist(m.home), ap = plist(m.away);
      for (let i = 0; i < hg; i++) ev.push({ teamId: m.home, playerId: hp[Math.floor(Math.random() * hp.length)].id, type: 'goal' });
      for (let i = 0; i < ag; i++) ev.push({ teamId: m.away, playerId: ap[Math.floor(Math.random() * ap.length)].id, type: 'goal' });
      [[m.home, hp], [m.away, ap]].forEach(([tid, pl]) => {
        if (Math.random() < 0.7) ev.push({ teamId: tid, playerId: pl[0].id, type: 'yellow' });
        if (Math.random() < 0.15) ev.push({ teamId: tid, playerId: pl[1].id, type: 'red' });
      });
      L.saveResult(db, m, { hg, ag, date: m.date, events: ev, mvp: (Math.random() < 0.5 ? hp : ap)[2].id });
    });
    return db;
  };

  root.Logic = L;
  if (typeof module !== 'undefined' && module.exports) module.exports = L;
})(typeof window !== 'undefined' ? window : globalThis);
