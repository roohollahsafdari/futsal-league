/* منطق برنامه: بدون وابستگی به صفحه (قابل تست در Node) */
(function (root) {
  'use strict';
  const L = {};

  L.uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  L.shuffle = (arr) => {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  };
  L.fa = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]);

  /* ---------- تاریخ شمسی (با Intl خود مرورگر) ---------- */
  const JM = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  L.JM = JM;
  const jf = new Intl.DateTimeFormat('en-US-u-ca-persian-nu-latn', { timeZone: 'UTC', year: 'numeric', month: 'numeric', day: 'numeric' });
  const wf = new Intl.DateTimeFormat('fa-IR', { timeZone: 'UTC', weekday: 'long' });
  const jParts = (date) => {
    const p = {};
    jf.formatToParts(date).forEach((x) => { p[x.type] = x.value; });
    return { y: Number(p.year || p.relatedYear), m: Number(p.month), d: Number(p.day) };
  };
  const isoToDate = (iso) => { const [y, m, d] = iso.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d)); };
  L.toJalali = (iso) => jParts(isoToDate(iso));
  L.fromJalali = (jy, jm, jd) => {
    const start = Date.UTC(jy + 621, 2, 1);
    for (let i = 0; i < 400; i++) {
      const dt = new Date(start + i * 864e5);
      const j = jParts(dt);
      if (j.y === jy && j.m === jm && j.d === jd) return dt.toISOString().slice(0, 10);
    }
    return null;
  };
  L.fmtDate = (iso) => {
    if (!iso) return '';
    const j = L.toJalali(iso);
    return L.fa(j.d) + ' ' + JM[j.m - 1] + ' ' + L.fa(j.y);
  };
  L.weekday = (iso) => wf.format(isoToDate(iso));
  L.today = () => {
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  };

  /* ---------- ساخت بازی‌ها ---------- */
  L.newMatch = (o) => Object.assign({ id: L.uid(), played: false, hg: null, ag: null, hp: null, ap: null, date: null, bye: false }, o);

  L.roundRobin = (ids, double) => {
    const t = ids.slice();
    if (t.length % 2) t.push(null);
    const n = t.length;
    const rounds = [];
    for (let r = 0; r < n - 1; r++) {
      const games = [];
      for (let i = 0; i < n / 2; i++) {
        const a = t[i], b = t[n - 1 - i];
        if (a && b) games.push(r % 2 ? [b, a] : [a, b]);
      }
      rounds.push(games);
      t.splice(1, 0, t.pop());
    }
    if (double) return rounds.concat(rounds.map((g) => g.map(([a, b]) => [b, a])));
    return rounds;
  };

  L.genLeagueMatches = (lg) =>
    L.roundRobin(L.shuffle(lg.teamIds), lg.double).flatMap((games, r) =>
      games.map(([h, a]) => L.newMatch({ leagueId: lg.id, stage: 'league', round: r + 1, home: h, away: a })));

  L.genGroups = (lg) => {
    const g = lg.groupCount;
    const groups = [];
    for (let i = 0; i < g; i++) groups.push({ id: 'g' + (i + 1), name: 'گروه ' + 'ABCDEFGH'[i], teamIds: [] });
    L.shuffle(lg.teamIds).forEach((id, i) => groups[i % g].teamIds.push(id));
    const matches = [];
    groups.forEach((gr) => {
      L.roundRobin(gr.teamIds, lg.double).forEach((games, r) =>
        games.forEach(([h, a]) => matches.push(L.newMatch({ leagueId: lg.id, stage: 'group', groupId: gr.id, round: r + 1, home: h, away: a }))));
    });
    return { groups, matches };
  };

  L.nextPow2 = (n) => { let s = 2; while (s < n) s *= 2; return s; };
  L.seedOrder = (S) => {
    let a = [1];
    while (a.length < S) { const n = a.length * 2; a = a.flatMap((x) => [x, n + 1 - x]); }
    return a;
  };
  L.roundName = (R, i) => {
    const rem = Math.pow(2, R - i);
    return rem === 2 ? 'فینال' : rem === 4 ? 'نیمه‌نهایی' : rem === 8 ? 'یک‌چهارم نهایی' : rem === 16 ? 'یک‌هشتم نهایی' : 'دور ' + L.fa(rem) + ' تیم';
  };

  L.koRounds = (ms) => {
    const ko = ms.filter((x) => x.stage === 'ko');
    return ko.length ? Math.max.apply(null, ko.map((x) => x.round)) + 1 : 0;
  };

  L.advance = (ms, m, w, l) => {
    if (m.stage !== 'ko') return;
    const R = L.koRounds(ms);
    const slot = m.pos % 2 === 0 ? 'home' : 'away';
    if (m.round < R - 1) {
      const nx = ms.find((x) => x.stage === 'ko' && x.round === m.round + 1 && x.pos === Math.floor(m.pos / 2));
      if (nx) nx[slot] = w;
    }
    if (m.round === R - 2) {
      const th = ms.find((x) => x.stage === 'third');
      if (th) th[slot] = l;
    }
  };

  L.dependents = (ms, m) => {
    if (m.stage !== 'ko') return [];
    const R = L.koRounds(ms);
    const out = [];
    const nx = ms.find((x) => x.stage === 'ko' && x.round === m.round + 1 && x.pos === Math.floor(m.pos / 2));
    if (nx) out.push(nx);
    if (m.round === R - 2) { const th = ms.find((x) => x.stage === 'third'); if (th) out.push(th); }
    return out;
  };

  // seeds: تیم‌ها به ترتیب سرگروه (قوی‌ترین اول). تعداد غیر توان ۲ = بای برای نفرات اول
  L.buildBracket = (leagueId, seeds) => {
    const n = seeds.length;
    const S = L.nextPow2(n);
    const R = Math.log2(S);
    const padded = seeds.concat(Array(S - n).fill(null));
    const order = L.seedOrder(S);
    const ms = [];
    for (let r = 0; r < R; r++) {
      for (let p = 0; p < S / Math.pow(2, r + 1); p++) {
        ms.push(L.newMatch({ leagueId, stage: 'ko', round: r, pos: p, roundName: L.roundName(R, r) }));
      }
    }
    ms.filter((m) => m.round === 0).forEach((m) => {
      m.home = padded[order[2 * m.pos] - 1];
      m.away = padded[order[2 * m.pos + 1] - 1];
    });
    if (S >= 8 || n === 4) ms.push(L.newMatch({ leagueId, stage: 'third', round: R - 1, pos: 0, roundName: 'رده‌بندی (سوم و چهارم)' }));
    ms.filter((m) => m.stage === 'ko' && m.round === 0).forEach((m) => {
      if ((m.home && !m.away) || (!m.home && m.away)) {
        m.bye = true; m.played = true;
        L.advance(ms, m, m.home || m.away, null);
      }
    });
    return ms;
  };

  /* ---------- نتایج و جدول ---------- */
  L.outcome = (m) => {
    if (!m.played || m.bye) return null;
    if (m.hg > m.ag) return { w: m.home, l: m.away };
    if (m.hg < m.ag) return { w: m.away, l: m.home };
    if (m.hp != null && m.ap != null) return m.hp > m.ap ? { w: m.home, l: m.away } : { w: m.away, l: m.home };
    return { w: null, l: null };
  };

  L.standings = (teamIds, matches) => {
    const t = {};
    teamIds.forEach((id) => { t[id] = { teamId: id, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, gd: 0, pts: 0 }; });
    matches.forEach((m) => {
      if (!m.played || m.bye || !t[m.home] || !t[m.away]) return;
      const h = t[m.home], a = t[m.away];
      h.p++; a.p++;
      h.gf += m.hg; h.ga += m.ag; a.gf += m.ag; a.ga += m.hg;
      if (m.hg > m.ag) { h.w++; a.l++; h.pts += 3; }
      else if (m.hg < m.ag) { a.w++; h.l++; a.pts += 3; }
      else { h.d++; a.d++; h.pts++; a.pts++; }
    });
    const rows = Object.keys(t).map((k) => { t[k].gd = t[k].gf - t[k].ga; return t[k]; });
    rows.sort((x, y) => y.pts - x.pts || y.gd - x.gd || y.gf - x.gf);
    return rows;
  };

  L.podium = (db, lg) => {
    const ms = db.matches.filter((m) => m.leagueId === lg.id);
    const out = { champion: null, runnerUp: null, third: null, fourth: null };
    if (lg.format === 'league') {
      if (ms.length && ms.every((m) => m.played)) {
        const st = L.standings(lg.teamIds, ms).map((r) => r.teamId);
        out.champion = st[0] || null; out.runnerUp = st[1] || null; out.third = st[2] || null; out.fourth = st[3] || null;
      }
    } else {
      const R = L.koRounds(ms);
      const fin = ms.find((m) => m.stage === 'ko' && m.round === R - 1);
      if (fin && fin.played) { const o = L.outcome(fin); out.champion = o.w; out.runnerUp = o.l; }
      const th = ms.find((m) => m.stage === 'third');
      if (th && th.played) { const o = L.outcome(th); out.third = o.w; out.fourth = o.l; }
    }
    return out;
  };

  L.syncStatus = (db, lg) => {
    const p = L.podium(db, lg);
    if (p.champion && lg.status !== 'finished') { lg.status = 'finished'; lg.autoFinished = true; }
    else if (!p.champion && lg.autoFinished) { lg.status = 'running'; lg.autoFinished = false; }
    else if (lg.status === 'upcoming' && db.matches.some((m) => m.leagueId === lg.id && m.played && !m.bye)) lg.status = 'running';
  };

  // d: {hg, ag, hp, ap, date, events:[{teamId, playerId, type}], mvp}
  L.saveResult = (db, m, d) => {
    const lg = db.leagues.find((x) => x.id === m.leagueId);
    const ms = db.matches.filter((x) => x.leagueId === m.leagueId);
    const isKo = m.stage === 'ko' || m.stage === 'third';
    if (!m.home || !m.away) return 'تیم‌های این بازی هنوز مشخص نشده‌اند.';
    if (!(d.hg >= 0) || !(d.ag >= 0)) return 'گل هر دو تیم را وارد کن.';
    let hp = null, ap = null;
    if (isKo && d.hg === d.ag) {
      if (d.hp == null || d.ap == null || d.hp === d.ap) return 'در حذفی، نتیجه مساوی باید با پنالتی مشخص شود.';
      hp = d.hp; ap = d.ap;
    }
    const old = m.played ? L.outcome(m) : null;
    const nw = d.hg > d.ag ? { w: m.home, l: m.away } : d.hg < d.ag ? { w: m.away, l: m.home } : hp > ap ? { w: m.home, l: m.away } : { w: m.away, l: m.home };
    if (old && old.w !== nw.w && L.dependents(ms, m).some((x) => x.played)) return 'ابتدا نتیجه دور بعد را پاک کن.';
    m.hg = d.hg; m.ag = d.ag; m.hp = hp; m.ap = ap; m.played = true;
    if (d.date) m.date = d.date;
    db.events = db.events.filter((e) => e.matchId !== m.id);
    (d.events || []).forEach((e) => db.events.push({ id: L.uid(), matchId: m.id, leagueId: m.leagueId, teamId: e.teamId, playerId: e.playerId || null, type: e.type }));
    db.awards = db.awards.filter((a) => !(a.matchId === m.id && a.type === 'mvp'));
    if (d.mvp) db.awards.push({ id: L.uid(), matchId: m.id, leagueId: m.leagueId, playerId: d.mvp, type: 'mvp' });
    if (isKo) L.advance(ms, m, nw.w, nw.l);
    L.syncStatus(db, lg);
    return null;
  };

  L.clearResult = (db, m) => {
    const ms = db.matches.filter((x) => x.leagueId === m.leagueId);
    const lg = db.leagues.find((x) => x.id === m.leagueId);
    if (m.bye) return 'این بازی بای است.';
    if (L.dependents(ms, m).some((x) => x.played)) return 'ابتدا نتیجه دور بعد را پاک کن.';
    if (m.stage === 'ko') L.advance(ms, m, null, null);
    m.played = false; m.hg = m.ag = m.hp = m.ap = null;
    db.events = db.events.filter((e) => e.matchId !== m.id);
    db.awards = db.awards.filter((a) => a.matchId !== m.id);
    L.syncStatus(db, lg);
    return null;
  };

  L.groupsToKo = (db, lg) => {
    const ms = db.matches.filter((m) => m.leagueId === lg.id);
    if (ms.some((m) => m.stage === 'ko')) return { error: 'مرحله حذفی قبلاً ساخته شده.' };
    const gm = ms.filter((m) => m.stage === 'group');
    if (!gm.length || !gm.every((m) => m.played)) return { error: 'بازی‌های گروهی هنوز تمام نشده.' };
    const tables = lg.groups.map((g) => L.standings(g.teamIds, gm.filter((m) => m.groupId === g.id)));
    const seeds = [];
    for (let r = 0; r < lg.advance; r++) tables.forEach((t) => { if (t[r]) seeds.push(t[r].teamId); });
    if (seeds.length < 2) return { error: 'تیم کافی برای مرحله حذفی نیست.' };
    return { matches: L.buildBracket(lg.id, seeds) };
  };

  /* ---------- آمار ---------- */
  L.topScorers = (db, leagueId) => {
    const c = {};
    db.events.forEach((e) => { if (e.leagueId === leagueId && e.type === 'goal' && e.playerId) c[e.playerId] = (c[e.playerId] || 0) + 1; });
    return Object.keys(c).map((id) => ({ playerId: id, n: c[id] })).sort((a, b) => b.n - a.n);
  };
  L.mvpCounts = (db, leagueId) => {
    const c = {};
    db.awards.forEach((a) => { if (a.leagueId === leagueId && a.type === 'mvp') c[a.playerId] = (c[a.playerId] || 0) + 1; });
    return Object.keys(c).map((id) => ({ playerId: id, n: c[id] })).sort((a, b) => b.n - a.n);
  };

  /* ---------- داده نمونه ---------- */
  L.emptyDb = () => ({ v: 1, teams: [], players: [], leagues: [], matches: [], events: [], awards: [], settings: { dark: false } });

  L.demo = () => {
    const db = L.emptyDb();
    const first = ['علی', 'رضا', 'حسین', 'مهدی', 'امیر', 'سجاد', 'محمد', 'پویا', 'سعید', 'کیان', 'آرش', 'بهنام'];
    const last = ['احمدی', 'رضایی', 'کریمی', 'موسوی', 'حسینی', 'صادقی', 'نوری', 'قاسمی', 'جعفری', 'رحیمی'];
    const pos = ['دروازه‌بان', 'فیکسو', 'آلا', 'آلا', 'پیوت'];
    ['پاس', 'گلسار', 'آراد', 'نیکان', 'سپهر', 'تیام'].forEach((name) => {
      const t = { id: L.uid(), name, staff: { manager: '', head: '', coach: '', assistant: '', media: '' } };
      db.teams.push(t);
      for (let i = 0; i < 9; i++) {
        db.players.push({ id: L.uid(), teamId: t.id, name: first[Math.floor(Math.random() * first.length)] + ' ' + last[Math.floor(Math.random() * last.length)], number: i + 1, pos: pos[i % pos.length] });
      }
    });
    const lg = { id: L.uid(), name: 'لیگ نمونه', province: 'تهران', venue: 'سالن آزادی', status: 'running', date: L.today(), format: 'league', double: false, groupCount: 2, advance: 2, teamIds: db.teams.map((t) => t.id), groups: [], bestPlayerId: null, autoFinished: false };
    db.leagues.push(lg);
    db.matches = L.genLeagueMatches(lg);
    db.matches.filter((m) => m.round <= 2).forEach((m) => {
      const hg = Math.floor(Math.random() * 6), ag = Math.floor(Math.random() * 6);
      const ev = [];
      const pick = (tid) => { const ps = db.players.filter((p) => p.teamId === tid); return ps[Math.floor(Math.random() * ps.length)].id; };
      for (let i = 0; i < hg; i++) ev.push({ teamId: m.home, playerId: pick(m.home), type: 'goal' });
      for (let i = 0; i < ag; i++) ev.push({ teamId: m.away, playerId: pick(m.away), type: 'goal' });
      L.saveResult(db, m, { hg, ag, date: L.today(), events: ev, mvp: pick(Math.random() < 0.5 ? m.home : m.away) });
    });
    return db;
  };

  root.Logic = L;
  if (typeof module !== 'undefined' && module.exports) module.exports = L;
})(typeof window !== 'undefined' ? window : globalThis);
