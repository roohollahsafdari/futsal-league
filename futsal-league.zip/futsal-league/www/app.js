/* رابط کاربری برنامه لیگ فوتسال - نسخه ۱.۱ */
(function () {
  'use strict';
  const L = window.Logic;
  const fa = L.fa;
  const KEY = 'futsal_db_v1';
  const POS = ['دروازه‌بان', 'فیکسو', 'آلا', 'پیوت'];
  const ROLES = [['manager', 'سرپرست'], ['head', 'سرمربی'], ['coach', 'مربی'], ['assistant', 'کمک‌مربی'], ['media', 'مسئول رسانه']];
  const FORMATS = { league: 'لیگی', knockout: 'حذفی (جام)', groups: 'گروهی + حذفی' };
  const STATUS = { upcoming: 'به‌زودی', running: 'در حال برگزاری', finished: 'تمام‌شده' };
  const CARD = { yellow: 'کارت زرد', yy: 'دو زرد (اخراج)', red: 'قرمز مستقیم' };
  const CARD_SHORT = { yellow: 'زرد', yy: 'دو زرد (اخراج)', red: 'قرمز مستقیم' };
  const STATE = { notheld: 'برگزار نشد', cancelled: 'لغو شد', postponed: 'به تعویق افتاد' };
  const VERSION = '۲٫۲';
  const MAX_PLAYERS = 30;

  const KINDS = ['leagues', 'teams', 'players', 'matches', 'events', 'awards'];
  const S = { base: null, rev: '', busy: false, again: false, timer: null, pending: 0, pendingTotal: 0, pendingLatest: '', lastPT: -1, err: '', deferred: null, bkey: '' };
  const SV = { act: null, users: null, sessions: null, pending: null, fresh: {}, loading: false, err: '' };
  let db = load();
  const ui = { ptab: 'activity', afUser: 'all', afType: 'all', aLimit: 40, homeDay: null, tab: 'matches', q: '', leagueId: null, edit: null, teamTab: null };
  const app = document.getElementById('app');

  /* ---------- ذخیره‌سازی ---------- */
  const cacheKey = () => 'futsal_db_u' + (Auth.current() ? Auth.current().id : 0);
  // function (نه const) تا پیش از اجرای load() در شروع برنامه در دسترس باشد
  function userFromMe(m) { return { first: m.first_name || '', last: m.last_name || '', phone: m.phone || '', email: m.email || '', role: m.role_title || '', photo: '' }; }
  function load() {
    let st = { dark: false };
    try { st = Object.assign(st, JSON.parse(localStorage.getItem('futsal_settings'))); } catch (e) { /* خالی */ }
    let d = null;
    const me = Auth.current();
    if (me) {
      try {
        const c = JSON.parse(localStorage.getItem('futsal_db_u' + me.id));
        if (c && c.d && c.b) { d = c.d; S.base = c.b; S.rev = c.r || ''; }
      } catch (e) { /* خالی */ }
    }
    // داده‌های نسخه‌های قدیمی (فقط ذخیره روی گوشی): یک‌بار برای مدیر اصلی به سرور منتقل می‌شود
    if (!d && me && me.role === 'admin') {
      try {
        const old = JSON.parse(localStorage.getItem(KEY));
        if (old && Array.isArray(old.teams) && (old.teams.length || old.leagues.length)) { d = {}; KINDS.forEach((k) => { d[k] = old[k] || []; }); S.base = hashMap(L.emptyDb()); S.rev = ''; }
      } catch (e) { /* خالی */ }
    }
    const nd = L.normalize(Object.assign(L.emptyDb(), d || {}));
    nd.settings = st;
    if (me) nd.user = userFromMe(me);
    return nd;
  }
  function persist() {
    try {
      localStorage.setItem('futsal_settings', JSON.stringify(db.settings));
      if (Auth.current() && S.base) {
        const d = {}; KINDS.forEach((k) => { d[k] = db[k]; });
        localStorage.setItem(cacheKey(), JSON.stringify({ d, b: S.base, r: S.rev }));
      }
    } catch (e) { toast('ذخیره‌سازی روی گوشی انجام نشد'); }
  }
  function save() { persist(); if (Auth.current()) scheduleSync(1200); }
  function commit() { save(); render(true); }

  /* ---------- همگام‌سازی با سرور ---------- */
  function hstr(s) {
    let h1 = 0xdeadbeef ^ s.length, h2 = 0x41c6ce57 ^ s.length;
    for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677); }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (h2 >>> 0).toString(36) + (h1 >>> 0).toString(36) + s.length;
  }
  function hashMap(d) {
    const m = {};
    KINDS.forEach((k) => { m[k] = {}; (d[k] || []).forEach((o) => { m[k][o.id] = hstr(JSON.stringify(o)); }); });
    return m;
  }
  function diffChanges(base, d) {
    const ch = [];
    KINDS.forEach((k) => {
      const seen = {};
      (d[k] || []).forEach((o) => {
        seen[o.id] = 1;
        const j = JSON.stringify(o);
        if (base[k][o.id] !== hstr(j)) ch.push({ kind: k, id: o.id, op: 'upsert', json: j });
      });
      Object.keys(base[k] || {}).forEach((id) => { if (!seen[id]) ch.push({ kind: k, id, op: 'delete' }); });
    });
    return ch;
  }
  function scheduleSync(ms) { clearTimeout(S.timer); S.timer = setTimeout(doSync, ms == null ? 1200 : ms); }
  async function doSync() {
    if (!Auth.current()) return;
    if (S.busy) { S.again = true; return; }
    S.busy = true;
    if (Auth.isOfflineSession()) {
      if (!S.base) S.base = hashMap(L.emptyDb());
      const up = await Auth.upgrade();
      if (up !== 'ok') {
        S.err = 'offline'; S.busy = false;
        if (up === 'need' && navigator.onLine !== false) askUpgrade();
        refreshBanner();
        return;
      }
      ui.upAsked = false;
    }
    const sent = hashMap(db);
    const changes = S.base ? diffChanges(S.base, db) : [];
    try {
      const r = await Auth.api('sync', { rev: changes.length ? '' : (S.base ? S.rev : ''), changes });
      if (!r.ok) throw new Error(r.error || 'server');
      S.err = '';
      onSync(r, sent, changes.length > 0);
    } catch (e) {
      if (e.auth) { S.busy = false; return; }
      S.err = 'offline';
    }
    S.busy = false;
    if (S.again) { S.again = false; scheduleSync(300); }
    refreshBanner();
  }
  function onSync(r, sent, hadChanges) {
    S.rev = r.rev; S.pending = r.pending || 0; S.pendingTotal = r.pending_total || 0; S.pendingLatest = r.pending_latest || '';
    Auth.setMe(r.me);
    notifyPending();
    db.user = userFromMe(r.me);
    if (r.denied && r.denied.length) toast('بخشی از تغییرات اجازه نداشت و برگردانده شد');
    if (r.decided && r.decided.length) {
      const ap = r.decided.filter((x) => x.status === 'approved').length, rj = r.decided.length - ap;
      toast((ap ? fa(ap) + ' تغییر تو تایید شد' : '') + (ap && rj ? ' • ' : '') + (rj ? fa(rj) + ' تغییر تو رد شد و برگشت' : ''));
    }
    if (r.db) {
      if (document.getElementById('modal')) { S.deferred = { remote: r.db, sent }; }
      else applyRemote(r.db, sent);
    } else if (!S.base) { S.err = 'offline'; }
    persist();
  }
  function applyRemote(remote, sent) {
    S.deferred = null;
    const nd = L.normalize(Object.assign(L.emptyDb(), remote));
    nd.settings = db.settings; nd.user = userFromMe(Auth.current());
    const newBase = hashMap(nd);
    const cur = hashMap(db);
    const same = JSON.stringify(newBase) === JSON.stringify(cur);
    if (!same) {
      // تغییرهای محلی بعد از ارسال را روی داده‌ی جدید سرور دوباره اعمال کن
      const inflight = diffChanges(sent, db);
      inflight.forEach((c) => {
        const list = nd[c.kind], i = list.findIndex((o) => o.id === c.id);
        if (c.op === 'delete') { if (i >= 0) list.splice(i, 1); }
        else { const o = JSON.parse(c.json); if (i >= 0) list[i] = o; else list.push(o); }
      });
      db = nd;
      if (inflight.length) scheduleSync(500);
    }
    S.base = newBase;
    persist();
    if (!same || !document.getElementById('modal')) render(true);
  }
  function applyDeferred() { if (S.deferred && !document.getElementById('modal')) applyRemote(S.deferred.remote, S.deferred.sent); }
  function bannerHtml() {
    if (!Auth.current()) return '';
    let h = '';
    if (canApprove() && S.pendingTotal) h += '<a class="sbar" href="#/users" data-act="goApprovals">' + fa(S.pendingTotal) + ' تغییر منتظر تایید توست ‹</a>';
    if (!Auth.isAdmin() && S.pending) h += '<div class="sbar">' + fa(S.pending) + ' تغییر تو منتظر تایید است و فعلاً فقط روی گوشی خودت دیده می‌شود.</div>';
    return h;
  }
  function refreshBanner() {
    const k = bannerHtml();
    if (k !== S.bkey) { S.bkey = k; if (!document.getElementById('modal')) render(true); }
  }
  const lvl = () => (Auth.current() ? Auth.current().level || (Auth.isAdmin() ? 1 : 3) : 0);
  const canApprove = () => lvl() === 1 || (lvl() === 2 && (Auth.current().can_sub || S.pendingTotal > 0));
  const canManage = () => lvl() === 1 || (lvl() === 2 && !!Auth.current().can_sub);
  // اعلان بالای صفحه: وقتی تغییری منتظر تایید است (در اولین همگام‌سازی و هر بار که تعداد زیاد شود)
  let ntm;
  function notifyPending() {
    const n = canApprove() ? S.pendingTotal : 0;
    const old = S.lastPT; S.lastPT = n;
    if (n > 0 && (old < 0 || n > old)) showNotif(n);
    if (n === 0) hideNotif();
  }
  function showNotif(n) {
    hideNotif();
    const el = document.createElement('div');
    el.id = 'notif'; el.className = 'notif'; el.setAttribute('role', 'alert');
    el.innerHTML = '<a class="nbody" href="#/users" data-act="goApprovals"><span class="nic">' + icon('bell') + '</span><span class="ntx"><b>' + fa(n) + ' تغییر منتظر تایید توست</b><small>' + esc(S.pendingLatest) + '</small></span></a><button class="icon-btn" data-act="closeNotif" aria-label="بستن">' + icon('x') + '</button>';
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    try { if (navigator.vibrate) navigator.vibrate(120); } catch (e) { /* خالی */ }
    clearTimeout(ntm); ntm = setTimeout(hideNotif, 12000);
  }
  function hideNotif() { const el = document.getElementById('notif'); if (el) el.remove(); clearTimeout(ntm); }
  function resetLocal(keepId) {
    clearTimeout(S.timer);
    try { Object.keys(localStorage).forEach((k) => { if (k.indexOf('futsal_db_u') === 0 && (keepId == null || k !== 'futsal_db_u' + keepId)) localStorage.removeItem(k); }); } catch (e) { /* خالی */ }
    S.base = null; S.rev = ''; S.pending = 0; S.pendingTotal = 0; S.pendingLatest = ''; S.lastPT = -1; hideNotif(); S.err = ''; S.deferred = null; S.bkey = ''; S.busy = false;
    const st = db.settings;
    db = L.emptyDb(); db.settings = st;
    SV.act = SV.users = SV.sessions = SV.pending = null; SV.fresh = {};
  }
  // کاربری که باید تغییرات را تایید کند، زودتر (۱۵ ثانیه) خبر می‌گیرد
  setInterval(() => { if (!document.hidden && Auth.current()) doSync(); }, 15000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && Auth.current()) doSync(); });
  window.addEventListener('online', () => { if (Auth.current()) doSync(); });

  /* ---------- ابزارها ---------- */
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const val = (id) => { const el = document.getElementById(id); return el ? el.value : ''; };
  const team = (id) => db.teams.find((t) => t.id === id);
  const player = (id) => db.players.find((p) => p.id === id);
  const league = (id) => db.leagues.find((l) => l.id === id);
  const players = (tid) => db.players.filter((p) => p.teamId === tid).sort((a, b) => a.number - b.number);
  const tn = (id) => (team(id) ? esc(team(id).name) : '<em>مشخص نشده</em>');
  const goalsOf = (pid) => db.events.filter((e) => e.playerId === pid && e.type === 'goal').length;
  const sortedLeagues = () => db.leagues.slice().sort((a, b) => a.level - b.level || a.name.localeCompare(b.name, 'fa'));
  const hasMatches = (lid) => db.matches.some((m) => m.leagueId === lid);

  const ICONS = {
    home: '<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14c2.8 0 4.5 1.9 4.5 4.5"/>',
    trophy: '<path d="M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M7 6H4v2a3 3 0 0 0 3 3M17 6h3v2a3 3 0 0 1-3 3M12 14v4M8 21h8M10 18h4"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    back: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    search: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4-4"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
    camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
    share: '<circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="M8.2 10.8l7.6-4.4M8.2 13.2l7.6 4.4"/>',
    download: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
    image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M4 18l5-5 4 4 3-3 4 4"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    logout: '<path d="M10 4H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h5M15 8l4 4-4 4M19 12H9"/>',
    bell: '<path d="M6 17V11a6 6 0 0 1 12 0v6l1.5 2h-15zM10 21h4"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M18.4 5.6l-1.8 1.8M7.4 16.6l-1.8 1.8"/>',
    idcard: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="M6 16c.6-1.6 1.8-2.2 3-2.2s2.4.6 3 2.2M14.5 10h4M14.5 13h3"/>',
    ban: '<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/>'
  };
  const icon = (n) => '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICONS[n] + '</svg>';

  let tt;
  function toast(msg) {
    let el = document.getElementById('toast');
    if (!el) { el = document.createElement('div'); el.id = 'toast'; document.body.appendChild(el); }
    el.textContent = msg; el.className = 'show';
    clearTimeout(tt); tt = setTimeout(() => { el.className = ''; }, 3200);
  }
  let nativeBack = false, modalPushed = false, skipPop = 0;
  function modal(title, body, actions) {
    const old = document.getElementById('modal');
    if (old) old.remove();
    const el = document.createElement('div');
    el.className = 'backdrop'; el.id = 'modal';
    el.innerHTML = '<div class="sheet" role="dialog" aria-label="' + esc(title) + '"><div class="sheet-h"><b>' + esc(title) + '</b><button class="icon-btn" data-act="closeModal" aria-label="بستن">' + icon('x') + '</button></div><div class="sheet-b">' + body + '</div>' + (actions ? '<div class="sheet-f">' + actions + '</div>' : '') + '</div>';
    el.addEventListener('click', (e) => { if (e.target === el) closeModal(); });
    document.body.appendChild(el);
    document.body.classList.add('lock');
    if (!nativeBack && !modalPushed) { history.pushState({ modal: 1 }, ''); modalPushed = true; }
  }
  function closeModal(noBack) {
    const m = document.getElementById('modal');
    if (m) m.remove();
    document.body.classList.remove('lock');
    if (modalPushed) { modalPushed = false; if (noBack !== true) { skipPop++; history.back(); } }
    if (S.deferred) setTimeout(applyDeferred, 0);
  }
  const empty = (t, p, actions) => '<div class="empty"><b>' + t + '</b>' + (p ? '<p>' + p + '</p>' : '') + (actions || '') + '</div>';
  const head = (title, back, sub) => '<header class="top' + (back ? '' : ' root') + '">' + (back ? '<a class="icon-btn fill" href="' + back + '" aria-label="بازگشت">' + icon('back') + '</a>' : '<button class="icon-btn fill" data-act="openDrawer" aria-label="منو">' + icon('menu') + '</button>') + '<div class="ttl"><h1>' + esc(title) + '</h1>' + (sub ? '<small>' + sub + '</small>' : '') + '</div></header>';
  const fab = (act, label, extra) => '<div class="fabwrap"><button class="fab" data-act="' + act + '"' + (extra || '') + '>' + icon('plus') + '<span>' + label + '</span></button></div>';
  function ring(p, cls) {
    const c = 2 * Math.PI * 18;
    return '<span class="ring ' + (cls || '') + '" role="img" aria-label="' + fa(p) + ' درصد"><svg viewBox="0 0 44 44"><circle class="rt" cx="22" cy="22" r="18"/><circle class="rp" cx="22" cy="22" r="18" stroke-dasharray="' + (c * p / 100).toFixed(1) + ' ' + c.toFixed(1) + '" transform="rotate(-90 22 22)"/></svg><b>' + fa(p) + '٪</b></span>';
  }
  function progress(lg) {
    const ms = db.matches.filter((m) => m.leagueId === lg.id && !m.bye && m.state !== 'notheld' && m.state !== 'cancelled');
    return ms.length ? Math.round(ms.filter((m) => m.played).length * 100 / ms.length) : 0;
  }
  function heroToday(today, dates) {
    const ms = db.matches.filter((m) => m.date === today && !m.bye);
    const pending = ms.filter((m) => !m.played && !m.state && m.home && m.away).sort((a, b) => (a.time || '99:99').localeCompare(b.time || '99:99') || a.round - b.round)[0];
    const nextD = dates.filter((d) => d > today)[0];
    let t, p, btn;
    if (ms.length) {
      t = fa(ms.length) + ' بازی امروز';
      p = pending ? 'بعدی: ' + tn(pending.home) + ' – ' + tn(pending.away) + (pending.time ? ' • ساعت ' + L.fmtTime(pending.time) : '') : 'نتیجه همه بازی‌ها ثبت شد';
      btn = pending ? '<button class="pill" data-act="openMatch" data-id="' + pending.id + '" data-home="1">ثبت نتیجه</button>' : '<a class="pill" href="#/leagues">لیگ‌ها</a>';
    } else {
      t = 'امروز بازی نداری';
      p = nextD ? 'بازی بعدی: ' + (L.diffDays(nextD, today) === 1 ? 'فردا' : L.fmtDate(nextD)) : 'تاریخ بازی‌ها را در صفحه لیگ تعیین کن.';
      btn = '<a class="pill" href="#/leagues">لیگ‌ها</a>';
    }
    return '<section class="hero"><div class="hero-t"><small>امروز</small><h2>' + t + '</h2><p>' + p + '</p></div>' + btn + '<span class="blob b1"></span><span class="blob b2"></span></section>';
  }
  function welcome() {
    return '<section class="welcome"><svg class="illu" viewBox="0 0 220 150" aria-hidden="true"><rect x="10" y="26" width="200" height="104" rx="16" fill="var(--soft)" stroke="var(--primary)" stroke-width="3"/><line x1="110" y1="26" x2="110" y2="130" stroke="var(--primary)" stroke-width="3"/><circle cx="110" cy="78" r="20" fill="none" stroke="var(--primary)" stroke-width="3"/><path d="M10 54a24 24 0 0 1 0 48M210 54a24 24 0 0 0 0 48" fill="none" stroke="var(--primary)" stroke-width="3"/><circle cx="160" cy="36" r="17" fill="#fff" stroke="var(--primary)" stroke-width="3"/><path d="M160 29l7 5-3 8h-8l-3-8z" fill="var(--primary)"/></svg><h2>لیگ فوتسال خودت را بساز</h2><p>تیم‌ها، لیگ‌ها، نتایج و جدول‌ها را یک‌جا مدیریت کن.</p><a class="btn" href="#/leagues">شروع</a> <button class="btn sec" data-act="demo">داده نمونه</button></section>';
  }
  function nav(tab) {
    const items = [['home', 'خانه', 'home'], ['teams', 'تیم‌ها', 'users'], ['leagues', 'لیگ‌ها', 'trophy'], ['users', lvl() === 3 ? 'فعالیت‌ها' : 'کاربران', 'idcard']];
    const nb = canApprove() && S.pendingTotal ? '<i class="nb">' + fa(S.pendingTotal) + '</i>' : '';
    return '<nav class="nav">' + items.map(([k, l, i]) => '<a href="#/' + k + '" class="' + (k === tab ? 'on' : '') + '"><span class="ind">' + icon(i) + (k === 'users' ? nb : '') + '</span><span>' + l + '</span></a>').join('') + '</nav>';
  }
  function dateInput(id, iso) {
    const j = L.toJalali(iso || L.today());
    return '<div class="dt" id="' + id + '"><input type="number" inputmode="numeric" class="dd" value="' + j.d + '" aria-label="روز">' +
      '<select class="dm" aria-label="ماه">' + L.JM.map((n, i) => '<option value="' + (i + 1) + '"' + (i + 1 === j.m ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>' +
      '<input type="number" inputmode="numeric" class="dy" value="' + j.y + '" aria-label="سال"></div>';
  }
  function readDate(id) {
    const el = document.getElementById(id);
    if (!el) return null;
    return L.fromJalali(parseInt(el.querySelector('.dy').value, 10), parseInt(el.querySelector('.dm').value, 10), parseInt(el.querySelector('.dd').value, 10));
  }
  const sel = (opts, cur) => opts.map(([v, l]) => '<option value="' + v + '"' + (String(cur) === String(v) ? ' selected' : '') + '>' + l + '</option>').join('');

  /* ---------- نمایش‌ها ---------- */
  function render(keep) {
    document.documentElement.dataset.theme = db.settings.dark ? 'dark' : 'light';
    if (!Auth.current()) { closeDrawer(); app.innerHTML = vLogin(); return; }
    if (!S.base) { app.innerHTML = vLoading(); return; }
    const y = window.scrollY;
    const h = location.hash.replace(/^#\/?/, '') || 'home';
    const parts = h.split('/');
    let v;
    switch (parts[0]) {
      case 'teams': v = vTeams(); break;
      case 'team': v = vTeam(parts[1]); break;
      case 'leagues': v = vLeagues(); break;
      case 'league': v = vLeague(parts[1]); break;
      case 'users': v = vUsers(); break;
      case 'profile': v = vProfile(); break;
      case 'settings': v = vSettings(); break;
      case 'about': v = vAbout(); break;
      default: v = vHome();
    }
    document.documentElement.dataset.theme = db.settings.dark ? 'dark' : 'light';
    S.bkey = bannerHtml();
    app.innerHTML = v.html.replace('</header>', '</header>' + S.bkey) + nav(v.tab);
    window.scrollTo(0, keep ? y : 0);
    centerRows();
  }
  // امروز وسط می‌ماند؛ در بقیه ردیف‌ها تب انتخاب‌شده وسط می‌آید. اگر تب انتخابی دیده نشود (مثلاً بعد از کشیدن انگشت) همان وسط می‌آید.
  function centerRows() {
    document.querySelectorAll('.chiprow, .tabs').forEach((row) => {
      if (row.scrollWidth <= row.clientWidth + 2) return;
      const cen = (el) => { const a = el.getBoundingClientRect(), b = row.getBoundingClientRect(); row.scrollLeft += (a.left + a.width / 2) - (b.left + b.width / 2); };
      const on = row.querySelector('.on'), today = row.id === 'dayTabs' ? document.getElementById('todayChip') : null;
      if (today) cen(today);
      if (on) {
        const a = on.getBoundingClientRect(), b = row.getBoundingClientRect();
        if (!today || a.left < b.left || a.right > b.right) cen(on);
      }
    });
  }

  // mode: undefined = صفحه لیگ | 'today' = امروز در صفحه اصلی | 'view' = فقط نمایش
  function matchRow(m, mode) {
    const sc = m.played
      ? '<span class="score"><b>' + fa(m.hg) + '</b><i>:</i><b>' + fa(m.ag) + '</b></span>'
      : m.state ? '<span class="score st ' + m.state + '"><b>' + STATE[m.state] + '</b></span>'
      : '<span class="score off"><b>–</b></span>';
    const meta = [];
    if (m.played && m.hp != null) meta.push('پنالتی ' + fa(m.hp) + ' - ' + fa(m.ap));
    if (mode === 'today' || mode === 'view') { if (m.time) meta.push('ساعت ' + L.fmtTime(m.time)); }
    else if (m.date) meta.push(L.dayInfo(m.date, m.time));
    return '<button class="match" data-act="' + (mode === 'view' ? 'viewMatch' : 'openMatch') + '" data-id="' + m.id + '"' + (mode === 'today' ? ' data-home="1"' : '') + '><span class="mt">' + tn(m.home) + '</span>' + sc + '<span class="mt away">' + tn(m.away) + '</span>' +
      (meta.length ? '<span class="meta">' + meta.join(' • ') + '</span>' : '') + '</button>';
  }

  function chipLabel(d, today) {
    const diff = L.diffDays(d, today);
    const j = L.toJalali(d);
    const top = diff === 0 ? 'امروز' : diff === -1 ? 'دیروز' : diff === 1 ? 'فردا' : L.weekday(d);
    return '<span>' + top + '</span><small>' + fa(j.d) + ' ' + L.JM[j.m - 1] + '</small>';
  }

  function vHome() {
    const today = L.today();
    let h = head('لیگ فوتسال', null, L.weekday(today) + ' ' + L.fmtDate(today)) + '<main class="page">';
    if (!db.leagues.length) return { tab: 'home', html: h + welcome() + '</main>' };
    const dates = Array.from(new Set(db.matches.filter((m) => m.date && !m.bye).map((m) => m.date))).sort();
    const prev = dates.filter((d) => d < today).slice(-3);
    const next = dates.filter((d) => d > today).slice(0, 3);
    const day = prev.concat([today], next).indexOf(ui.homeDay) >= 0 ? ui.homeDay : today;
    const ghost = '<span class="chip ghost" aria-hidden="true"><span>–</span><small>&nbsp;</small></span>';
    const pad = (n) => new Array(n + 1).join(ghost);
    const chip = (d) => '<button class="chip' + (d === day ? ' on' : '') + (d === today ? ' today' : '') + '" data-act="homeDay" data-d="' + d + '"' + (d === today ? ' id="todayChip"' : '') + '>' + chipLabel(d, today) + '</button>';
    h += heroToday(today, dates);
    // امروز همیشه وسط است: ۳ روز بازی‌دار قبل، امروز، ۳ روز بازی‌دار بعد (جای خالی با تب کم‌رنگ پر می‌شود)
    h += '<div class="chiprow" id="dayTabs" role="tablist">' + pad(3 - prev.length) + prev.map(chip).join('') + chip(today) + next.map(chip).join('') + pad(3 - next.length) + '</div>';
    h += '<p class="daytitle"><b>' + L.weekday(day) + '</b> ' + L.fmtDate(day) + '</p>';
    const ms = db.matches.filter((m) => m.date === day && !m.bye);
    if (!ms.length) {
      h += '<div class="card">' + empty(day === today ? 'امروز بازی‌ای ثبت نشده' : 'بازی‌ای در این روز نیست', day === today ? 'برای نمایش بازی‌ها، از صفحه لیگ تاریخ بازی‌ها را تعیین کن.' : '') + '</div>';
    } else {
      if (day !== today) h += '<p class="note hint">فقط نتیجه بازی‌های امروز از این صفحه ثبت می‌شود. برای ویرایش بازی‌های دیگر، وارد صفحه لیگ شو.</p>';
      const by = {};
      ms.forEach((m) => { (by[m.leagueId] = by[m.leagueId] || []).push(m); });
      sortedLeagues().forEach((lg) => {
        if (!by[lg.id]) return;
        h += '<h3 class="sub">' + esc(lg.name) + '</h3>' + by[lg.id].sort((a, b) => (a.time || '99:99').localeCompare(b.time || '99:99') || a.round - b.round).map((m) => matchRow(m, day === today ? 'today' : 'view')).join('');
      });
    }
    const post = db.matches.filter((m) => m.state === 'postponed' && m.home && m.away && !(m.date === day))
      .sort((a, b) => (a.date || '9').localeCompare(b.date || '9'));
    if (post.length) {
      h += '<h3 class="sub">بازی‌های معوقه <small>(' + fa(post.length) + ')</small></h3>' + post.map((m) => {
        const lg = league(m.leagueId);
        return '<div class="postwrap">' + matchRow(m, m.date === today ? 'today' : 'view') + '<span class="postinfo">' + esc(lg ? lg.name : '') + (m.date ? ' • موعد قبلی: ' + L.fmtDate(m.date) : '') + '</span></div>';
      }).join('');
    }
    const act = sortedLeagues().filter((l) => l.status !== 'finished');
    if (act.length) {
      h += '<h3 class="sub">لیگ‌های فعال</h3>';
      act.forEach((lg) => {
        let line = FORMATS[lg.format];
        if (lg.format === 'league') {
          const st = L.standings(lg.teamIds, db.matches.filter((m) => m.leagueId === lg.id));
          if (st.length && st[0].p > 0) line = 'صدرنشین: ' + (team(st[0].teamId) ? team(st[0].teamId).name : '') + ' (' + fa(st[0].pts) + ' امتیاز)';
        }
        h += '<a class="tile" href="#/league/' + lg.id + '"><span class="grow"><b>' + esc(lg.name) + '</b><small>' + esc(line) + '</small></span>' + ring(progress(lg)) + '</a>';
      });
    }
    return { tab: 'home', html: h + '</main>' };
  }

  /* --- تیم‌ها --- */
  function teamItems() {
    const q = ui.q.trim();
    let list;
    if (q) list = db.teams.filter((t) => t.name.indexOf(q) >= 0);
    else if (ui.teamTab === 'none') list = db.teams.filter((t) => !league(t.leagueId));
    else list = db.teams.filter((t) => t.leagueId === ui.teamTab);
    list = list.slice().sort((a, b) => a.name.localeCompare(b.name, 'fa'));
    if (!list.length) return empty(q ? 'تیمی پیدا نشد' : 'هنوز تیمی در این لیگ نیست', q ? '' : 'با دکمه پایین یک تیم به این لیگ اضافه کن.');
    return list.map((t) => '<div class="item"><a class="item-main" href="#/team/' + t.id + '"><span class="av">' + esc((t.name.trim()[0] || '؟')) + '</span><span class="grow"><b>' + esc(t.name) + '</b><small>' + fa(players(t.id).length) + ' بازیکن' + (q ? ' • ' + esc(league(t.leagueId) ? league(t.leagueId).name : 'بدون لیگ') : '') + '</small></span></a>' +
      '<button class="icon-btn" data-act="editTeam" data-id="' + t.id + '" aria-label="ویرایش">' + icon('edit') + '</button>' +
      '<button class="icon-btn bad" data-act="delTeam" data-id="' + t.id + '" aria-label="حذف">' + icon('trash') + '</button></div>').join('');
  }
  function leagueNote(lg) {
    const up = L.pickLeague(db, lg.level - 1, lg.id), down = L.pickLeague(db, lg.level + 1, lg.id);
    return '<p class="note lnote">سطح ' + fa(lg.level) + ' • لیگ بالاتر: ' + (up ? esc(up.name) : '—') + ' • لیگ پایین‌تر: ' + (down ? esc(down.name) : '—') + '</p>';
  }
  function vTeams() {
    const lgs = sortedLeagues();
    const none = db.teams.filter((t) => !league(t.leagueId));
    const keys = lgs.map((l) => l.id).concat(none.length ? ['none'] : []);
    if (!ui.teamTab || keys.indexOf(ui.teamTab) < 0) ui.teamTab = keys[0] || null;
    let h = head('تیم‌ها') + '<main class="page has-dock">';
    if (!lgs.length) {
      h += empty('اول یک لیگ بساز', 'هر تیم باید عضو یک لیگ باشد. بعد از ساخت لیگ، تیم‌ها را اینجا اضافه کن.', '<a class="btn" href="#/leagues">ساخت لیگ</a>');
      return { tab: 'teams', html: h + '</main>' };
    }
    h += '<p class="note" style="margin:0 2px 8px">' + fa(lgs.length) + ' لیگ • ' + fa(db.teams.length) + ' تیم</p>';
    h += '<label class="search">' + icon('search') + '<input data-input="teamSearch" placeholder="جستجوی تیم در همه لیگ‌ها" value="' + esc(ui.q) + '"></label>';
    h += '<div class="chiprow" id="teamTabs">' + keys.map((k) => {
      const l = league(k);
      const n = k === 'none' ? none.length : db.teams.filter((t) => t.leagueId === k).length;
      return '<button class="chip' + (k === ui.teamTab ? ' on' : '') + '" data-act="teamTab" data-t="' + k + '"><span>' + (l ? esc(l.name) : 'بدون لیگ') + '</span><small>' + fa(n) + ' تیم</small></button>';
    }).join('') + '</div>';
    const cur = league(ui.teamTab);
    h += '<div id="teamNote">' + (cur ? leagueNote(cur) : '') + '</div><div id="teamList">' + teamItems() + '</div></main>';
    h += fab('addTeam', 'افزودن تیم');
    return { tab: 'teams', html: h };
  }
  function vTeam(id) {
    const t = team(id);
    if (!t) return { tab: 'teams', html: head('تیم', '#/teams') + '<main class="page">' + empty('این تیم پیدا نشد', '', '<a class="btn" href="#/teams">بازگشت</a>') + '</main>' };
    const pl = players(id);
    const lg = league(t.leagueId);
    let h = head(t.name, '#/teams') + '<main class="page has-dock"><div class="card"><div class="kv"><span>لیگ</span><span>' + (lg ? '<a href="#/league/' + lg.id + '">' + esc(lg.name) + '</a>' : '—') + '</span></div></div><h3 class="sub">کادر فنی</h3><div class="card">';
    ROLES.forEach(([k, l]) => { h += '<div class="kv"><span>' + l + '</span><span>' + (t.staff && t.staff[k] ? esc(t.staff[k]) : '—') + '</span></div>'; });
    h += '<div class="row-btns"><button class="btn sec" data-act="editStaff" data-id="' + id + '">' + icon('edit') + ' ویرایش کادر فنی</button></div></div>';
    h += '<h3 class="sub">بازیکنان (' + fa(pl.length) + ' از ' + fa(MAX_PLAYERS) + ')</h3>';
    h += pl.length ? pl.map((p) => '<div class="item"><span class="num">' + fa(p.number) + '</span><span class="grow"><b>' + esc(p.name) + '</b><small>' + esc(p.pos) + ' • ' + fa(goalsOf(p.id)) + ' گل</small></span>' +
      '<button class="icon-btn" data-act="editPlayer" data-id="' + p.id + '" aria-label="ویرایش">' + icon('edit') + '</button>' +
      '<button class="icon-btn bad" data-act="delPlayer" data-id="' + p.id + '" aria-label="حذف">' + icon('trash') + '</button></div>').join('') : '<div class="card">' + empty('بازیکنی ثبت نشده', 'تا ۳۰ بازیکن می‌توانی اضافه کنی.') + '</div>';
    return { tab: 'teams', html: h + '</main>' + fab('addPlayer', 'افزودن بازیکن', ' data-id="' + id + '"' + (pl.length >= MAX_PLAYERS ? ' disabled' : '')) };
  }

  /* --- لیگ‌ها --- */
  function vLeagues() {
    let h = head('لیگ‌ها') + '<main class="page has-dock">';
    if (!db.leagues.length) h += empty('هنوز لیگی نساخته‌ای', 'اول لیگ را بساز، بعد از بخش تیم‌ها تیم‌ها را به آن اضافه کن.');
    sortedLeagues().forEach((lg) => {
      const p = L.podium(db, lg);
      h += '<div class="tile"><a class="item-main" href="#/league/' + lg.id + '"><span class="av">' + fa(lg.level) + '</span><span class="grow"><b>' + esc(lg.name) + '</b>' +
        '<small>' + esc([lg.province, lg.venue].filter(Boolean).join(' • ') || FORMATS[lg.format]) + '</small>' +
        '<span class="chips"><span class="badge">' + FORMATS[lg.format] + '</span><span class="badge ' + lg.status + '">' + STATUS[lg.status] + '</span><span class="badge">' + fa(lg.teamIds.length) + ' تیم</span></span>' +
        (p.champion ? '<small>قهرمان: ' + tn(p.champion) + '</small>' : '') + '</span>' + ring(progress(lg)) + '</a>' +
        '<button class="icon-btn" data-act="editLeague" data-id="' + lg.id + '" aria-label="ویرایش">' + icon('edit') + '</button>' +
        '<button class="icon-btn bad" data-act="delLeague" data-id="' + lg.id + '" aria-label="حذف">' + icon('trash') + '</button></div>';
    });
    return { tab: 'leagues', html: h + '</main>' + fab('addLeague', 'افزودن لیگ') };
  }

  function pendingIds(ms) { return ms.filter((m) => !m.played && !m.bye).map((m) => m.id).join(','); }
  function roundHead(title, ids, poster) {
    const pb = poster ? '<button class="link" data-act="poster" data-k="' + poster.k + '" data-r="' + poster.r + '" data-g="' + (poster.g || '') + '">پوستر</button>' : '';
    return '<h4><span>' + title + '</span><span>' + pb + (ids ? '<button class="link" data-act="roundDate" data-ids="' + ids + '">تعیین تاریخ</button>' : '') + '</span></h4>';
  }
  const hasResult = (rm) => rm.some((m) => m.played && !m.bye);
  function roundsBlock(ms, gid) {
    const rs = Array.from(new Set(ms.map((m) => m.round))).sort((a, b) => a - b);
    return rs.map((r) => { const rm = ms.filter((m) => m.round === r); return '<div class="round">' + roundHead('هفته ' + fa(r), pendingIds(rm), hasResult(rm) ? { k: 'week', r, g: gid } : null) + rm.map((m) => matchRow(m)).join('') + '</div>'; }).join('');
  }
  function koBlock(ms) {
    const R = L.koRounds(ms);
    let h = '<h3 class="sub">مرحله حذفی</h3>';
    const third = ms.find((m) => m.stage === 'third');
    for (let r = 0; r < R; r++) {
      const rm = ms.filter((m) => m.stage === 'ko' && m.round === r).sort((a, b) => a.pos - b.pos);
      if (r === R - 1 && third) h += '<div class="round">' + roundHead(third.roundName, pendingIds([third])) + matchRow(third) + '</div>';
      h += '<div class="round">' + roundHead(rm[0].roundName, pendingIds(rm), hasResult(rm.concat(r === R - 1 && third ? [third] : [])) ? { k: 'ko', r } : null) + rm.map((m) => m.bye ? '<div class="bye">' + tn(m.home || m.away) + ' — بای (مستقیم صعود کرد)</div>' : matchRow(m)).join('') + '</div>';
    }
    return h;
  }
  function roundGroups(ms) {
    const out = [];
    const base = ms.filter((m) => m.stage === 'league' || m.stage === 'group');
    Array.from(new Set(base.map((m) => m.round))).sort((a, b) => a - b).forEach((r) => out.push(base.filter((m) => m.round === r)));
    const R = L.koRounds(ms);
    for (let r = 0; r < R; r++) out.push(ms.filter((m) => !m.bye && ((m.stage === 'ko' && m.round === r) || (m.stage === 'third' && r === R - 1))));
    return out.filter((g) => g.length);
  }
  function tabMatches(lg) {
    const ms = db.matches.filter((m) => m.leagueId === lg.id);
    const hasGroups = lg.format === 'groups' && lg.groups.length > 0;
    if (!ms.length && !hasGroups) {
      if (lg.teamIds.length < 2) return empty('تیم کافی نیست', 'اول از بخش تیم‌ها، تیم‌های این لیگ را اضافه کن (حداقل ۲ تیم). بعد برگرد و قرعه‌کشی کن.', '<a class="btn" href="#/teams">رفتن به تیم‌ها</a>');
      return empty('بازی‌ای ساخته نشده', fa(lg.teamIds.length) + ' تیم در این لیگ ثبت شده است. می‌توانی بازی‌ها را خودکار بچینی یا خودت وارد کنی.', '<button class="btn" data-act="draw" data-id="' + lg.id + '">' + (lg.format === 'league' ? 'ساخت بازی‌ها' : 'قرعه‌کشی') + '</button>');
    }
    let h = '';
    if (lg.format === 'league') h += roundsBlock(ms.filter((m) => m.stage === 'league'));
    const noGroupGames = lg.format === 'groups' && !ms.some((m) => m.stage === 'group');
    const ko = ms.filter((m) => m.stage === 'ko');
    if (lg.format === 'groups') {
      const keys = lg.groups.map((g) => g.id).concat(['ko']);
      if (keys.indexOf(ui.gTab) < 0) ui.gTab = keys[0];
      h += '<div class="chiprow">' + lg.groups.map((g) => {
        const gm = ms.filter((m) => m.stage === 'group' && m.groupId === g.id);
        return '<button class="chip' + (ui.gTab === g.id ? ' on' : '') + '" data-act="gTab" data-t="' + g.id + '"><span>' + esc(g.name) + '</span><small>' + (gm.length ? fa(gm.filter((m) => m.played).length) + ' از ' + fa(gm.length) + ' بازی' : fa(g.teamIds.length) + ' تیم') + '</small></button>';
      }).join('') + '<button class="chip' + (ui.gTab === 'ko' ? ' on' : '') + '" data-act="gTab" data-t="ko"><span>حذفی</span><small>' + (ko.length ? fa(L.koRounds(ms)) + ' دور' : 'ساخته نشده') + '</small></button></div>';
      if (ui.gTab === 'ko') {
        if (ko.length) h += koBlock(ms);
        else if (noGroupGames) h += '<div class="card note-card"><p class="note">اول بازی‌های گروهی را بساز.</p></div>';
        else {
          const done = ms.filter((m) => m.stage === 'group').every(L.settled);
          h += '<div class="card note-card">' + (done ? '<button class="btn block" data-act="makeKo" data-id="' + lg.id + '">ساخت مرحله حذفی</button>' : '<p class="note">بعد از پایان بازی‌های گروهی، مرحله حذفی را از اینجا می‌سازی (خودکار یا دستی).</p>') + '</div>';
        }
      } else {
        const g = lg.groups.find((x) => x.id === ui.gTab);
        const gm = ms.filter((m) => m.stage === 'group' && m.groupId === g.id);
        h += gm.length ? roundsBlock(gm, g.id) : '<div class="card"><p class="note">' + g.teamIds.map((id) => tn(id)).join('، ') + '</p></div>';
      }
    } else if (ko.length) h += koBlock(ms);
    h += '<div class="row-btns">';
    if (noGroupGames) h += '<button class="btn" data-act="autoGroupMatches" data-id="' + lg.id + '">ساخت خودکار بازی‌های گروهی</button>';
    if (lg.format !== 'knockout') h += '<button class="btn sec" data-act="addWeek" data-id="' + lg.id + '">' + icon('plus') + ' ورود بازی‌های یک هفته</button>';
    if (ms.some((m) => !m.bye)) h += '<button class="btn sec" data-act="autoDates" data-id="' + lg.id + '">تاریخ‌گذاری خودکار</button>';
    if (!ms.some((m) => m.played && !m.bye)) h += '<button class="btn sec" data-act="draw" data-id="' + lg.id + '">قرعه‌کشی مجدد</button>';
    return h + '</div>';
  }

  function tbl(rows, o) {
    o = o || {};
    const n = rows.length;
    const sg = (x) => '\u200E' + (x > 0 ? '+' : '') + fa(x);
    return '<div class="tw"><table class="tbl"><thead><tr><th>#</th><th class="tn">تیم</th><th>بازی</th><th>برد</th><th>باخت</th><th>مساوی</th><th>زده</th><th>خورده</th><th>تفاضل</th><th>امتیاز</th></tr></thead><tbody>' +
      rows.map((r, i) => {
        const cls = i < (o.adv || 0) || i < (o.up || 0) ? 'adv' : (o.down && i >= n - o.down) ? 'down' : '';
        return '<tr class="' + cls + '"><td>' + fa(i + 1) + '</td><td class="tn">' + tn(r.teamId) + '</td><td>' + fa(r.p) + '</td><td>' + fa(r.w) + '</td><td>' + fa(r.l) + '</td><td>' + fa(r.d) + '</td><td>' + fa(r.gf) + '</td><td>' + fa(r.ga) + '</td><td class="gd">' + sg(r.gd) + '</td><td class="pts">' + fa(r.pts) + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }
  function podiumCard(lg) {
    const p = L.podium(db, lg);
    const rows = [['قهرمان', p.champion], ['نایب‌قهرمان', p.runnerUp], ['تیم سوم', p.third], ['تیم چهارم', p.fourth]];
    return '<h3 class="sub">رده‌بندی نهایی</h3><div class="card">' + (p.champion ? rows.map((r, i) => r[1] ? '<div class="pod"><span class="rk r' + (i + 1) + '">' + fa(i + 1) + '</span><span class="l">' + r[0] + '</span><b>' + tn(r[1]) + '</b></div>' : '').join('') : '<p class="note">بعد از پایان لیگ، قهرمان و تیم‌های دوم تا چهارم اینجا نمایش داده می‌شوند.</p>') + '</div>';
  }
  function tabTable(lg) {
    const ms = db.matches.filter((m) => m.leagueId === lg.id);
    if (lg.format === 'league') {
      const up = lg.promote || 0, down = lg.relegate || 0;
      return '<div class="card flush">' + tbl(L.standings(lg.teamIds, ms), { up, down }) + '</div>' +
        (up || down ? '<p class="legend">' + (up ? 'نوار سبز: صعود به لیگ بالاتر (' + fa(up) + ' تیم)' : '') + (up && down ? ' • ' : '') + (down ? 'نوار قرمز: سقوط به لیگ پایین‌تر (' + fa(down) + ' تیم)' : '') + '</p>' : '') + podiumCard(lg);
    }
    if (lg.format === 'groups') {
      if (!lg.groups.length) return empty('گروه‌بندی انجام نشده', 'اول از تب بازی‌ها قرعه‌کشی کن.');
      return lg.groups.map((g) => '<h3 class="sub">' + esc(g.name) + '</h3><div class="card flush">' + tbl(L.standings(g.teamIds, ms.filter((m) => m.stage === 'group' && m.groupId === g.id)), { adv: L.groupAdvance(lg, g) }) + '</div>').join('') +
        '<p class="legend">نوار سبز: تیم‌های صعودکننده • جمعاً ' + fa(lg.groups.reduce((t, g) => t + L.groupAdvance(lg, g), 0)) + ' تیم</p><div class="row-btns" style="margin:-4px 0 8px"><button class="btn sec" data-act="advSetup" data-id="' + lg.id + '">تنظیم تعداد صعودکنندگان هر گروه</button></div>' + podiumCard(lg);
    }
    return podiumCard(lg);
  }
  function tabStats(lg) {
    const sc = L.topScorers(db, lg.id).slice(0, 10);
    const mv = L.mvpCounts(db, lg.id).slice(0, 10);
    const st = L.cardState(db, lg.id, null);
    const banned = Object.keys(st).filter((id) => st[id].pend > 0 && player(id) && lg.teamIds.indexOf(player(id).teamId) >= 0);
    const carded = Object.keys(st).filter((id) => player(id) && (st[id].y || st[id].yy || st[id].r)).sort((a, b) => (st[b].r + st[b].yy) * 10 + st[b].y - ((st[a].r + st[a].yy) * 10 + st[a].y)).slice(0, 15);
    const row = (r, i, unit) => { const p = player(r.playerId); return p ? '<div class="pod"><span class="rk r' + Math.min(i + 1, 4) + '">' + fa(i + 1) + '</span><span class="grow"><b>' + esc(p.name) + '</b><small>' + tn(p.teamId) + '</small></span><b>' + fa(r.n) + ' ' + unit + '</b></div>' : ''; };
    let h = '<h3 class="sub">محرومان بازی بعد</h3><div class="card">' + (banned.length ? banned.map((id) => '<div class="pod"><span class="num sm">' + fa(player(id).number) + '</span><span class="grow"><b>' + esc(player(id).name) + '</b><small>' + tn(player(id).teamId) + '</small></span><b class="bad-t">' + fa(st[id].pend) + ' جلسه</b></div>').join('') : '<p class="note">فعلاً بازیکن محرومی نیست.</p>') +
      '<p class="note" style="margin-top:8px">قانون: هر ۳ زرد = ۱ جلسه • قرمز مستقیم = ۲ جلسه • دو زرد و قرمز = ۱ جلسه</p></div>';
    h += '<h3 class="sub">آقای گل</h3><div class="card">' + (sc.length ? sc.map((r, i) => row(r, i, 'گل')).join('') : '<p class="note">گلزنان با ثبت نتیجه بازی‌ها پر می‌شوند.</p>') + '</div>';
    h += '<h3 class="sub">بهترین بازیکن بازی‌ها</h3><div class="card">' + (mv.length ? mv.map((r, i) => row(r, i, 'بار')).join('') : '<p class="note">در هر بازی می‌توانی بهترین بازیکن زمین را انتخاب کنی.</p>') + '</div>';
    h += '<h3 class="sub">کارت‌ها</h3><div class="card">' + (carded.length ? carded.map((id) => '<div class="pod"><span class="grow"><b>' + esc(player(id).name) + '</b><small>' + tn(player(id).teamId) + '</small></span><span class="cd y">' + fa(st[id].y) + '</span><span class="cd r">' + fa(st[id].yy + st[id].r) + '</span></div>').join('') + '<p class="legend" style="margin:6px 0 0">زرد و قرمز (اخراج) هر بازیکن</p>' : '<p class="note">کارتی ثبت نشده است.</p>') + '</div>';
    const pls = db.players.filter((p) => lg.teamIds.indexOf(p.teamId) >= 0);
    h += '<h3 class="sub">بهترین بازیکن لیگ</h3><div class="card"><label class="field"><span>انتخاب نهایی (مثلاً بعد از پایان لیگ)</span><select data-change="bestPlayer" data-id="' + lg.id + '"><option value="">— انتخاب نشده —</option>' +
      db.teams.filter((t) => lg.teamIds.indexOf(t.id) >= 0).map((t) => '<optgroup label="' + esc(t.name) + '">' + players(t.id).map((p) => '<option value="' + p.id + '"' + (lg.bestPlayerId === p.id ? ' selected' : '') + '>' + esc(p.name) + '</option>').join('') + '</optgroup>').join('') + '</select></label>' +
      (mv[0] && player(mv[0].playerId) ? '<p class="note">پیشنهاد: ' + esc(player(mv[0].playerId).name) + ' (' + fa(mv[0].n) + ' بار بهترین بازیکن بازی)</p>' : '') + (pls.length ? '' : '<p class="note">برای انتخاب، اول بازیکن‌های تیم‌ها را اضافه کن.</p>') + '</div>';
    return h;
  }
  function tabInfo(lg) {
    const kv = (a, b) => '<div class="kv"><span>' + a + '</span><span>' + b + '</span></div>';
    const plan = L.promotionPlan(db, lg);
    let promo = '';
    if (lg.format === 'league' && (lg.promote || lg.relegate)) {
      const names = (ids) => ids.map((id) => tn(id)).join('، ') || '—';
      promo = '<h3 class="sub">صعود و سقوط</h3><div class="card">' +
        kv('صعود به ' + (plan.upLeague ? esc(plan.upLeague.name) : 'لیگ بالاتر'), plan.ready ? names(plan.up) : fa(lg.promote) + ' تیم اول') +
        kv('سقوط به ' + (plan.downLeague ? esc(plan.downLeague.name) : 'لیگ پایین‌تر'), plan.ready ? names(plan.down) : fa(lg.relegate) + ' تیم آخر') +
        (lg.promotionApplied ? '<p class="note">صعود و سقوط اعمال شده است.</p>' : plan.ready ? '<div class="row-btns"><button class="btn" data-act="applyPromo" data-id="' + lg.id + '">اعمال صعود و سقوط</button></div>' : '<p class="note">بعد از پایان همه بازی‌ها می‌توانی صعود و سقوط را اعمال کنی.</p>') + '</div>';
    }
    return '<div class="card">' + kv('سطح لیگ', fa(lg.level)) + kv('نوع لیگ', FORMATS[lg.format]) + kv('وضعیت', STATUS[lg.status]) + kv('استان', esc(lg.province) || '—') + kv('شهر', esc(lg.city) || '—') + kv('سالن', esc(lg.venue) || '—') + kv('تاریخ برگزاری', lg.date ? L.fmtDate(lg.date) : '—') + kv('تعداد تیم', fa(lg.teamIds.length)) +
      (lg.format === 'groups' ? kv('تعداد گروه', fa(lg.groupCount)) + kv('صعود از هر گروه (پیش‌فرض)', fa(lg.advance)) : '') +
      (lg.format !== 'knockout' ? kv('دوره', lg.double ? 'رفت و برگشت' : 'یک دوره') : '') +
      (lg.bestPlayerId && player(lg.bestPlayerId) ? kv('بهترین بازیکن', esc(player(lg.bestPlayerId).name)) : '') + '</div>' + promo + podiumCard(lg) +
      '<div class="row-btns"><button class="btn sec" data-act="editLeague" data-id="' + lg.id + '">' + icon('edit') + ' ویرایش لیگ</button><button class="btn danger" data-act="delLeague" data-id="' + lg.id + '">' + icon('trash') + ' حذف لیگ</button></div>';
  }
  /* --- پوستر --- */
  const posterOf = (lg) => Object.assign({}, window.Poster.DEF, lg.poster || {});
  function posterItems(lg) {
    const ms = db.matches.filter((m) => m.leagueId === lg.id && !m.bye);
    const items = [];
    const base = ms.filter((m) => m.stage === 'league' || m.stage === 'group');
    Array.from(new Set(base.map((m) => m.round))).sort((a, b) => a - b).forEach((r) => {
      const rm = base.filter((m) => m.round === r), done = rm.filter((m) => m.played).length;
      if (done) items.push({ k: 'week', r, g: '', t: 'نتایج هفته ' + fa(r), s: fa(done) + ' از ' + fa(rm.length) + ' بازی ثبت شده' + (lg.format === 'groups' ? ' • همه گروه‌ها' : '') });
    });
    const R = L.koRounds(db.matches.filter((m) => m.leagueId === lg.id));
    for (let r = 0; r < R; r++) {
      const rm = ms.filter((m) => (m.stage === 'ko' && m.round === r) || (m.stage === 'third' && r === R - 1)), done = rm.filter((m) => m.played).length;
      if (done) items.push({ k: 'ko', r, g: '', t: 'نتایج ' + (rm[0].roundName || 'حذفی'), s: fa(done) + ' از ' + fa(rm.length) + ' بازی ثبت شده' });
    }
    const tables = [];
    if (lg.format === 'league' && lg.teamIds.length) tables.push({ k: 'table', r: '', g: '', t: 'جدول لیگ', s: fa(lg.teamIds.length) + ' تیم' });
    if (lg.format === 'groups') lg.groups.forEach((g) => tables.push({ k: 'table', r: '', g: g.id, t: 'جدول ' + g.name, s: fa(g.teamIds.length) + ' تیم' }));
    return { results: items, tables };
  }
  // فهرست هفته‌ها (و دورهای حذفی) برای پوستر اعلام بازی‌ها
  function annWeeks(lg) {
    const ms = db.matches.filter((m) => m.leagueId === lg.id && !m.bye);
    const out = [];
    const base = ms.filter((m) => m.stage === 'league' || m.stage === 'group');
    Array.from(new Set(base.map((m) => m.round))).sort((a, b) => a - b).forEach((r) => {
      const rm = base.filter((m) => m.round === r);
      out.push({ v: 'w:' + r, t: 'هفته ' + fa(r) + ' (' + fa(rm.length) + ' بازی)' });
    });
    const R = L.koRounds(db.matches.filter((m) => m.leagueId === lg.id));
    for (let r = 0; r < R; r++) {
      const rm = ms.filter((m) => (m.stage === 'ko' && m.round === r) || (m.stage === 'third' && r === R - 1));
      if (rm.length) out.push({ v: 'k:' + r, t: (rm[0].roundName || 'مرحله حذفی') + ' (' + fa(rm.length) + ' بازی)' });
    }
    return out;
  }
  function annCard(lg) {
    const w = annWeeks(lg);
    if (!w.length) return '<div class="card"><p class="note">بعد از ساخت بازی‌ها (قرعه‌کشی)، پوستر اعلام بازی‌های هر هفته اینجا ساخته می‌شود.</p></div>';
    if (!ui.annSel || !w.some((x) => x.v === ui.annSel)) ui.annSel = w[0].v;
    const where = [lg.venue, lg.city || lg.province].filter(Boolean).join('، ');
    return '<div class="card"><p class="note" style="margin-bottom:8px">همه بازی‌های هفته (در لیگ گروهی: همه گروه‌ها، حتی اگر در چند روز باشند) با تیم‌ها، روز، تاریخ و ساعت' + (where ? ' و محل برگزاری (' + esc(where) + ')' : '') + ' روی یک پوستر می‌آید.' + (where ? '' : ' سالن و شهر را از «ویرایش لیگ» وارد کن.') + '</p>' +
      '<label class="field"><span>هفته مورد نظر</span><select id="ann-sel" data-change="annSel">' + sel(w.map((x) => [x.v, x.t]), ui.annSel) + '</select></label>' +
      '<button class="btn block" data-act="announce" data-id="' + lg.id + '">' + icon('image') + ' ساخت پوستر اعلام بازی‌ها</button></div>';
  }
  function announce() {
    const lg = league(ui.leagueId), v = val('ann-sel') || ui.annSel;
    if (!lg || !v) return;
    const [k, r] = v.split(':');
    ui.poster = { lid: lg.id, spec: { k: k === 'w' ? 'annw' : 'annko', r: parseInt(r, 10), g: '' }, opts: { scorers: false }, canvas: null };
    openPoster();
  }
  function tabPoster(lg) {
    const st = posterOf(lg), th = window.Poster.THEMES[st.theme] || window.Poster.THEMES.blue;
    const it = posterItems(lg);
    const row = (x) => '<div class="item"><span class="av">' + icon('image') + '</span><span class="grow"><b>' + x.t + '</b><small>' + x.s + '</small></span><button class="btn sec" data-act="poster" data-k="' + x.k + '" data-r="' + x.r + '" data-g="' + x.g + '">پوستر</button></div>';
    let h = '<div class="card pbg"><div class="pbg-prev" style="' + (st.bg ? 'background-image:url(' + esc(st.bg) + ');' : 'background:linear-gradient(135deg,' + th[0] + ',' + th[1] + ');') + '"><span>' + esc(st.title || lg.name) + '</span></div><p class="note">همه پوسترهای این لیگ با همین پس‌زمینه، عکس‌ها و متن ساخته می‌شوند.</p><div class="row-btns"><button class="btn" data-act="editPoster" data-id="' + lg.id + '">' + icon('edit') + ' ویرایش پس‌زمینه پوستر</button></div></div>';
    h += '<h3 class="sub">پوستر اعلام بازی‌ها</h3>' + annCard(lg);
    h += '<h3 class="sub">نتایج بازی‌ها</h3>' + (it.results.length ? it.results.map(row).join('') : '<div class="card"><p class="note">بعد از ثبت نتیجه بازی‌ها، پوستر هر هفته اینجا ظاهر می‌شود.</p></div>');
    if (it.tables.length) h += '<h3 class="sub">جدول‌ها</h3>' + it.tables.map(row).join('');
    return h;
  }
  const dispName = (id) => (team(id) ? team(id).name : 'مشخص نشده');
  function scorersOf(m, tid) {
    const cnt = {}, order = [];
    db.events.filter((e) => e.matchId === m.id && e.teamId === tid && (e.type === 'goal' || e.type === 'og')).forEach((e) => {
      const n = e.type === 'og' ? 'گل به خودی' : (player(e.playerId) ? player(e.playerId).name : 'نامشخص');
      if (!cnt[n]) { cnt[n] = 0; order.push(n); }
      cnt[n]++;
    });
    return order.map((n) => n + (cnt[n] > 1 ? ' (' + fa(cnt[n]) + ')' : '')).join('، ');
  }
  function posterContent(lg, sp, o) {
    const ms = db.matches.filter((m) => m.leagueId === lg.id && !m.bye);
    const mrow = (m) => ({ home: dispName(m.home), away: dispName(m.away), played: m.played, hg: m.hg, ag: m.ag, hp: m.hp, ap: m.ap, state: m.state, dateLine: m.date ? L.dayInfo(m.date, m.time) : (m.time ? 'ساعت ' + L.fmtTime(m.time) : ''), hs: o.scorers && m.played ? scorersOf(m, m.home) : '', as: o.scorers && m.played ? scorersOf(m, m.away) : '' });
    const order = (a, b) => (a.date || '9').localeCompare(b.date || '9') || (a.time || '99:99').localeCompare(b.time || '99:99') || (a.pos || 0) - (b.pos || 0);
    const range = (list) => {
      const ds = list.map((m) => m.date).filter(Boolean).sort();
      if (!ds.length) return '';
      return ds[0] === ds[ds.length - 1] ? L.weekday(ds[0]) + ' ' + L.fmtDate(ds[0]) : 'از ' + L.fmtDate(ds[0]) + ' تا ' + L.fmtDate(ds[ds.length - 1]);
    };
    if (sp.k === 'annw' || sp.k === 'annko') {
      const R = L.koRounds(db.matches.filter((m) => m.leagueId === lg.id));
      const list = sp.k === 'annw' ? ms.filter((m) => (m.stage === 'league' || m.stage === 'group') && m.round === sp.r)
        : ms.filter((m) => (m.stage === 'ko' && m.round === sp.r) || (m.stage === 'third' && sp.r === R - 1));
      const arow = (m) => ({ home: dispName(m.home), away: dispName(m.away), ann: true, played: false, state: m.state, dateLine: m.date ? L.dayInfo(m.date, m.time) : (m.time ? 'ساعت ' + L.fmtTime(m.time) : 'زمان: به‌زودی اعلام می‌شود') });
      let sections;
      if (sp.k === 'annw' && lg.format === 'groups') sections = lg.groups.map((x) => ({ title: x.name, matches: list.filter((m) => m.groupId === x.id).sort(order).map(arow) })).filter((x) => x.matches.length);
      else sections = [{ title: '', matches: list.sort(order).map(arow) }];
      const name = sp.k === 'annw' ? 'هفته ' + fa(sp.r) : ((list[0] && list[0].roundName) || 'مرحله حذفی');
      return { heading: 'اعلام بازی‌های ' + name, sub: range(list), venue: [lg.venue, lg.city || lg.province].filter(Boolean).join(' • '), sections };
    }
    if (sp.k === 'week') {
      const g = sp.g ? lg.groups.find((x) => x.id === sp.g) : null;
      const list = ms.filter((m) => (m.stage === 'league' || m.stage === 'group') && m.round === sp.r && (!g || m.groupId === g.id));
      let sections;
      if (lg.format === 'groups' && !g) sections = lg.groups.map((x) => ({ title: x.name, matches: list.filter((m) => m.groupId === x.id).sort(order).map(mrow) })).filter((x) => x.matches.length);
      else sections = [{ title: '', matches: list.sort(order).map(mrow) }];
      return { heading: 'نتایج هفته ' + fa(sp.r) + (g ? ' • ' + g.name : ''), sub: range(list), sections };
    }
    if (sp.k === 'ko') {
      const R = L.koRounds(db.matches.filter((m) => m.leagueId === lg.id));
      const list = ms.filter((m) => (m.stage === 'ko' && m.round === sp.r) || (m.stage === 'third' && sp.r === R - 1)).sort(order);
      return { heading: 'نتایج ' + ((list[0] && list[0].roundName) || 'مرحله حذفی'), sub: range(list), sections: [{ title: '', matches: list.map(mrow) }] };
    }
    // جدول
    if (sp.g) {
      const g = lg.groups.find((x) => x.id === sp.g);
      const adv = L.groupAdvance(lg, g);
      const rows = L.standings(g.teamIds, ms.filter((m) => m.stage === 'group' && m.groupId === g.id));
      return { heading: 'جدول ' + g.name, sub: '', table: { rows: rows.map((r, i) => Object.assign({ rank: i + 1, team: dispName(r.teamId), cls: i < adv ? 'adv' : '' }, r)), legend: 'نوار سبز: تیم‌های صعودکننده' } };
    }
    const up = lg.promote || 0, down = lg.relegate || 0;
    const rows = L.standings(lg.teamIds, ms.filter((m) => m.stage === 'league'));
    const n = rows.length;
    const lgd = [up ? 'سبز: صعود' : '', down ? 'قرمز: سقوط' : ''].filter(Boolean).join(' • ');
    return { heading: 'جدول لیگ', sub: '', table: { rows: rows.map((r, i) => Object.assign({ rank: i + 1, team: dispName(r.teamId), cls: i < up ? 'adv' : (down && i >= n - down ? 'down' : '') }, r)), legend: lgd } };
  }

  function leagueHero(lg) {
    const ms = db.matches.filter((m) => m.leagueId === lg.id && !m.bye && m.state !== 'notheld' && m.state !== 'cancelled');
    const done = ms.filter((m) => m.played).length;
    return '<section class="hero sm"><div class="hero-t"><small>سطح ' + fa(lg.level) + ' • ' + FORMATS[lg.format] + '</small><h2>' + STATUS[lg.status] + '</h2><p>' + (ms.length ? fa(done) + ' از ' + fa(ms.length) + ' بازی برگزار شده • ' : '') + fa(lg.teamIds.length) + ' تیم</p></div>' + ring(progress(lg), 'big light') + '<span class="blob b1"></span><span class="blob b2"></span></section>';
  }
  function vLeague(id) {
    const lg = league(id);
    if (!lg) return { tab: 'leagues', html: head('لیگ', '#/leagues') + '<main class="page">' + empty('این لیگ پیدا نشد', '', '<a class="btn" href="#/leagues">بازگشت</a>') + '</main>' };
    if (ui.leagueId !== id) { ui.leagueId = id; ui.tab = 'matches'; ui.gTab = null; }
    const tabs = [['matches', 'بازی‌ها'], ['table', lg.format === 'knockout' ? 'رده‌بندی' : 'جدول'], ['stats', 'آمار'], ['poster', 'پوستر'], ['info', 'اطلاعات']];
    const body = ui.tab === 'table' ? tabTable(lg) : ui.tab === 'stats' ? tabStats(lg) : ui.tab === 'poster' ? tabPoster(lg) : ui.tab === 'info' ? tabInfo(lg) : tabMatches(lg);
    return { tab: 'leagues', html: head(lg.name, '#/leagues') + '<main class="page">' + leagueHero(lg) + '<div class="tabs">' + tabs.map(([k, l]) => '<button data-act="tab" data-t="' + k + '" class="' + (ui.tab === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>' + body + '</main>' };
  }

  const userName = () => [db.user.first, db.user.last].filter(Boolean).join(' ') || (Auth.current() ? Auth.current().username : '');
  const avatar = (u, cls) => '<span class="uav ' + (cls || '') + '">' + (u.photo ? '<img alt="" src="' + esc(u.photo) + '">' : icon('user')) + '</span>';
  function userCard() {
    const u = db.user;
    const kv = (a, b) => '<div class="kv"><span>' + a + '</span><span>' + (b ? b : '—') + '</span></div>';
    return '<section class="ucard"><button class="uhead" data-act="editUser" aria-label="ویرایش پروفایل">' + avatar(u, 'lg') + '<span class="grow"><b>' + (userName() ? esc(userName()) : 'نام شما ثبت نشده') + '</b><small>' + (u.role ? esc(u.role) : 'سمت ثبت نشده') + '</small></span></button>' +
      '<div class="ubody">' + kv('نام', esc(u.first)) + kv('نام خانوادگی', esc(u.last)) + kv('شماره تماس', u.phone ? '<span dir="ltr">' + esc(u.phone) + '</span>' : '') + kv('ایمیل', u.email ? '<span dir="ltr">' + esc(u.email) + '</span>' : '') + kv('سمت', esc(u.role)) +
      '<div class="row-btns"><button class="btn sec" data-act="editUser">' + icon('edit') + ' ویرایش مشخصات</button></div></div></section>';
  }
  /* ---------- ورود ---------- */
  const REASONS = {
    password: 'رمز عبور حساب تو توسط مدیر تغییر کرد. با رمز جدید دوباره وارد شو.',
    username: 'نام کاربری حساب تو توسط مدیر تغییر کرد. دوباره وارد شو.',
    disabled: 'حساب تو غیرفعال شده است.',
    subexpired: 'اشتراک تو به پایان رسیده است. برای تمدید با مدیر اصلی تماس بگیر.',
    substart: 'اشتراک تو هنوز شروع نشده است.',
    forced: 'مدیر تو را از برنامه خارج کرد. دوباره وارد شو.',
    deleted: 'این حساب حذف شده است.',
    expired: 'نشست تو منقضی شده است. دوباره وارد شو.',
    invalid: 'نشست تو معتبر نیست. دوباره وارد شو.',
    logout: 'از برنامه خارج شده‌ای. دوباره وارد شو.'
  };
  Auth.onExpire = (reason) => {
    // انقضای عادی نشست: داده‌ها و تغییرات ارسال‌نشده روی گوشی می‌ماند؛ در موارد دیگر (تغییر رمز، حذف و ...) پاک می‌شود
    resetLocal(reason === 'expired' ? Auth.lastId() : null);
    ui.loginMsg = REASONS[reason] || REASONS.invalid; closeModal(true); closeDrawer(); location.hash = '#/home'; render(false);
  };
  setInterval(() => { Auth.current(); }, 60000);
  function vLoading() {
    return '<main class="login"><section class="lhero"><h1>لیگ فوتسال</h1><p>' + (S.err ? 'ارتباط با سرور برقرار نشد' : 'در حال دریافت اطلاعات...') + '</p></section><section class="lcard" style="text-align:center">' +
      (S.err ? '<p class="lerr">اینترنت را بررسی کن و دوباره تلاش کن.</p><button class="btn" data-act="retrySync">تلاش دوباره</button> <button class="btn sec" data-act="logout">خروج از حساب</button>' : '<div class="spin"></div>') + '</section></main>';
  }
  function vLogin() {
    const feats = ['مدیریت تیم‌ها، لیگ‌ها و جام‌های حذفی', 'ثبت نتیجه، گلزنان و کارت‌ها', 'همه تغییرات پس از تایید مدیر برای همه نمایش داده می‌شود'];
    const msg = ui.loginMsg || (Auth.takeExpired() ? REASONS.expired : '');
    return '<main class="login"><section class="lhero"><svg class="illu" viewBox="0 0 220 150" aria-hidden="true"><rect x="10" y="26" width="200" height="104" rx="16" fill="rgba(255,255,255,.14)" stroke="#fff" stroke-width="3"/><line x1="110" y1="26" x2="110" y2="130" stroke="#fff" stroke-width="3"/><circle cx="110" cy="78" r="20" fill="none" stroke="#fff" stroke-width="3"/><path d="M10 54a24 24 0 0 1 0 48M210 54a24 24 0 0 0 0 48" fill="none" stroke="#fff" stroke-width="3"/><circle cx="160" cy="36" r="17" fill="#fff" stroke="#fff" stroke-width="3"/><path d="M160 29l7 5-3 8h-8l-3-8z" fill="#0B5BD3"/></svg><h1>لیگ فوتسال</h1><p>مدیریت حرفه‌ای لیگ و جام، همه در یک برنامه</p></section>' +
      '<section class="lcard"><h2>ورود به حساب</h2>' +
      '<label class="field"><span>نام کاربری</span><input id="l-user" dir="ltr" inputmode="email" autocomplete="username" autocapitalize="off" spellcheck="false" placeholder="example@gmail.com"></label>' +
      '<label class="field"><span>رمز عبور</span><div class="pw"><input id="l-pass" type="password" dir="ltr" autocomplete="current-password" placeholder="••••••••"><button type="button" class="icon-btn" data-act="togglePw" aria-label="نمایش رمز">' + icon('eye') + '</button></div></label>' +
      '<label class="check"><input type="checkbox" id="l-rem"><span>مرا به خاطر بسپار</span></label>' +
      '<p class="note" style="margin:0 0 4px">اگر تیک نزنی، بعد از ۲۴ ساعت از حساب خارج می‌شوی.</p>' +
      '<p class="lerr" id="l-err" role="alert">' + esc(msg) + '</p>' +
      '<button class="btn wide" id="l-btn" data-act="doLogin">ورود</button>' +
      '<ul class="lfeat">' + feats.map((f) => '<li>' + icon('check') + '<span>' + f + '</span></li>').join('') + '</ul>' +
      '<p class="note" style="text-align:center">حساب کاربری را مدیر اصلی برنامه می‌سازد.</p></section></main>';
  }

  /* ---------- پروفایل ---------- */
  const ACT = { create: ['ایجاد', 'a-create'], edit: ['ویرایش', 'a-edit'], delete: ['حذف', 'a-delete'], result: ['نتیجه', 'a-result'], login: ['ورود', 'a-auth'], logout: ['خروج', 'a-auth'], fail: ['ورود ناموفق', 'a-delete'], other: ['سایر', 'a-auth'] };
  const pad2 = (n) => (n < 10 ? '0' : '') + n;
  function stamp(sec) {
    if (!sec) return '—';
    const d = new Date(sec * 1000);
    const iso = d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
    return L.dayInfo(iso, pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds()));
  }
  const fullName = (u) => [u.first_name, u.last_name].filter(Boolean).join(' ') || u.username || '';
  const loadingBox = () => '<div class="empty"><div class="spin"></div></div>';
  const errBox = () => SV.err ? '<p class="lerr" style="text-align:center">' + esc(SV.err) + '</p>' : '';
  const refreshBtn = () => '<div class="row-btns" style="justify-content:center"><button class="btn sec" data-act="tabRefresh">بروزرسانی</button></div>';

  async function loadTab(more) {
    const t = ui.ptab;
    if (SV.loading) return;
    SV.loading = true; SV.err = '';
    try {
      if (t === 'activity') {
        const r = await Auth.api('activity', { user_id: ui.afUser === 'all' ? 0 : parseInt(ui.afUser, 10), type: ui.afType === 'all' ? '' : ui.afType, offset: more && SV.act ? SV.act.rows.length : 0 });
        if (!r.ok) throw new Error(r.error);
        SV.act = more && SV.act ? { rows: SV.act.rows.concat(r.rows), total: r.total } : r;
      } else if (t === 'users') {
        const r = await Auth.api('users'); if (!r.ok) throw new Error(r.error); SV.users = r.users; if (r.me) Auth.setMe(r.me);
      } else if (t === 'sessions') {
        const r = await Auth.api('sessions'); if (!r.ok) throw new Error(r.error); SV.sessions = r;
      } else if (t === 'approvals') {
        const r = await Auth.api('pending'); if (!r.ok) throw new Error(r.error); SV.pending = r.rows;
      }
      SV.fresh[t] = true;
    } catch (e) {
      if (e.auth) { SV.loading = false; return; }
      SV.err = 'ارتباط با سرور برقرار نشد';
      SV.fresh[t] = true;
    }
    SV.loading = false;
    if (ui.ptab === t && (location.hash.replace(/^#\/?/, '') || 'home').split('/')[0] === 'users') render(true);
  }
  function tabActivity() {
    const mg = canManage(), admin = lvl() === 1, me = Auth.current();
    const types = ['create', 'edit', 'delete', 'result', 'login', 'logout'].concat(admin ? ['fail'] : []);
    const filters = '<div class="grid2 afil">' +
      (mg ? '<label class="field"><span>کاربر</span><select id="af-user" data-change="aFilter"><option value="all">' + (admin ? 'همه کاربران' : 'من و زیرمجموعه‌هایم') + '</option>' + (admin ? '' : '<option value="' + me.id + '"' + (String(ui.afUser) === String(me.id) ? ' selected' : '') + '>خودم</option>') + (SV.users || []).filter((u) => u.role !== 'admin' || admin).map((u) => '<option value="' + u.id + '"' + (String(ui.afUser) === String(u.id) ? ' selected' : '') + '>' + esc(fullName(u)) + '</option>').join('') + '</select></label>' : '') +
      '<label class="field"><span>نوع فعالیت</span><select id="af-type" data-change="aFilter"><option value="all">همه</option>' + types.map((k) => '<option value="' + k + '"' + (ui.afType === k ? ' selected' : '') + '>' + ACT[k][0] + '</option>').join('') + '</select></label></div>';
    const a = SV.act;
    let body;
    if (!SV.fresh.activity && SV.loading) body = loadingBox();
    else if (!a) body = errBox() + refreshBtn();
    else if (!a.rows.length) body = empty('فعالیتی ثبت نشده', 'هر ویرایش، افزودن، حذف و ثبت نتیجه اینجا با تاریخ، روز و ساعت نمایش داده می‌شود.');
    else body = '<ul class="actlist">' + a.rows.map((r) => {
      const t = ACT[r.action] || ACT.other, who = r.display_name || r.username;
      return '<li class="act"><span class="abadge ' + t[1] + '">' + t[0] + '</span><div class="abody"><p>' + esc(r.text) + '</p><small>' + (mg && who ? '<b>' + esc(who) + '</b> • ' : '') + esc(stamp(r.created_at)) + '</small></div></li>';
    }).join('') + '</ul>' + (a.rows.length < a.total ? '<div class="row-btns" style="justify-content:center"><button class="btn sec" data-act="moreAct">نمایش بیشتر (' + fa(a.total - a.rows.length) + ' مورد دیگر)</button></div>' : '');
    return '<p class="note">' + (admin ? 'فعالیت همه کاربران، از جدید به قدیم. زمان‌ها از ساعت سرور ثبت می‌شود.' : mg ? 'فعالیت خودت و زیرمجموعه‌هایت، از جدید به قدیم.' : 'فعالیت‌های حساب خودت، از جدید به قدیم.') + '</p>' + filters + body;
  }

  /* --- تایید تغییرات --- */
  function pendingGroups() {
    const g = {}, order = [];
    (SV.pending || []).forEach((r) => {
      const key = r.user_id + '|' + (r.grp || 'r' + r.id);
      if (!g[key]) { g[key] = { key, uid: r.user_id, user: fullName(r), ids: [], rows: [], t: r.updated_at }; order.push(key); }
      g[key].ids.push(r.id); g[key].rows.push(r); g[key].t = Math.max(g[key].t, r.updated_at);
    });
    return order.map((k) => g[k]);
  }
  function tabApprovals() {
    if (!SV.fresh.approvals && SV.loading) return loadingBox();
    const groups = pendingGroups();
    if (!groups.length) return errBox() + empty('تغییری در انتظار نیست', 'وقتی کاربران چیزی ثبت یا ویرایش کنند، اینجا برای تایید یا رد می‌آید.') + refreshBtn();
    const byUser = {}, uo = [];
    groups.forEach((x) => { if (!byUser[x.uid]) { byUser[x.uid] = []; uo.push(x.uid); } byUser[x.uid].push(x); });
    const OP = { upsert: 'ثبت/ویرایش', delete: 'حذف' };
    return '<p class="note">تا تایید نکنی، این تغییرات فقط روی گوشی خودِ کاربر دیده می‌شود.' + (lvl() === 2 && Auth.current().require_approval ? ' چون خودت هم نیازمند تایید مدیر اصلی هستی، بعد از تایید تو برای او ارسال می‌شود.' : '') + '</p>' + uo.map((uid) => {
      const list = byUser[uid], all = list.reduce((a, x) => a.concat(x.ids), []);
      return '<section class="card"><div class="urow"><span class="av">' + esc((list[0].user || '؟').charAt(0)) + '</span><div class="grow"><b>' + esc(list[0].user) + '</b><small>' + fa(list.length) + ' مورد منتظر تایید</small></div></div>' +
        '<div class="row-btns" style="margin:0 0 8px"><button class="btn" data-act="decide" data-mode="approve" data-ids="' + all.join(',') + '">تایید همه</button><button class="btn danger" data-act="decide" data-mode="reject" data-ids="' + all.join(',') + '">رد همه</button></div>' +
        '<ul class="pdlist">' + list.map((x) => {
          const first = x.rows.find((r) => r.kind !== 'events' && r.kind !== 'awards') || x.rows[0];
          const many = x.rows.filter((r) => r.kind === 'matches').length;
          const label = first.label + (many > 1 && /^(mk|md):/.test(first.grp || '') ? ' (' + fa(many) + ' بازی)' : '');
          return '<li class="pd"><label class="check"><input type="checkbox" class="pd-chk" data-ids="' + x.ids.join(',') + '"><span class="pdt"><span>' + esc(label) + '</span><small>' + esc(OP[first.op] || '') + ' • ' + esc(stamp(x.t)) + '</small></span></label></li>';
        }).join('') + '</ul></section>';
    }).join('') + '<div class="stickybar"><button class="btn" data-act="decideSel" data-mode="approve">تایید انتخاب‌شده‌ها</button><button class="btn danger" data-act="decideSel" data-mode="reject">رد انتخاب‌شده‌ها</button></div>';
  }

  /* --- کاربران --- */
  // گروه‌های دسترسی کاربر سطح ۳ (باید با GROUPS3 در سرور یکی باشد)
  const PGROUPS = [
    ['league', 'ایجاد و ویرایش لیگ‌ها', ['league.create', 'league.edit', 'league.draw', 'league.promote', 'league.poster', 'league.best']],
    ['team', 'ایجاد و ویرایش تیم‌ها', ['team.create', 'team.edit']],
    ['player', 'ایجاد و ویرایش بازیکن‌ها', ['player.create', 'player.edit']],
    ['result', 'ثبت نتایج', ['match.schedule', 'match.result', 'match.result_edit', 'poster.export']]
  ];
  const GROUPED = PGROUPS.reduce((a, g) => a.concat(g[2]), []);
  const permNames = (u) => (u.level === 3 ? PGROUPS.filter((g) => g[2].some((k) => (u.perms || []).indexOf(k) >= 0)).map((g) => g[1].replace('ایجاد و ویرایش ', '').replace('ثبت ', '')).join('، ') || 'بدون دسترسی' : '');
  const daysLeft = (iso) => L.diffDays(iso, L.today());
  function subLine(u) {
    if (!u.sub_start_d && !u.sub_end_d) return 'بدون محدودیت زمانی';
    let t = (u.sub_start_d ? 'از ' + L.fmtDate(u.sub_start_d) + ' ' : '') + (u.sub_end_d ? 'تا ' + L.fmtDate(u.sub_end_d) : '');
    if (u.sub_end_d) { const d = daysLeft(u.sub_end_d); t += d < 0 ? ' (تمام شده)' : d === 0 ? ' (امروز آخرین روز)' : ' (' + fa(d) + ' روز مانده)'; }
    return t;
  }
  function userCardRow(u, sub) {
    const badge = !u.active ? '<span class="abadge a-delete">غیرفعال</span>' : u.sub_state === 'expired' ? '<span class="abadge a-delete">اشتراک تمام شد</span>' : u.sub_state === 'notstarted' ? '<span class="abadge a-edit">شروع نشده</span>' : '<span class="abadge a-create">فعال</span>';
    const admin = lvl() === 1;
    return '<li class="ucardrow' + (sub ? ' sub' : '') + '"><div class="urow"><span class="av">' + esc(fullName(u).charAt(0) || '؟') + '</span><div class="grow"><b>' + esc(fullName(u)) + '</b><small dir="ltr">' + esc(u.username) + '</small></div><span class="abadge a-auth">سطح ' + fa(u.level) + '</span>' + badge + '</div>' +
      (u.level === 2 ? '<div class="kv"><span>اشتراک</span><span>' + esc(subLine(u)) + '</span></div><div class="kv"><span>زیرمجموعه‌ها</span><span>' + fa(u.sub_used) + ' از ' + fa(u.max_sub) + '</span></div>' : '<div class="kv"><span>دسترسی‌ها</span><span>' + esc(permNames(u)) + '</span></div>') +
      '<div class="kv"><span>انتشار تغییرات</span><span>' + (u.require_approval ? 'پس از تایید' : 'مستقیم') + '</span></div>' +
      '<div class="kv"><span>آخرین ورود</span><span>' + esc(stamp(u.last_login)) + '</span></div>' +
      '<div class="kv"><span>منتظر تایید</span><span>' + fa(u.pending) + '</span></div>' +
      '<div class="row-btns"><button class="btn sec" data-act="userEdit" data-id="' + u.id + '">ویرایش</button><button class="btn sec" data-act="userActs" data-id="' + u.id + '">فعالیت‌ها</button>' +
      (admin && u.level === 2 ? '<button class="btn sec" data-act="userBackup" data-id="' + u.id + '">پشتیبان</button>' : '') +
      '<button class="btn sec" data-act="userLogout" data-id="' + u.id + '">خروج اجباری</button><button class="btn danger" data-act="userDel" data-id="' + u.id + '">حذف</button></div></li>';
  }
  function tabUsers() {
    if (!SV.fresh.users && SV.loading) return loadingBox();
    if (!canManage()) return empty('دسترسی نداری', 'مدیر اصلی اجازه ساخت زیرمجموعه را برای حساب تو فعال نکرده است.');
    const list = (SV.users || []).filter((x) => x.role !== 'admin'), me = Auth.current(), admin = lvl() === 1;
    const kids = (pid) => list.filter((x) => x.parent_id === pid && x.level === 3);
    let rows = '';
    if (admin) {
      list.filter((x) => x.level === 2).forEach((x) => { rows += userCardRow(x, false) + kids(x.id).map((k) => userCardRow(k, true)).join(''); });
      const direct = list.filter((x) => x.level === 3 && !list.some((p) => p.id === x.parent_id && p.level === 2));
      if (direct.length) rows += '<li class="grplabel">کاربران سطح ۳ مستقیم زیر مجموعه تو</li>' + direct.map((k) => userCardRow(k, false)).join('');
    } else rows = list.map((x) => userCardRow(x, false)).join('');
    const full = !admin && me.sub_used >= me.max_sub;
    const btns = admin
      ? '<button class="btn" data-act="userEdit" data-id="0" data-lv="2">' + icon('plus') + ' کاربر سطح ۲</button><button class="btn sec" data-act="userEdit" data-id="0" data-lv="3">' + icon('plus') + ' کاربر سطح ۳</button>'
      : '<button class="btn" data-act="' + (full ? 'subFull' : 'userEdit') + '" data-id="0" data-lv="3">' + icon('plus') + ' افزودن زیرمجموعه</button>';
    const cap = admin ? '' : '<p class="note">ظرفیت زیرمجموعه: ' + fa(me.sub_used) + ' از ' + fa(me.max_sub) + (me.sub_end_d ? ' • اشتراک تو تا ' + L.fmtDate(me.sub_end_d) : '') + '</p>';
    return errBox() + cap + '<div class="row-btns" style="margin:0 0 12px">' + btns + '</div>' +
      (rows ? '<ul class="ulist">' + rows + '</ul>' : empty('هنوز کاربری نساخته‌ای', 'با دکمه بالا اولین کاربر را اضافه کن.'));
  }
  function userForm(id, lvNew) {
    const u = id ? (SV.users || []).find((x) => String(x.id) === String(id)) : null;
    const tl = u ? u.level : (lvl() === 2 ? 3 : (lvNew || 2));
    const admin = lvl() === 1;
    const has = (k) => !!u && (u.perms || []).indexOf(k) >= 0;
    const today = L.today();
    ui.ueExtra = u ? (u.perms || []).filter((p) => GROUPED.indexOf(p) < 0) : [];
    const noEnd = !!u && !u.sub_end_d && tl === 2;
    const subBox = tl !== 2 ? '' :
      '<h3 class="sub">اشتراک و سقف زیرمجموعه</h3>' +
      '<div class="field"><span>شروع اشتراک</span>' + dateInput('ue-sd', u && u.sub_start_d ? u.sub_start_d : today) + '</div>' +
      '<label class="check"><input type="checkbox" id="ue-noend" data-change="noEnd"' + (noEnd ? ' checked' : '') + '><span>بدون تاریخ پایان</span></label>' +
      '<div class="field" id="ue-endbox"' + (noEnd ? ' style="display:none"' : '') + '><span>پایان اشتراک (بعد از این تاریخ خودش و زیرمجموعه‌هایش از برنامه خارج می‌شوند و پشتیبان کامل به ایمیل تو ارسال می‌شود)</span>' + dateInput('ue-ed', u && u.sub_end_d ? u.sub_end_d : L.addDays(today, 30)) + '</div>' +
      '<label class="field"><span>تعداد زیرمجموعه‌ای که می‌تواند بسازد (۰ = اجازه ندارد)</span><select id="ue-max">' + [0, 1, 2, 3, 4, 5, 6, 7].map((n) => '<option value="' + n + '"' + ((u ? u.max_sub : 3) === n ? ' selected' : '') + '>' + fa(n) + '</option>').join('') + '</select></label>' +
      '<p class="note">کاربر سطح ۲ همه امکانات برنامه را دارد، به‌جز تغییر نام کاربری و رمز عبور خودش.</p>';
    const permBox = tl !== 3 ? '' :
      '<h3 class="sub">دسترسی‌ها (تیک بزن تا مجاز شود)</h3>' +
      PGROUPS.map((g) => '<label class="check"><input type="checkbox" class="pg-chk" value="' + g[0] + '"' + (g[2].some(has) ? ' checked' : '') + '><span>' + g[1] + '</span></label>').join('');
    modal((u ? 'ویرایش کاربر' : 'افزودن کاربر') + ' سطح ' + fa(tl),
      '<div class="grid2"><label class="field"><span>نام</span><input id="ue-first" maxlength="40" value="' + esc(u ? u.first_name : '') + '"></label><label class="field"><span>نام خانوادگی</span><input id="ue-last" maxlength="40" value="' + esc(u ? u.last_name : '') + '"></label></div>' +
      '<label class="field"><span>نام کاربری (آیدی ورود)</span><input id="ue-user" dir="ltr" autocapitalize="off" autocomplete="off" spellcheck="false" value="' + esc(u ? u.username : '') + '"></label>' +
      '<label class="field"><span>' + (u ? 'رمز جدید (خالی = بدون تغییر؛ با تغییر رمز، کاربر از برنامه خارج می‌شود)' : 'رمز عبور (حداقل ۶ کاراکتر)') + '</span><input id="ue-pass" dir="ltr" autocomplete="new-password"></label>' +
      '<div class="grid2"><label class="field"><span>شماره تماس</span><input id="ue-phone" dir="ltr" inputmode="tel" value="' + esc(u ? u.phone : '') + '"></label><label class="field"><span>ایمیل</span><input id="ue-email" dir="ltr" value="' + esc(u ? u.email : '') + '"></label></div>' +
      '<label class="field"><span>سمت</span><input id="ue-role" maxlength="40" value="' + esc(u ? u.role_title : '') + '"></label>' +
      '<label class="check"><input type="checkbox" id="ue-active"' + (!u || u.active ? ' checked' : '') + '><span>حساب فعال باشد</span></label>' +
      '<label class="check"><input type="checkbox" id="ue-appr"' + ((u ? u.require_approval : tl === 3) ? ' checked' : '') + '><span>تغییرات این کاربر قبل از انتشار، تایید من را نیاز دارد</span></label>' +
      subBox + permBox + '<p class="lerr" id="ue-err"></p>',
      '<button class="btn" data-act="userSave" data-id="' + (u ? u.id : 0) + '" data-lv="' + tl + '">ذخیره</button>');
  }

  /* --- ورود و خروج --- */
  function tabSessions() {
    if (!SV.fresh.sessions && SV.loading) return loadingBox();
    const s = SV.sessions;
    if (!s) return errBox() + refreshBtn();
    const WHY = { logout: 'خروج توسط کاربر', password: 'خروج اجباری (تغییر رمز)', username: 'خروج اجباری (تغییر نام کاربری)', disabled: 'خروج اجباری (غیرفعال شد)', forced: 'خروج اجباری توسط مدیر', deleted: 'حساب حذف شد' };
    const rows = s.rows.map((r) => {
      const st = r.logout_at ? (WHY[r.logout_reason] || 'خارج شده') : (s.now - r.last_seen < 300 ? 'آنلاین' : 'وارد شده');
      return '<tr><td><b>' + esc(fullName(r)) + '</b><br><small dir="ltr">' + esc(r.ip || '') + '</small></td><td>' + esc(stamp(r.login_at)) + '</td><td>' + esc(stamp(r.last_seen)) + '</td><td>' + (r.logout_at ? esc(stamp(r.logout_at)) : '—') + '</td><td>' + esc(st) + '</td></tr>';
    }).join('');
    return '<p class="note">ورود و خروج کاربران با تاریخ، روز و ساعت (۱۵۰ مورد آخر).</p><div class="tblwrap"><table class="stbl"><thead><tr><th>کاربر</th><th>ورود</th><th>آخرین فعالیت</th><th>خروج</th><th>وضعیت</th></tr></thead><tbody>' + rows + '</tbody></table></div>' + refreshBtn();
  }
  /* --- صفحه کاربران (فعالیت‌ها، تایید، کاربران، ورود و خروج) --- */
  function usersTabs() {
    const l = lvl();
    if (l === 3) return [['activity', 'فعالیت‌ها']];
    const t = [['activity', 'فعالیت‌ها']];
    if (canManage() || S.pendingTotal) t.push(['approvals', 'تایید' + (S.pendingTotal ? ' (' + fa(S.pendingTotal) + ')' : '')]);
    if (canManage()) t.push(['users', 'کاربران'], ['sessions', 'ورود و خروج']);
    return t;
  }
  function vUsers() {
    const tabs = usersTabs();
    if (!tabs.some((t) => t[0] === ui.ptab)) ui.ptab = 'activity';
    if (!SV.fresh[ui.ptab] && !SV.loading) setTimeout(() => loadTab(false), 0);
    if (ui.ptab === 'activity' && canManage() && !SV.users && !SV.loading) Auth.api('users').then((r) => { if (r.ok) { SV.users = r.users; render(true); } }).catch(() => {});
    const body = ui.ptab === 'activity' ? tabActivity() : ui.ptab === 'approvals' ? tabApprovals() : ui.ptab === 'users' ? tabUsers() : tabSessions();
    return {
      tab: 'users',
      html: head(lvl() === 3 ? 'فعالیت‌ها' : 'کاربران') + '<main class="page' + (ui.ptab === 'sessions' ? ' wide' : '') + '">' + (tabs.length > 1 ? '<div class="tabs scroll">' + tabs.map(([k, l]) => '<button data-act="ptab" data-t="' + k + '" class="' + (ui.ptab === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>' : '') + body + '</main>'
    };
  }
  /* --- مشخصات (پروفایل) --- */
  const LVN = { 1: 'مالک و مدیر اصلی (سطح ۱)', 2: 'کاربر سطح ۲', 3: 'کاربر سطح ۳' };
  function vProfile() {
    const me = Auth.current(), l = lvl();
    const approver = l === 2 ? 'مدیر اصلی' : 'مدیر';
    return {
      tab: null,
      html: head('پروفایل', '#/home') + '<main class="page">' + userCard() +
        '<div class="card"><div class="kv"><span>نام کاربری</span><span dir="ltr">' + esc(me.username) + '</span></div><div class="kv"><span>سطح کاربری</span><span>' + LVN[l] + '</span></div>' +
        (l === 2 ? '<div class="kv"><span>اشتراک</span><span>' + esc(subLine(me)) + '</span></div><div class="kv"><span>زیرمجموعه‌ها</span><span>' + fa(me.sub_used) + ' از ' + fa(me.max_sub) + '</span></div>' : '') +
        (l > 1 ? '<div class="kv"><span>نمایش تغییرات</span><span>' + (me.require_approval ? 'پس از تایید ' + approver : 'مستقیم') + '</span></div>' : '') +
        (l === 1 ? '<div class="row-btns"><button class="btn sec" data-act="editAccount">' + icon('edit') + ' تغییر نام کاربری و رمز عبور</button></div>' : '<p class="note">نام، نام کاربری و رمز عبور را مدیر بالادستی تغییر می‌دهد.</p>') +
        '<div class="row-btns"><button class="btn danger" data-act="logout">خروج از حساب</button></div></div>' +
        '<div class="card"><div class="kv"><span>لیگ‌ها</span><span>' + fa(db.leagues.length) + '</span></div><div class="kv"><span>تیم‌ها</span><span>' + fa(db.teams.length) + '</span></div><div class="kv"><span>بازیکنان</span><span>' + fa(db.players.length) + '</span></div>' +
        '<div class="kv"><span>بازی‌های ثبت‌شده</span><span>' + fa(db.matches.filter((m) => m.played && !m.bye).length) + '</span></div></div>' +
        '<p class="note" style="text-align:center;margin-top:16px">لیگ فوتسال • نسخه ' + VERSION + '</p></main>'
    };
  }
  /* --- تنظیمات --- */
  function vSettings() {
    const l = lvl();
    let data = '';
    if (l <= 2) {
      data = '<h3 class="sub">داده‌ها</h3><div class="card"><p class="note">' + (l === 1 ? 'پشتیبان‌گیری از همه داده‌های همه کاربران. بازیابی فقط موارد داخل فایل را اضافه یا جایگزین می‌کند و چیزی را پاک نمی‌کند.' : 'داده‌های تو و زیرمجموعه‌هایت روی سرور ذخیره می‌شود. پشتیبان‌گیری یک نسخه JSON می‌دهد.') + '</p><div class="row-btns"><button class="btn sec" data-act="exportDb">پشتیبان‌گیری</button><button class="btn sec" data-act="importDb">بازیابی</button>' +
        (l === 2 ? '<button class="btn sec" data-act="demo">داده نمونه</button><button class="btn danger" data-act="resetAll">حذف همه داده‌ها</button>' : '') + '</div></div>';
    }
    return {
      tab: null,
      html: head('تنظیمات', '#/home') + '<main class="page"><div class="card"><label class="check"><input type="checkbox" data-change="dark"' + (db.settings.dark ? ' checked' : '') + '><span>حالت تاریک</span></label></div>' +
        (Auth.isOfflineSession() ? '<div class="card"><p class="note">الان آفلاین وارد شده‌ای و تغییرات هنوز به سرور نرفته است.</p><div class="row-btns"><button class="btn sec" data-act="askUp">' + icon('share') + ' ارسال تغییرات به سرور</button></div></div>' : '') +
        data + '<p class="note" style="text-align:center;margin-top:16px">لیگ فوتسال • نسخه ' + VERSION + '</p></main>'
    };
  }

  const EMAIL = 'roohollahsafdari@gmail.com';
  function vAbout() {
    const uses = ['ساخت تیم، ثبت بازیکنان و کادر فنی', 'برگزاری لیگ، جام حذفی و گروهی + حذفی', 'قرعه‌کشی و برنامه بازی‌ها (خودکار یا دستی)', 'ثبت نتیجه، گلزنان، کارت‌ها و بهترین بازیکن', 'جدول، آقای گل و محرومان بازی بعد', 'صعود و سقوط، بازی‌های معوقه و لغوشده'];
    return {
      tab: 'home',
      html: head('ارتباط با ما', '#/home') + '<main class="page">' +
        '<section class="abox"><span class="aic">' + icon('info') + '</span><h3>درباره برنامه</h3><p>«لیگ فوتسال» برنامه‌ای فارسی برای مدیریت کامل لیگ و جام فوتسال است. همه اطلاعات روی همین گوشی ذخیره می‌شود و بدون اینترنت کار می‌کند.</p><p class="note">نسخه ' + VERSION + '</p></section>' +
        '<section class="abox"><span class="aic">' + icon('trophy') + '</span><h3>کاربردها</h3><ul>' + uses.map((x) => '<li>' + x + '</li>').join('') + '</ul></section>' +
        '<section class="abox"><span class="aic">' + icon('user') + '</span><h3>طراحی و پیاده‌سازی</h3><p class="who">روح‌الله صفدری</p></section>' +
        '<section class="abox"><span class="aic">' + icon('mail') + '</span><h3>ارتباط با ما</h3><p>برای پیشنهاد، گزارش مشکل یا همکاری ایمیل بزن:</p><a class="mail" dir="ltr" href="mailto:' + EMAIL + '">' + EMAIL + '</a><div class="row-btns"><a class="btn" href="mailto:' + EMAIL + '">' + icon('mail') + ' ارسال ایمیل</a><button class="btn sec" data-act="copyMail">کپی ایمیل</button></div></section>' +
        '</main>'
    };
  }

  /* ---------- عملیات ---------- */
  const A = {};
  const I = {};
  const C = {};
  C.annSel = (el) => { ui.annSel = el.value; };
  A.announce = announce;
  A.closeModal = () => closeModal();


  /* --- ورود و کاربران --- */
  A.togglePw = () => { const i = document.getElementById('l-pass'); if (i) i.type = i.type === 'password' ? 'text' : 'password'; };
  A.doLogin = async () => {
    const btn = document.getElementById('l-btn'), err = document.getElementById('l-err');
    if (btn) btn.disabled = true;
    const r = await Auth.login(val('l-user'), val('l-pass'), !!(document.getElementById('l-rem') || {}).checked);
    if (btn) btn.disabled = false;
    if (!r.ok) { if (err) err.textContent = r.error || 'ورود انجام نشد'; return; }
    ui.loginMsg = ''; ui.ptab = 'activity'; ui.afUser = 'all'; ui.afType = 'all'; ui.upAsked = false;
    // داده‌ی همین کاربر (و تغییرهای ارسال‌نشده‌اش) حفظ می‌شود؛ داده‌ی بقیه پاک می‌شود
    resetLocal(Auth.current().id); db = load();
    if (r.offline && !S.base) S.base = hashMap(L.emptyDb());
    if (r.offline) { toast('وارد شدی (حالت آفلاین). با اتصال به اینترنت اطلاعات همگام می‌شود.'); }
    location.hash = '#/home'; render(false); doSync();
  };
  function askUpgrade() {
    if (ui.upAsked || document.getElementById('modal')) return;
    ui.upAsked = true;
    modal('اتصال به سرور', '<p class="note">اینترنت وصل است. برای ارسال تغییراتت به سرور، یک‌بار رمز عبور مدیر را وارد کن.</p><label class="field"><span>رمز عبور</span><input id="up-pass" type="password" dir="ltr" autocomplete="current-password"></label><p class="lerr" id="up-err"></p>', '<button class="btn" data-act="upgradeDo">اتصال</button>');
  }
  A.askUp = () => { ui.upAsked = false; askUpgrade(); };
  A.upgradeDo = async () => {
    const r = await Auth.upgradeWith(val('up-pass')), e = document.getElementById('up-err');
    if (r === 'net') { if (e) e.textContent = 'ارتباط با سرور برقرار نشد'; return; }
    if (r === 'bad') { if (e) e.textContent = 'رمز عبور درست نیست'; return; }
    ui.upAsked = false; closeModal(); toast('به سرور وصل شدی'); doSync();
  };
  A.retrySync = () => { S.err = ''; render(false); doSync(); };
  A.logout = async () => {
    if (!confirm('از حساب خارج می‌شوی؟')) return;
    closeDrawer(); closeModal(true);
    try { await doSync(); } catch (e) { /* خالی */ }
    const uid = Auth.current() ? Auth.current().id : null;
    const unsent = !!(S.base && diffChanges(S.base, db).length);
    await Auth.logout();
    resetLocal(unsent ? uid : null); ui.loginMsg = ''; location.hash = '#/home'; render(false);
    if (unsent) toast('تغییرهای ارسال‌نشده روی گوشی ماند و با ورود بعدی ارسال می‌شود');
  };
  A.goApprovals = () => { ui.ptab = 'approvals'; SV.fresh.approvals = false; hideNotif(); };
  A.closeNotif = () => hideNotif();
  A.subFull = () => toast('سقف تعداد زیرمجموعه‌هایت تکمیل شده است');
  C.noEnd = (el) => { const b = document.getElementById('ue-endbox'); if (b) b.style.display = el.checked ? 'none' : ''; };
  A.ptab = (d) => { ui.ptab = d.t; SV.fresh[d.t] = false; SV.err = ''; render(true); };
  A.tabRefresh = () => { SV.fresh[ui.ptab] = false; SV.err = ''; render(true); };
  A.moreAct = () => loadTab(true);
  C.aFilter = () => { const u = document.getElementById('af-user'), t = document.getElementById('af-type'); if (u) ui.afUser = u.value; if (t) ui.afType = t.value; SV.fresh.activity = false; SV.act = null; render(true); };
  A.userActs = (d) => { ui.ptab = 'activity'; ui.afUser = d.id; ui.afType = 'all'; SV.fresh.activity = false; SV.act = null; render(false); };
  A.userEdit = (d) => userForm(d.id === '0' ? null : d.id, parseInt(d.lv, 10) || 0);
  A.userSave = async (d) => {
    const e = document.getElementById('ue-err'), has = (id) => document.getElementById(id);
    const tl = parseInt(d.lv, 10) || 3;
    const body = { id: parseInt(d.id, 10) || 0, level: tl, first_name: val('ue-first').trim(), last_name: val('ue-last').trim(), username: val('ue-user').trim(), password: val('ue-pass'), phone: val('ue-phone').trim(), email: val('ue-email').trim(), role_title: val('ue-role').trim(),
      active: has('ue-active') ? has('ue-active').checked : true, require_approval: has('ue-appr') ? has('ue-appr').checked : false };
    if (tl === 3) {
      const on = Array.prototype.map.call(document.querySelectorAll('.pg-chk:checked'), (c) => c.value);
      body.perms = PGROUPS.filter((g) => on.indexOf(g[0]) >= 0).reduce((a, g) => a.concat(g[2]), []).concat(ui.ueExtra || []);
    }
    if (tl === 2) {
      const sd = readDate('ue-sd'), noEnd = has('ue-noend') && has('ue-noend').checked, ed = noEnd ? '' : readDate('ue-ed');
      if (!sd || (!noEnd && !ed)) { if (e) e.textContent = 'تاریخ‌ها را درست وارد کن'; return; }
      body.sub_start_d = sd; body.sub_end_d = ed || ''; body.max_sub = parseInt(val('ue-max'), 10) || 0;
    }
    const r = await Auth.api('user_save', body).catch((x) => ({ ok: false, error: x.auth ? '' : 'ارتباط با سرور برقرار نشد' }));
    if (!r.ok) { if (e) e.textContent = r.error || ''; return; }
    closeModal(); SV.fresh.users = false; SV.users = null;
    render(true); toast('ذخیره شد');
  };
  A.userBackup = async (d) => {
    toast('در حال ساخت پشتیبان...');
    const r = await Auth.api('backup', { id: parseInt(d.id, 10) }).catch(() => ({}));
    if (!r.ok) return toast(r.error || 'ارتباط با سرور برقرار نشد');
    modal('پشتیبان کامل کاربر', '<p class="note">این متن شامل همه لیگ‌ها، تیم‌ها، بازیکنان و بازی‌های این کاربر و زیرمجموعه‌هایش است. کپی کن و جای امن نگه دار، یا برای ایمیلت بفرست.</p><label class="field"><textarea id="x-json" readonly>' + esc(r.raw) + '</textarea></label>',
      '<button class="btn" data-act="copyDb">کپی متن</button><button class="btn sec" data-act="backupMail" data-id="' + d.id + '">ارسال به ایمیل من</button>');
  };
  A.backupMail = async (d) => {
    const r = await Auth.api('backup_mail', { id: parseInt(d.id, 10) }).catch(() => ({}));
    toast(r.ok ? 'پشتیبان به ایمیل مدیر اصلی ارسال شد' : (r.error || 'ارتباط با سرور برقرار نشد'));
  };
  A.userLogout = async (d) => { if (!confirm('این کاربر از برنامه خارج شود؟')) return; const r = await Auth.api('user_logout', { id: parseInt(d.id, 10) }).catch(() => ({})); if (r.ok) toast('کاربر خارج شد'); };
  A.userDel = async (d) => {
    const u = (SV.users || []).find((x) => String(x.id) === String(d.id));
    if (!u || !confirm('حساب «' + fullName(u) + '» حذف شود؟' + (u.level === 2 ? ' زیرمجموعه‌هایش هم حذف می‌شوند (اطلاعات لیگ‌ها می‌ماند).' : '') + ' سابقه فعالیت‌ها می‌ماند.')) return;
    const r = await Auth.api('user_delete', { id: u.id }).catch(() => ({}));
    if (r.ok) { SV.fresh.users = false; SV.users = null; render(true); toast('حساب حذف شد'); } else toast(r.error || 'حذف انجام نشد');
  };
  async function decide(ids, mode) {
    if (!ids.length) return toast('موردی انتخاب نشده');
    const r = await Auth.api('decide', { ids, decision: mode }).catch(() => ({}));
    if (!r.ok) return toast(r.error || 'ارتباط با سرور برقرار نشد');
    toast(fa(r.count) + ' تغییر ' + (mode === 'approve' ? 'تایید شد' : 'رد شد'));
    SV.fresh.approvals = false; render(true); doSync();
  }
  const idsOf = (str) => String(str || '').split(',').filter(Boolean).map((x) => parseInt(x, 10));
  A.decide = (d) => {
    if (d.mode === 'reject' && !confirm('این تغییرات رد شود؟ از گوشی کاربر هم برگردانده می‌شود.')) return;
    decide(idsOf(d.ids), d.mode);
  };
  A.decideSel = (d) => {
    const ids = [];
    document.querySelectorAll('.pd-chk:checked').forEach((c) => idsOf(c.dataset.ids).forEach((x) => ids.push(x)));
    if (d.mode === 'reject' && ids.length && !confirm('تغییرات انتخاب‌شده رد شود؟')) return;
    decide(ids, d.mode);
  };
  /* --- منوی کشویی --- */
  function closeDrawer() {
    const d = document.getElementById('drawer');
    if (!d) return false;
    d.classList.remove('open');
    document.body.classList.remove('lock');
    setTimeout(() => { if (d.parentNode && !d.classList.contains('open')) d.remove(); }, 220);
    return true;
  }
  A.openDrawer = () => {
    if (document.getElementById('drawer')) return;
    const u = db.user, cur = (location.hash.replace(/^#\/?/, '') || 'home').split('/')[0];
    const item = (href, ic, label) => '<a class="ditem' + (cur === href ? ' on' : '') + '" href="#/' + href + '">' + icon(ic) + '<span>' + label + '</span></a>';
    const el = document.createElement('div');
    el.id = 'drawer'; el.className = 'drawer';
    el.innerHTML = '<div class="dscrim" data-act="closeDrawer"></div><aside class="dpanel" role="dialog" aria-label="منو"><a class="dhead" href="#/profile">' + avatar(u, 'xl') + '<b>' + (userName() ? esc(userName()) : 'کاربر لیگ فوتسال') + '</b><small>' + (u.role ? esc(u.role) : 'مشخصات خود را در پروفایل ثبت کن') + '</small></a><nav class="dlist">' +
      item('profile', 'user', 'پروفایل') + item('settings', 'gear', 'تنظیمات') + item('about', 'mail', 'ارتباط با ما') + '<button class="ditem" data-act="logout">' + icon('logout') + '<span>خروج از حساب</span></button></nav><p class="dfoot">لیگ فوتسال • نسخه ' + VERSION + '</p></aside>';
    document.body.appendChild(el);
    document.body.classList.add('lock');
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('open')));
  };
  A.closeDrawer = () => closeDrawer();
  A.copyMail = () => {
    try { if (navigator.clipboard) navigator.clipboard.writeText(EMAIL); toast('ایمیل کپی شد'); } catch (e) { toast(EMAIL); }
  };

  /* --- مشخصات کاربر --- */
  A.editUser = () => {
    const u = db.user, adm = lvl() === 1;
    modal('ویرایش مشخصات',
      (adm ? '<div class="grid2"><label class="field"><span>نام</span><input id="u-first" value="' + esc(u.first) + '" maxlength="40"></label><label class="field"><span>نام خانوادگی</span><input id="u-last" value="' + esc(u.last) + '" maxlength="40"></label></div>' : '<p class="note">نام و حساب کاربری را مدیر بالادستی تغییر می‌دهد. اینجا فقط شماره تماس، ایمیل و سمت قابل ویرایش است.</p>') +
      '<label class="field"><span>شماره تماس</span><input id="u-phone" type="tel" inputmode="tel" dir="ltr" value="' + esc(u.phone) + '" maxlength="20" placeholder="09123456789" autocomplete="off"></label>' +
      '<label class="field"><span>ایمیل' + (adm ? ' (پشتیبان پایان اشتراک کاربران به این ایمیل می‌رود)' : '') + '</span><input id="u-email" type="email" dir="ltr" value="' + esc(u.email) + '" maxlength="120" placeholder="name@example.com" autocomplete="off"></label>' +
      '<label class="field"><span>سمت</span><input id="u-role" value="' + esc(u.role) + '" maxlength="40" placeholder="مثلاً مدیر لیگ، سرپرست، داور" autocomplete="off"></label><p class="lerr" id="u-err"></p>',
      '<button class="btn" data-act="saveUser">ذخیره</button>');
  };
  A.saveUser = async () => {
    const phone = val('u-phone').trim().replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 1776)).replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 1632));
    const e = document.getElementById('u-err');
    if (phone && !/^[0-9+\-\s()]{5,20}$/.test(phone)) { if (e) e.textContent = 'شماره تماس معتبر نیست'; return; }
    const body = { phone, email: val('u-email').trim(), role_title: val('u-role').trim() };
    if (lvl() === 1) { body.first_name = val('u-first').trim(); body.last_name = val('u-last').trim(); }
    const r = await Auth.api('profile', body).catch((x) => ({ ok: false, error: x.auth ? '' : 'ارتباط با سرور برقرار نشد' }));
    if (!r.ok) { if (e) e.textContent = r.error || ''; return; }
    Auth.setMe(r.me); db.user = userFromMe(r.me); closeModal(); render(true); toast('پروفایل ذخیره شد');
  };
  // تغییر نام کاربری و رمز عبور (فقط مالک؛ با رمز فعلی)
  A.editAccount = () => {
    const me = Auth.current();
    modal('تغییر نام کاربری و رمز عبور',
      '<label class="field"><span>نام کاربری جدید</span><input id="ac-user" dir="ltr" autocapitalize="off" autocomplete="off" spellcheck="false" value="' + esc(me.username) + '"></label>' +
      '<label class="field"><span>رمز جدید (خالی = بدون تغییر، حداقل ۶ کاراکتر)</span><input id="ac-new" type="password" dir="ltr" autocomplete="new-password"></label>' +
      '<label class="field"><span>تکرار رمز جدید</span><input id="ac-new2" type="password" dir="ltr" autocomplete="new-password"></label>' +
      '<label class="field"><span>رمز عبور فعلی (برای تایید لازم است)</span><input id="ac-cur" type="password" dir="ltr" autocomplete="current-password"></label>' +
      '<p class="note">بعد از تغییر، دستگاه‌های دیگرت از برنامه خارج می‌شوند و همین دستگاه می‌ماند.</p><p class="lerr" id="ac-err"></p>',
      '<button class="btn" data-act="saveAccount">ذخیره</button>');
  };
  A.saveAccount = async () => {
    const e = document.getElementById('ac-err'), un = val('ac-user').trim(), pw = val('ac-new'), cur = val('ac-cur');
    if (un.length < 3 || /\s/.test(un)) { if (e) e.textContent = 'نام کاربری حداقل ۳ حرف و بدون فاصله باشد'; return; }
    if (pw && pw.length < 6) { if (e) e.textContent = 'رمز جدید حداقل ۶ کاراکتر باشد'; return; }
    if (pw !== val('ac-new2')) { if (e) e.textContent = 'تکرار رمز با رمز جدید یکی نیست'; return; }
    if (!cur) { if (e) e.textContent = 'رمز فعلی را وارد کن'; return; }
    const r = await Auth.api('account', { username: un, password: pw, cur }).catch((x) => ({ ok: false, error: x.auth ? '' : 'ارتباط با سرور برقرار نشد' }));
    if (!r.ok) { if (e) e.textContent = r.error || ''; return; }
    Auth.setMe(r.me); Auth.setOwnerCred(r.me.username, pw || cur, r.me);
    closeModal(); render(true); toast('ذخیره شد');
  };
  // عکس: کوچک و مربعی می‌شود تا حافظه زیاد نگیرد
  C.userPhoto = (el) => {
    const f = el.files && el.files[0];
    if (!f) return;
    const fr = new FileReader();
    fr.onerror = () => toast('عکس خوانده نشد');
    fr.onload = () => {
      const img = new Image();
      img.onerror = () => toast('این فایل عکس معتبر نیست');
      img.onload = () => {
        const S = 256, c = document.createElement('canvas');
        c.width = c.height = S;
        const side = Math.min(img.width, img.height);
        c.getContext('2d').drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, S, S);
        ui.photo = c.toDataURL('image/jpeg', 0.82);
        const p = document.getElementById('u-prev'); if (p) p.innerHTML = avatar({ photo: ui.photo }, 'xl');
      };
      img.src = fr.result;
    };
    fr.readAsDataURL(f);
    el.value = '';
  };
  A.homeDay = (d) => { ui.homeDay = d.d; render(true); };
  A.tab = (d) => { ui.tab = d.t; render(false); };
  A.teamTab = (d) => { ui.teamTab = d.t; ui.q = ''; render(true); };

  /* --- تیم --- */
  function joinRoster(t, lid) {
    const l = league(lid);
    if (l && !hasMatches(l.id) && l.teamIds.indexOf(t.id) < 0) l.teamIds.push(t.id);
  }
  function moveTeam(t, newId) {
    const old = league(t.leagueId);
    const played = old && db.matches.some((m) => m.leagueId === old.id && (m.home === t.id || m.away === t.id));
    if (played && old.status !== 'finished') return 'این تیم در بازی‌های لیگ فعلی‌اش حضور دارد. تغییر لیگ بعد از پایان آن لیگ ممکن است.';
    if (old && !played) old.teamIds = old.teamIds.filter((x) => x !== t.id);
    t.leagueId = newId;
    joinRoster(t, newId);
    return null;
  }
  function teamForm(id) {
    if (!db.leagues.length) { toast('اول یک لیگ بساز'); location.hash = '#/leagues'; return; }
    const t = id && team(id);
    const cur = t ? t.leagueId : (league(ui.teamTab) ? ui.teamTab : sortedLeagues()[0].id);
    modal(t ? 'ویرایش تیم' : 'افزودن تیم',
      '<label class="field"><span>نام تیم</span><input id="f-name" value="' + esc(t ? t.name : '') + '" maxlength="40" autocomplete="off"></label>' +
      '<label class="field"><span>لیگی که در آن بازی می‌کند</span><select id="f-league">' + sortedLeagues().map((l) => '<option value="' + l.id + '"' + (l.id === cur ? ' selected' : '') + '>' + esc(l.name) + ' (سطح ' + fa(l.level) + ')</option>').join('') + '</select></label>',
      '<button class="btn" data-act="saveTeam" data-id="' + (t ? t.id : '') + '">ذخیره</button>');
    setTimeout(() => { const i = document.getElementById('f-name'); if (i) i.focus(); }, 60);
  }
  A.addTeam = () => teamForm();
  A.editTeam = (d) => teamForm(d.id);
  A.saveTeam = (d) => {
    const name = val('f-name').trim();
    const lid = val('f-league');
    if (!name) return toast('نام تیم را وارد کن');
    if (!league(lid)) return toast('لیگ تیم را انتخاب کن');
    if (db.teams.some((t) => t.name === name && t.id !== d.id)) return toast('این نام قبلاً ثبت شده');
    let note = '';
    if (d.id) {
      const t = team(d.id);
      if (t.leagueId !== lid) { const err = moveTeam(t, lid); if (err) return toast(err); }
      t.name = name;
    } else {
      const t = { id: L.uid(), name, leagueId: lid, staff: { manager: '', head: '', coach: '', assistant: '', media: '' } };
      db.teams.push(t);
      if (hasMatches(lid)) note = 'تیم ثبت شد، ولی برنامه بازی‌های این لیگ قبلاً ساخته شده و تیم در آن شرکت داده نمی‌شود.';
      else joinRoster(t, lid);
    }
    ui.teamTab = lid; ui.q = '';
    closeModal(); commit();
    if (note) toast(note);
  };
  A.delTeam = (d) => {
    const t = team(d.id);
    if (db.matches.some((m) => m.home === d.id || m.away === d.id)) return toast('این تیم در بازی‌های یک لیگ حضور دارد و حذف نمی‌شود.');
    if (!confirm('تیم «' + t.name + '» و بازیکنانش حذف شود؟')) return;
    db.leagues.forEach((l) => { l.teamIds = l.teamIds.filter((x) => x !== d.id); });
    db.teams = db.teams.filter((x) => x.id !== d.id);
    db.players = db.players.filter((p) => p.teamId !== d.id);
    commit();
  };
  A.editStaff = (d) => {
    const t = team(d.id);
    modal('کادر فنی ' + t.name, ROLES.map(([k, l]) => '<label class="field"><span>' + l + '</span><input id="s-' + k + '" value="' + esc(t.staff && t.staff[k]) + '" maxlength="40" autocomplete="off"></label>').join(''),
      '<button class="btn" data-act="saveStaff" data-id="' + d.id + '">ذخیره</button>');
  };
  A.saveStaff = (d) => {
    const t = team(d.id);
    t.staff = t.staff || {};
    ROLES.forEach(([k]) => { t.staff[k] = val('s-' + k).trim(); });
    closeModal(); commit();
  };

  /* --- بازیکن --- */
  function playerForm(tid, id) {
    const p = id && player(id);
    const used = players(tid).filter((x) => !p || x.id !== p.id).map((x) => x.number);
    let free = 1; while (used.indexOf(free) >= 0) free++;
    modal(p ? 'ویرایش بازیکن' : 'افزودن بازیکن',
      '<label class="field"><span>نام بازیکن</span><input id="p-name" value="' + esc(p ? p.name : '') + '" maxlength="40" autocomplete="off"></label>' +
      '<div class="grid2"><label class="field"><span>شماره پیراهن</span><input id="p-num" type="number" inputmode="numeric" min="0" max="99" value="' + (p ? p.number : free) + '"></label>' +
      '<label class="field"><span>پست</span><select id="p-pos">' + POS.map((x) => '<option' + (p && p.pos === x ? ' selected' : '') + '>' + x + '</option>').join('') + '</select></label></div>',
      '<button class="btn" data-act="savePlayer" data-id="' + (p ? p.id : '') + '" data-team="' + tid + '">ذخیره</button>');
    setTimeout(() => { const i = document.getElementById('p-name'); if (i) i.focus(); }, 60);
  }
  A.addPlayer = (d) => { if (players(d.id).length >= MAX_PLAYERS) return toast('حداکثر ۳۰ بازیکن'); playerForm(d.id); };
  A.editPlayer = (d) => playerForm(player(d.id).teamId, d.id);
  A.savePlayer = (d) => {
    const name = val('p-name').trim(); const num = parseInt(val('p-num'), 10); const pos = val('p-pos');
    if (!name) return toast('نام بازیکن را وارد کن');
    if (isNaN(num) || num < 0 || num > 99) return toast('شماره پیراهن بین ۰ تا ۹۹ باشد');
    if (players(d.team).some((p) => p.number === num && p.id !== d.id)) return toast('این شماره قبلاً استفاده شده');
    if (d.id) { const p = player(d.id); p.name = name; p.number = num; p.pos = pos; }
    else { if (players(d.team).length >= MAX_PLAYERS) return toast('حداکثر ۳۰ بازیکن'); db.players.push({ id: L.uid(), teamId: d.team, name, number: num, pos }); }
    closeModal(); commit();
  };
  A.delPlayer = (d) => {
    const p = player(d.id);
    if (!confirm('بازیکن «' + p.name + '» حذف شود؟' + (goalsOf(d.id) ? ' گل‌های او در آمار بدون نام می‌شود.' : ''))) return;
    db.events.forEach((e) => { if (e.playerId === d.id) e.playerId = null; });
    db.awards = db.awards.filter((a) => a.playerId !== d.id);
    db.leagues.forEach((l) => { if (l.bestPlayerId === d.id) l.bestPlayerId = null; });
    db.players = db.players.filter((x) => x.id !== d.id);
    commit();
  };

  /* --- لیگ --- */
  function leagueForm(id) {
    const lg = id && league(id);
    const locked = !!(lg && hasMatches(lg.id));
    const f = Object.assign({ city: '' }, lg || { name: '', province: '', venue: '', status: 'upcoming', date: L.today(), format: 'league', double: false, groupCount: 2, advance: 2, level: 1, promote: 0, relegate: 0, teamIds: [] });
    const teamsHtml = db.teams.length ? db.teams.map((t) => '<label class="check"><input type="checkbox" class="chk-team" value="' + t.id + '"' + (f.teamIds.indexOf(t.id) >= 0 ? ' checked' : '') + (locked ? ' disabled' : '') + '><span>' + esc(t.name) + (league(t.leagueId) ? ' <small>(' + esc(league(t.leagueId).name) + ')</small>' : '') + '</span></label>').join('') : '<p class="note" style="padding:10px 0">هنوز تیمی نداری. بعد از ساخت لیگ، تیم‌ها را از بخش «تیم‌ها» به آن اضافه کن.</p>';
    modal(lg ? 'ویرایش لیگ' : 'افزودن لیگ',
      '<label class="field"><span>نام لیگ</span><input id="l-name" value="' + esc(f.name) + '" maxlength="60" autocomplete="off"></label>' +
      '<div class="grid2"><label class="field"><span>استان</span><input id="l-prov" value="' + esc(f.province) + '" maxlength="30"></label><label class="field"><span>شهر</span><input id="l-city" value="' + esc(f.city) + '" maxlength="30"></label></div>' +
      '<label class="field"><span>سالن ورزشی</span><input id="l-venue" value="' + esc(f.venue) + '" maxlength="40"></label>' +
      '<div class="grid2"><label class="field"><span>سطح لیگ (۱ = بالاترین)</span><select id="l-level">' + sel([1, 2, 3, 4, 5, 6].map((n) => [n, fa(n)]), f.level) + '</select></label>' +
      '<label class="field"><span>وضعیت</span><select id="l-status">' + sel([['upcoming', STATUS.upcoming], ['running', STATUS.running], ['finished', STATUS.finished]], f.status) + '</select></label></div>' +
      '<div class="field"><span>تاریخ برگزاری</span>' + dateInput('l-date', f.date) + '</div>' +
      '<label class="field"><span>نوع لیگ</span><select id="l-fmt" data-change="fmtChange"' + (locked ? ' disabled' : '') + '>' + sel([['league', FORMATS.league + ' (همه با همه)'], ['knockout', FORMATS.knockout], ['groups', FORMATS.groups]], f.format) + '</select></label>' +
      (locked ? '<p class="note">بعد از ساخت بازی‌ها، نوع لیگ و تیم‌ها قابل تغییر نیست.</p>' : '') +
      '<label class="check" id="o-double"><input type="checkbox" id="l-double"' + (f.double ? ' checked' : '') + (locked ? ' disabled' : '') + '><span>رفت و برگشت</span></label>' +
      '<div class="grid2" id="o-promo"><label class="field"><span>صعود به لیگ بالاتر (تیم)</span><select id="l-promote">' + sel([0, 1, 2, 3, 4].map((n) => [n, fa(n)]), f.promote) + '</select></label>' +
      '<label class="field"><span>سقوط به لیگ پایین‌تر (تیم)</span><select id="l-relegate">' + sel([0, 1, 2, 3, 4].map((n) => [n, fa(n)]), f.relegate) + '</select></label></div>' +
      '<div class="grid2" id="o-groups"><label class="field"><span>تعداد گروه</span><select id="l-gc"' + (locked ? ' disabled' : '') + '>' + sel([2, 3, 4, 5, 6, 7, 8].map((n) => [n, fa(n)]), f.groupCount) + '</select></label>' +
      '<label class="field"><span>صعود از هر گروه (پیش‌فرض)</span><select id="l-adv"' + (locked ? ' disabled' : '') + '>' + sel([1, 2, 3, 4].map((n) => [n, fa(n)]), f.advance) + '</select></label></div>' +
      '<div class="field"><span>تیم‌های لیگ (اختیاری)</span><div class="teamlist">' + teamsHtml + '</div></div>',
      '<button class="btn" data-act="saveLeague" data-id="' + (lg ? lg.id : '') + '">ذخیره</button>');
    I.fmtChange();
  }
  I.fmtChange = () => {
    const fmt = val('l-fmt');
    const d = document.getElementById('o-double'), g = document.getElementById('o-groups'), p = document.getElementById('o-promo');
    if (d) d.style.display = fmt === 'knockout' ? 'none' : '';
    if (g) g.style.display = fmt === 'groups' ? '' : 'none';
    if (p) p.style.display = fmt === 'league' ? '' : 'none';
  };
  A.addLeague = () => leagueForm();
  A.editLeague = (d) => leagueForm(d.id);
  A.saveLeague = (d) => {
    const lg = d.id && league(d.id);
    const locked = !!(lg && hasMatches(lg.id));
    const name = val('l-name').trim();
    if (!name) return toast('نام لیگ را وارد کن');
    const date = readDate('l-date');
    if (!date) return toast('تاریخ معتبر نیست');
    const fmt = locked ? lg.format : val('l-fmt');
    const ids = locked ? lg.teamIds : Array.prototype.map.call(document.querySelectorAll('.chk-team:checked'), (c) => c.value);
    const gc = parseInt(val('l-gc'), 10), adv = parseInt(val('l-adv'), 10);
    if (!locked && fmt === 'groups' && adv * gc < 2) return toast('حداقل دو تیم باید صعود کنند');
    const o = { name, province: val('l-prov').trim(), city: val('l-city').trim(), venue: val('l-venue').trim(), status: val('l-status'), date, level: parseInt(val('l-level'), 10), promote: parseInt(val('l-promote'), 10) || 0, relegate: parseInt(val('l-relegate'), 10) || 0 };
    if (fmt !== 'league') { o.promote = 0; o.relegate = 0; }
    if (!locked) Object.assign(o, { format: fmt, double: !!document.getElementById('l-double').checked, groupCount: gc, advance: adv, teamIds: ids });
    let target = lg;
    if (lg) { Object.assign(lg, o); if (o.status === 'finished') lg.autoFinished = false; }
    else { target = Object.assign({ id: L.uid(), groups: [], bestPlayerId: null, autoFinished: false, promotionApplied: false }, o); db.leagues.push(target); }
    if (!locked) db.teams.forEach((t) => { if (ids.indexOf(t.id) >= 0 && !league(t.leagueId)) t.leagueId = target.id; });
    closeModal(!lg);
    if (lg) commit(); else { save(); location.hash = '#/league/' + target.id; }
  };
  A.delLeague = (d) => {
    const lg = league(d.id);
    const n = db.teams.filter((t) => t.leagueId === d.id).length;
    if (!confirm('لیگ «' + lg.name + '» با همه بازی‌ها و نتایجش حذف شود؟' + (n ? ' ' + fa(n) + ' تیم آن بدون لیگ می‌شوند.' : ''))) return;
    db.teams.forEach((t) => { if (t.leagueId === d.id) t.leagueId = null; });
    db.leagues = db.leagues.filter((x) => x.id !== d.id);
    db.matches = db.matches.filter((m) => m.leagueId !== d.id);
    db.events = db.events.filter((e) => e.leagueId !== d.id);
    db.awards = db.awards.filter((a) => a.leagueId !== d.id);
    save();
    if (location.hash.indexOf('#/league/') === 0) location.hash = '#/leagues'; else render(true);
  };
  A.draw = (d) => {
    const lg = league(d.id);
    const old = db.matches.filter((m) => m.leagueId === lg.id);
    if (old.some((m) => m.played && !m.bye)) return toast('بعد از ثبت نتیجه، قرعه‌کشی مجدد ممکن نیست.');
    if (lg.teamIds.length < 2) return toast('حداقل ۲ تیم لازم است.');
    if (lg.format === 'groups') {
      if (lg.teamIds.length < lg.groupCount * 2) return toast('برای ' + fa(lg.groupCount) + ' گروه حداقل ' + fa(lg.groupCount * 2) + ' تیم لازم است.');
      return groupsForm(lg);
    }
    const isLeague = lg.format === 'league';
    modal(isLeague ? 'ساخت بازی‌ها' : 'قرعه‌کشی',
      '<p class="note">' + (isLeague ? '«خودکار»: برنامه کامل هفته‌ها را برنامه می‌چیند. «دستی»: بازی‌های هر هفته را خودت وارد می‌کنی.' : '«خودکار»: برنامه تیم‌ها را تصادفی در براکت می‌گذارد. «دستی»: خودت مشخص می‌کنی کدام تیم با کدام بازی کند.') + '</p>' + (old.length ? '<p class="warn">بازی‌های فعلی حذف می‌شوند.</p>' : ''),
      '<button class="btn" data-act="drawAuto" data-id="' + lg.id + '">خودکار</button><button class="btn sec" data-act="drawManual" data-id="' + lg.id + '">دستی</button>');
  };
  A.drawAuto = (d) => {
    const lg = league(d.id);
    db.matches = db.matches.filter((m) => m.leagueId !== lg.id);
    db.matches = db.matches.concat(lg.format === 'league' ? L.genLeagueMatches(lg) : L.buildBracket(lg.id, L.shuffle(lg.teamIds)));
    L.syncStatus(db, lg);
    closeModal(); ui.tab = 'matches'; commit(); toast('بازی‌ها ساخته شد. حالا تاریخ بازی‌ها را تعیین کن.');
  };
  A.drawManual = (d) => {
    const lg = league(d.id);
    db.matches = db.matches.filter((m) => m.leagueId !== lg.id);
    ui.tab = 'matches'; save(); render(true);
    if (lg.format === 'league') weekForm(lg); else pairsForm('ko', lg, lg.teamIds);
  };
  A.gTab = (d) => { ui.gTab = d.t; render(true); };
  A.autoGroupMatches = (d) => {
    const lg = league(d.id);
    db.matches = db.matches.concat(L.groupMatches(lg, lg.groups));
    commit(); toast('بازی‌های گروهی ساخته شد');
  };

  /* گروه‌ها */
  function groupsForm(lg) {
    const names = 'ABCDEFGH', g = lg.groupCount;
    const gopts = (cur) => Array.from({ length: g }, (_, i) => '<option value="' + i + '"' + (i === cur ? ' selected' : '') + '>گروه ' + names[i] + '</option>').join('');
    modal('قرعه‌کشی گروه‌ها',
      '<label class="field"><span>روش قرعه‌کشی</span><select id="g-mode" data-change="gMode"><option value="auto">خودکار (تصادفی)</option><option value="manual">دستی (خودم تیم‌ها را در گروه‌ها می‌گذارم)</option></select></label>' +
      '<div id="g-manual" style="display:none">' + lg.teamIds.map((id, i) => '<div class="cardrow tg"><b>' + tn(id) + '</b><select class="gsel" data-team="' + id + '">' + gopts(i % g) + '</select></div>').join('') + '</div>' +
      '<label class="field"><span>بازی‌های گروهی</span><select id="g-sched"><option value="auto">ساخت خودکار برنامه</option><option value="manual">بعداً دستی وارد می‌کنم</option></select></label>' +
      (db.matches.some((m) => m.leagueId === lg.id) ? '<p class="warn">گروه‌ها و بازی‌های فعلی حذف می‌شوند.</p>' : ''),
      '<button class="btn" data-act="saveGroups" data-id="' + lg.id + '">ساخت گروه‌ها</button>');
  }
  A.saveGroups = (d) => {
    const lg = league(d.id);
    let groups;
    if (val('g-mode') === 'manual') {
      const assign = {};
      document.querySelectorAll('.gsel').forEach((x) => { assign[x.dataset.team] = parseInt(x.value, 10); });
      groups = L.groupsFromAssignment(lg, assign);
      const e = L.validateGroups(groups);
      if (e) return toast(e);
    } else groups = L.drawGroups(lg);
    db.matches = db.matches.filter((m) => m.leagueId !== lg.id);
    lg.groups = groups;
    if (val('g-sched') === 'auto') db.matches = db.matches.concat(L.groupMatches(lg, groups));
    L.syncStatus(db, lg);
    closeModal(); ui.tab = 'matches'; commit(); toast('گروه‌ها ساخته شد');
  };
  function updAdvSum() {
    const el = document.getElementById('adv-sum');
    if (!el) return;
    const tot = Array.prototype.reduce.call(document.querySelectorAll('.adv-sel'), (t, x) => t + parseInt(x.value, 10), 0);
    const S = L.nextPow2(Math.max(2, tot));
    el.textContent = 'جمعاً ' + fa(tot) + ' تیم به مرحله حذفی می‌رسند' + (tot < 2 ? ' — حداقل ۲ تیم لازم است' : tot === S ? ' (براکت ' + fa(S) + ' تیمی)' : ' — براکت ' + fa(S) + ' تیمی، ' + fa(S - tot) + ' تیم برتر بای می‌گیرند');
  }
  function advForm(lg, withKo) {
    modal(withKo ? 'ساخت مرحله حذفی' : 'تعداد صعودکنندگان',
      '<p class="note">از هر گروه چند تیم صعود کند؟ برای هر گروه می‌توانی فرق بگذاری (مثلاً از بعضی گروه‌ها ۳ تیم) تا تعداد کل درست شود.</p>' +
      lg.groups.map((g) => '<label class="field"><span>' + esc(g.name) + ' (' + fa(g.teamIds.length) + ' تیم)</span><select class="adv-sel" data-gid="' + g.id + '" data-change="koAdv">' + sel(Array.from({ length: g.teamIds.length }, (_, i) => [i + 1, fa(i + 1)]), Math.min(L.groupAdvance(lg, g), g.teamIds.length)) + '</select></label>').join('') +
      '<p class="sumline" id="adv-sum"></p>' +
      (withKo ? '<label class="field"><span>چیدن براکت</span><select id="k-mode"><option value="auto">خودکار</option><option value="manual">دستی (خودم مشخص می‌کنم)</option></select></label>' : ''),
      '<button class="btn" data-act="saveAdv" data-id="' + lg.id + '" data-ko="' + (withKo ? 1 : 0) + '">' + (withKo ? 'ادامه' : 'ذخیره') + '</button>');
    updAdvSum();
  }
  A.advSetup = (d) => advForm(league(d.id), false);
  A.makeKo = (d) => {
    const lg = league(d.id);
    const gm = db.matches.filter((m) => m.leagueId === lg.id && m.stage === 'group');
    if (!gm.length || !gm.every(L.settled)) return toast('بازی‌های گروهی هنوز تمام نشده (بازی معوقه باقی مانده).');
    advForm(lg, true);
  };
  A.saveAdv = (d) => {
    const lg = league(d.id);
    const v = {};
    document.querySelectorAll('.adv-sel').forEach((x) => { v[x.dataset.gid] = parseInt(x.value, 10); });
    const tot = Object.keys(v).reduce((t, k) => t + v[k], 0);
    if (tot < 2) return toast('حداقل ۲ تیم باید صعود کنند.');
    lg.groups.forEach((g) => { g.advance = v[g.id]; });
    if (d.ko !== '1') { closeModal(); commit(); return toast('ذخیره شد'); }
    if (val('k-mode') === 'manual') {
      const seeds = L.qualified(db, lg);
      return pairsForm('gko', lg, seeds);
    }
    const r = L.groupsToKo(db, lg);
    if (r.error) return toast(r.error);
    db.matches = db.matches.concat(r.matches);
    closeModal(); commit(); toast('مرحله حذفی ساخته شد');
  };

  /* براکت دستی */
  function pairsForm(kind, lg, teamIds) {
    const n = teamIds.length, S = L.nextPow2(n), k = S / 2, byes = S - n;
    const sug = kind === 'gko' ? L.suggestPairs(teamIds, L.groupOfMap(lg)) : L.suggestPairs(L.shuffle(teamIds));
    ui.pair = { kind, id: lg.id, teamIds, sug };
    const opts = '<option value="">— انتخاب —</option>' + (byes ? '<option value="bye">بای (بدون حریف)</option>' : '') + teamIds.map((id) => '<option value="' + id + '">' + tn(id) + '</option>').join('');
    let rows = '';
    for (let i = 0; i < k; i++) rows += '<div class="cardrow pr"><select id="pr-h-' + i + '" aria-label="تیم اول بازی ' + fa(i + 1) + '">' + opts + '</select><select id="pr-a-' + i + '" aria-label="تیم دوم بازی ' + fa(i + 1) + '">' + opts + '</select></div>';
    modal(kind === 'gko' ? 'براکت مرحله حذفی (دستی)' : 'قرعه دستی',
      '<p class="note">' + fa(n) + ' تیم • دور اول ' + fa(k) + ' بازی' + (byes ? ' • ' + fa(byes) + ' بای (تیمی که بای می‌گیرد مستقیم به دور بعد می‌رود)' : '') + '</p>' + rows,
      '<button class="btn" data-act="savePairs">ساخت براکت</button><button class="btn sec" data-act="fillPairs">پر کردن خودکار</button>');
  }
  A.fillPairs = () => {
    ui.pair.sug.forEach((p, i) => { document.getElementById('pr-h-' + i).value = p[0] || 'bye'; document.getElementById('pr-a-' + i).value = p[1] || 'bye'; });
  };
  A.savePairs = () => {
    const c = ui.pair, lg = league(c.id), k = L.nextPow2(c.teamIds.length) / 2, pairs = [];
    for (let i = 0; i < k; i++) {
      const a = val('pr-h-' + i), b = val('pr-a-' + i);
      if (!a || !b) return toast('همه بازی‌ها را کامل کن.');
      pairs.push([a === 'bye' ? null : a, b === 'bye' ? null : b]);
    }
    if (c.kind === 'ko') {
      const e = L.validatePairs(c.teamIds, pairs);
      if (e) return toast(e);
      db.matches = db.matches.filter((m) => m.leagueId !== lg.id).concat(L.buildBracketPairs(lg.id, pairs));
    } else {
      const r = L.groupsToKo(db, lg, pairs);
      if (r.error) return toast(r.error);
      db.matches = db.matches.concat(r.matches);
    }
    L.syncStatus(db, lg);
    closeModal(); ui.tab = 'matches'; commit(); toast('براکت ساخته شد');
  };
  A.applyPromo = (d) => {
    const lg = league(d.id);
    const p = L.promotionPlan(db, lg);
    const names = (ids) => ids.map((id) => (team(id) ? team(id).name : '')).join('، ') || '—';
    if (!confirm('صعود: ' + names(p.up) + '\nسقوط: ' + names(p.down) + '\n\nاعمال شود؟')) return;
    const err = L.applyPromotion(db, lg);
    if (err) return toast(err);
    commit(); toast('صعود و سقوط اعمال شد');
  };

  /* --- تاریخ بازی‌ها --- */
  A.roundDate = (d) => {
    modal('تاریخ این دور', '<div class="field"><span>تاریخ بازی‌های برگزارنشده</span>' + dateInput('r-date', L.today()) + '</div><label class="field"><span>ساعت (اختیاری، برای همه بازی‌های این دور)</span><input id="r-time" type="time"></label>', '<button class="btn" data-act="saveRoundDate" data-ids="' + d.ids + '">ذخیره</button>');
  };
  A.saveRoundDate = (d) => {
    const date = readDate('r-date');
    if (!date) return toast('تاریخ معتبر نیست');
    const ids = d.ids.split(',');
    const time = val('r-time');
    db.matches.forEach((m) => { if (ids.indexOf(m.id) >= 0 && !m.played) { m.date = date; if (time) m.time = time; } });
    closeModal(); commit(); toast('تاریخ ثبت شد');
  };
  A.autoDates = (d) => {
    modal('تاریخ‌گذاری خودکار', '<p class="note">دورها به ترتیب، با فاصله مشخص تاریخ می‌گیرند. فقط بازی‌های برگزارنشده تغییر می‌کنند.</p><div class="field"><span>تاریخ دور اول</span>' + dateInput('a-date', L.today()) + '</div><label class="field"><span>فاصله بین دورها (روز)</span><input id="a-gap" type="number" inputmode="numeric" min="1" value="7"></label><label class="field"><span>ساعت بازی‌ها (اختیاری)</span><input id="a-time" type="time"></label>',
      '<button class="btn" data-act="saveAutoDates" data-id="' + d.id + '">اعمال</button>');
  };
  A.saveAutoDates = (d) => {
    const start = readDate('a-date'); const gap = parseInt(val('a-gap'), 10);
    if (!start) return toast('تاریخ معتبر نیست');
    if (!(gap >= 1)) return toast('فاصله دورها حداقل ۱ روز است');
    roundGroups(db.matches.filter((m) => m.leagueId === d.id)).forEach((g, i) => { g.forEach((m) => { if (!m.played) { m.date = L.addDays(start, i * gap); if (val('a-time')) m.time = val('a-time'); } }); });
    closeModal(); commit(); toast('تاریخ بازی‌ها ثبت شد');
  };
  function weekRow(lg, h, a) {
    const opts = (cur) => '<option value="">— تیم —</option>' + lg.teamIds.map((id) => '<option value="' + id + '"' + (id === cur ? ' selected' : '') + '>' + tn(id) + '</option>').join('');
    return '<div class="cardrow wk"><select class="wh" aria-label="میزبان">' + opts(h) + '</select><select class="wa" aria-label="مهمان">' + opts(a) + '</select><input class="wt" type="time" aria-label="ساعت بازی"><button class="icon-btn bad" data-act="rmWeekRow" aria-label="حذف ردیف">' + icon('trash') + '</button></div>';
  }
  function weekForm(lg, round) {
    const stage = lg.format === 'groups' ? 'group' : 'league';
    const last = Math.max.apply(null, [0].concat(db.matches.filter((m) => m.leagueId === lg.id && m.stage === stage).map((m) => m.round)));
    const rows = Math.max(1, Math.floor(lg.teamIds.length / 2));
    ui.weekLg = lg.id;
    modal('بازی‌های یک هفته',
      '<label class="field"><span>شماره هفته</span><input id="w-round" type="number" inputmode="numeric" min="1" value="' + (round || last + 1) + '"></label>' +
      '<label class="check"><input type="checkbox" id="w-nodate" data-change="noDate" checked><span>تاریخ را بعداً تعیین می‌کنم</span></label>' +
      '<div class="field" id="w-datebox" style="display:none"><span>تاریخ این هفته</span>' + dateInput('w-date') + '</div>' +
      '<h4 class="sech">بازی‌ها (میزبان - مهمان - ساعت اختیاری)</h4><div id="wrows">' + Array.from({ length: rows }, () => weekRow(lg)).join('') + '</div>' +
      '<button class="btn sec" style="margin-top:8px" data-act="addWeekRow">' + icon('plus') + ' افزودن بازی</button>',
      '<button class="btn" data-act="saveWeek" data-id="' + lg.id + '" data-next="0">ذخیره</button><button class="btn sec" data-act="saveWeek" data-id="' + lg.id + '" data-next="1">ذخیره و هفته بعد</button>');
  }
  A.addWeek = (d) => weekForm(league(d.id));
  A.addWeekRow = () => { document.getElementById('wrows').insertAdjacentHTML('beforeend', weekRow(league(ui.weekLg))); };
  A.rmWeekRow = (d, el) => { const r = el.closest('.wk'); if (r) r.remove(); };
  A.saveWeek = (d) => {
    const lg = league(d.id);
    const round = parseInt(val('w-round'), 10);
    const noDate = document.getElementById('w-nodate').checked;
    const date = noDate ? null : readDate('w-date');
    if (!noDate && !date) return toast('تاریخ معتبر نیست');
    const pairs = Array.prototype.map.call(document.querySelectorAll('#wrows .wk'), (r) => [r.querySelector('.wh').value, r.querySelector('.wa').value, r.querySelector('.wt').value || null]).filter((p) => p[0] || p[1]);
    const err = L.addWeek(db, lg, round, date, pairs);
    if (err) return toast(err);
    save();
    toast('بازی‌های هفته ' + fa(round) + ' ثبت شد');
    if (d.next === '1') { render(true); weekForm(lg, round + 1); } else { closeModal(); commit(); }
  };

  /* --- نتیجه بازی --- */
  const popts = (tid, cur, susp) => players(tid).map((p) => {
    const s = susp[p.id];
    return '<option value="' + p.id + '"' + (cur === p.id ? ' selected' : '') + (s && cur !== p.id ? ' disabled' : '') + '>' + fa(p.number) + ' - ' + esc(p.name) + (s ? ' (محروم)' : '') + '</option>';
  }).join('');
  function syncEdit() {
    const me = ui.edit;
    ['h', 'a'].forEach((side) => {
      const n = Math.min(30, Math.max(0, parseInt(val(side === 'h' ? 'm-hg' : 'm-ag'), 10) || 0));
      me[side] = me[side].slice(0, n);
      while (me[side].length < n) me[side].push('');
    });
  }
  function drawScorers() {
    const me = ui.edit, m = me.m;
    syncEdit();
    const box = document.getElementById('scorers');
    if (!box) return;
    box.innerHTML = ['h', 'a'].map((side) => {
      const tid = side === 'h' ? m.home : m.away;
      if (!me[side].length) return '';
      return '<div class="sc-group"><h4>گلزنان ' + tn(tid) + '</h4>' + me[side].map((v, i) => '<select data-change="scorerSel" data-side="' + side + '" data-i="' + i + '" aria-label="گلزن"><option value="">گلزن نامشخص</option><option value="og"' + (v === 'og' ? ' selected' : '') + '>گل به خودی (از تیم حریف)</option>' + popts(tid, v, me.susp) + '</select>').join('') + '</div>';
    }).join('');
    const ko = m.stage === 'ko' || m.stage === 'third';
    const eq = val('m-hg') !== '' && val('m-hg') === val('m-ag');
    document.getElementById('pens').style.display = ko && eq ? '' : 'none';
  }
  function drawCards() {
    const me = ui.edit, m = me.m;
    const box = document.getElementById('cards');
    if (!box) return;
    box.innerHTML = me.cards.map((c, i) => '<div class="cardrow"><select data-change="cardSel" data-k="p" data-i="' + i + '" aria-label="بازیکن"><option value="">انتخاب بازیکن</option>' +
      [m.home, m.away].map((tid) => '<optgroup label="' + esc(team(tid).name) + '">' + popts(tid, c.p, me.susp) + '</optgroup>').join('') + '</select>' +
      '<select data-change="cardSel" data-k="t" data-i="' + i + '" aria-label="نوع کارت">' + sel(Object.keys(CARD_SHORT).map((k) => [k, CARD_SHORT[k]]), c.t) + '</select>' +
      '<button class="icon-btn bad" data-act="rmCard" data-i="' + i + '" aria-label="حذف کارت">' + icon('trash') + '</button></div>').join('') +
      (me.cards.length ? '' : '<p class="note">کارتی ثبت نشده.</p>');
  }
  A.addCard = () => { ui.edit.cards.push({ p: '', t: 'yellow' }); drawCards(); };
  A.rmCard = (d) => { ui.edit.cards.splice(parseInt(d.i, 10), 1); drawCards(); };

  A.openMatch = (d) => {
    const m = db.matches.find((x) => x.id === d.id);
    if (!m || m.bye) return;
    const lg = league(m.leagueId);
    if (!m.home || !m.away) return modal(m.roundName || 'بازی', '<p class="note">تیم‌های این بازی بعد از پایان دور قبل مشخص می‌شوند.</p>');
    const fromHome = d.home === '1';
    const evs = db.events.filter((e) => e.matchId === m.id);
    const side = (tid) => evs.filter((e) => e.teamId === tid && (e.type === 'goal' || e.type === 'og')).map((e) => (e.type === 'og' ? 'og' : (e.playerId || '')));
    const susp = L.suspendedFor(db, m);
    ui.edit = { m, h: side(m.home), a: side(m.away), cards: evs.filter((e) => L.CARD_TYPES.indexOf(e.type) >= 0).map((e) => ({ p: e.playerId || '', t: e.type })), susp, fromHome };
    const mv = db.awards.find((a) => a.matchId === m.id && a.type === 'mvp');
    const mvOpts = [m.home, m.away].map((tid) => '<optgroup label="' + esc(team(tid).name) + '">' + popts(tid, mv && mv.playerId, susp) + '</optgroup>').join('');
    const suspNames = Object.keys(susp).map((id) => esc(player(id).name) + ' (' + fa(susp[id]) + ' جلسه)').join('، ');
    const canLose = !(m.stage === 'ko' || m.stage === 'third');
    const stBtn = (k, ic) => (k !== 'postponed' && !canLose) ? '' : '<button class="stbtn ' + k + (m.state === k ? ' on' : '') + '" data-act="setState" data-id="' + m.id + '" data-s="' + k + '">' + icon(ic) + '<span>' + STATE[k] + '</span></button>';
    const stBox = '<h4 class="sech" style="margin-top:4px">وضعیت بازی</h4><div class="stgrid">' + stBtn('notheld', 'ban') + stBtn('cancelled', 'x') + stBtn('postponed', 'clock') + '</div>' +
      (m.state ? '<p class="warn st-' + m.state + '">این بازی «' + STATE[m.state] + '» ثبت شده است. برای بازگرداندن، دوباره روی همان گزینه بزن یا نتیجه را ذخیره کن.</p>' : (canLose ? '' : '<p class="note" style="margin-top:6px">در مرحله حذفی فقط تعویق ممکن است.</p>'));
    const body = stBox + '<div class="vs"><label>' + tn(m.home) + '<input id="m-hg" data-input="goals" type="number" inputmode="numeric" min="0" max="99" value="' + (m.played ? m.hg : '') + '" placeholder="۰"></label>' +
      '<label>' + tn(m.away) + '<input id="m-ag" data-input="goals" type="number" inputmode="numeric" min="0" max="99" value="' + (m.played ? m.ag : '') + '" placeholder="۰"></label></div>' +
      '<div id="pens" style="display:none"><div class="grid2"><label class="field"><span>پنالتی ' + tn(m.home) + '</span><input id="m-hp" type="number" inputmode="numeric" min="0" value="' + (m.hp != null ? m.hp : '') + '"></label><label class="field"><span>پنالتی ' + tn(m.away) + '</span><input id="m-ap" type="number" inputmode="numeric" min="0" value="' + (m.ap != null ? m.ap : '') + '"></label></div></div>' +
      (suspNames ? '<p class="warn">محروم این بازی: ' + suspNames + '</p>' : '') +
      '<div id="scorers"></div>' +
      '<h4 class="sech">کارت‌ها</h4><div id="cards"></div><button class="btn sec" style="margin-top:8px" data-act="addCard">' + icon('plus') + ' افزودن کارت</button>' +
      '<label class="field"><span>بهترین بازیکن زمین (اختیاری)</span><select id="m-mvp"><option value="">— انتخاب نشده —</option>' + mvOpts + '</select></label>' +
      (fromHome ? '' : '<div class="field"><span>تاریخ بازی</span>' + dateInput('m-date', m.date || L.today()) + '</div>') +
      '<label class="field"><span>ساعت بازی (اختیاری)</span><input id="m-time" type="time" value="' + esc(m.time || '') + '"></label>';
    let act = '<button class="btn" data-act="saveMatch" data-id="' + m.id + '">ذخیره نتیجه</button>';
    if (!fromHome && !m.played) act += '<button class="btn sec" data-act="saveDate" data-id="' + m.id + '">فقط ذخیره زمان</button>';
    if (m.played) act += '<button class="btn danger" data-act="clearMatch" data-id="' + m.id + '">پاک کردن نتیجه</button>';
    if (!fromHome && (m.stage === 'league' || m.stage === 'group')) act += '<button class="btn danger" data-act="delMatch" data-id="' + m.id + '">حذف بازی</button>';
    modal((m.roundName ? m.roundName + ' • ' : '') + (lg ? lg.name : 'بازی'), body, act);
    drawScorers(); drawCards();
  };
  A.saveMatch = (d) => {
    const m = db.matches.find((x) => x.id === d.id);
    const hg = parseInt(val('m-hg'), 10), ag = parseInt(val('m-ag'), 10);
    if (isNaN(hg) || isNaN(ag) || hg < 0 || ag < 0) return toast('گل هر دو تیم را وارد کن');
    const date = ui.edit.fromHome ? (m.date || L.today()) : readDate('m-date');
    if (!date) return toast('تاریخ معتبر نیست');
    syncEdit();
    const events = [];
    [['h', m.home], ['a', m.away]].forEach(([s, tid]) => ui.edit[s].forEach((v) => events.push({ teamId: tid, playerId: v && v !== 'og' ? v : null, type: v === 'og' ? 'og' : 'goal' })));
    ui.edit.cards.forEach((c) => { if (c.p && player(c.p)) events.push({ teamId: player(c.p).teamId, playerId: c.p, type: c.t }); });
    const hp = val('m-hp'), ap = val('m-ap');
    const err = L.saveResult(db, m, { hg, ag, hp: hp === '' ? null : parseInt(hp, 10), ap: ap === '' ? null : parseInt(ap, 10), date, time: val('m-time') || null, events, mvp: val('m-mvp') || null });
    if (err) return toast(err);
    closeModal(); commit(); toast('نتیجه ذخیره شد');
  };
  A.saveDate = (d) => {
    const m = db.matches.find((x) => x.id === d.id);
    const date = readDate('m-date');
    if (!date) return toast('تاریخ معتبر نیست');
    m.date = date; m.time = val('m-time') || null; closeModal(); commit(); toast('زمان بازی ثبت شد');
  };
  A.clearMatch = (d) => {
    const m = db.matches.find((x) => x.id === d.id);
    if (!confirm('نتیجه این بازی پاک شود؟')) return;
    const err = L.clearResult(db, m);
    if (err) return toast(err);
    closeModal(); commit(); toast('نتیجه پاک شد');
  };
  A.setState = (d) => {
    const m = db.matches.find((x) => x.id === d.id);
    if (!m) return;
    const next = m.state === d.s ? null : d.s;
    if (next && m.played && !confirm('نتیجه ثبت‌شده این بازی پاک می‌شود و بازی «' + STATE[next] + '» ثبت می‌شود. ادامه؟')) return;
    const err = L.setState(db, m, next);
    if (err) return toast(err);
    closeModal(); commit();
    toast(next ? 'بازی «' + STATE[next] + '» ثبت شد' : 'وضعیت بازی به حالت عادی برگشت');
  };
  A.delMatch = (d) => {
    if (!confirm('این بازی حذف شود؟')) return;
    db.matches = db.matches.filter((x) => x.id !== d.id);
    db.events = db.events.filter((e) => e.matchId !== d.id);
    db.awards = db.awards.filter((a) => a.matchId !== d.id);
    db.leagues.forEach((lg) => L.syncStatus(db, lg));
    closeModal(); commit();
  };
  A.viewMatch = (d) => {
    const m = db.matches.find((x) => x.id === d.id);
    if (!m) return;
    const lg = league(m.leagueId);
    const evs = db.events.filter((e) => e.matchId === m.id);
    const pn = (id) => (player(id) ? esc(player(id).name) : 'بازیکن نامشخص');
    const goals = (tid) => evs.filter((e) => e.teamId === tid && (e.type === 'goal' || e.type === 'og')).map((e) => (e.type === 'og' ? 'گل به خودی' : pn(e.playerId)));
    const mv = db.awards.find((a) => a.matchId === m.id && a.type === 'mvp');
    let b = '<div class="vs"><div class="vcol"><b>' + tn(m.home) + '</b><span class="score">' + (m.played ? '<b>' + fa(m.hg) + '</b>' : '–') + '</span></div><div class="vcol"><b>' + tn(m.away) + '</b><span class="score">' + (m.played ? '<b>' + fa(m.ag) + '</b>' : '–') + '</span></div></div>';
    if (m.date) b += '<div class="kv"><span>زمان بازی</span><span>' + L.dayInfo(m.date, m.time) + '</span></div>';
    if (m.played && m.hp != null) b += '<p class="note" style="text-align:center">پنالتی ' + fa(m.hp) + ' - ' + fa(m.ap) + '</p>';
    if (m.played) {
      [m.home, m.away].forEach((tid) => { const g = goals(tid); if (g.length) b += '<div class="kv"><span>گلزنان ' + tn(tid) + '</span><span>' + g.join('، ') + '</span></div>'; });
      const cs = evs.filter((e) => L.CARD_TYPES.indexOf(e.type) >= 0);
      if (cs.length) b += '<div class="kv"><span>کارت‌ها</span><span>' + cs.map((e) => pn(e.playerId) + ' (' + CARD[e.type] + ')').join('<br>') + '</span></div>';
      if (mv) b += '<div class="kv"><span>بهترین بازیکن</span><span>' + pn(mv.playerId) + '</span></div>';
    } else if (m.state) b += '<p class="warn st-' + m.state + '" style="text-align:center">' + STATE[m.state] + '</p>';
    else b += '<p class="note" style="text-align:center">این بازی هنوز برگزار نشده است.</p>';
    b += '<p class="note" style="margin-top:12px">ثبت و ویرایش نتیجه بازی‌های غیر از امروز، فقط از صفحه لیگ ممکن است.</p>';
    modal((m.roundName ? m.roundName + ' • ' : '') + (lg ? lg.name : 'بازی'), b, lg ? '<a class="btn" href="#/league/' + lg.id + '">رفتن به صفحه لیگ</a>' : '');
  };

  /* --- پوستر: ساخت، اشتراک‌گذاری، ذخیره --- */
  function capPlugin(name) {
    const C = window.Capacitor;
    if (!C || !(C.isNativePlatform && C.isNativePlatform())) return null;
    try { return (C.Plugins && C.Plugins[name]) || (C.registerPlugin && C.registerPlugin(name)) || null; } catch (e) { return null; }
  }
  let posterSeq = 0;
  async function drawPoster() {
    const pc = ui.poster, lg = league(pc.lid), box = document.getElementById('pbox');
    if (!lg || !box) return;
    const my = ++posterSeq;
    box.innerHTML = '<p class="note ploading">در حال ساخت پوستر…</p>';
    try {
      const cv = await window.Poster.render(posterContent(lg, pc.spec, pc.opts), posterOf(lg), lg.name);
      if (my !== posterSeq || !document.getElementById('pbox')) return;
      pc.canvas = cv; cv.className = 'pcanvas'; cv.removeAttribute('style');
      box.innerHTML = ''; box.appendChild(cv);
    } catch (e) { box.innerHTML = '<p class="warn">ساخت پوستر انجام نشد.</p>'; }
  }
  function openPoster() {
    const pc = ui.poster;
    const hasSc = pc.spec.k === 'week' || pc.spec.k === 'ko';
    modal('پوستر', '<div id="pbox" class="pbox"></div>' +
      (hasSc ? '<label class="check"><input type="checkbox" id="po-sc" data-change="posterOpt"' + (pc.opts.scorers ? ' checked' : '') + '><span>نمایش گلزنان</span></label>' : '') +
      '<p class="note">پس‌زمینه و متن پوستر را از «ویرایش پس‌زمینه» عوض کن؛ برای همه پوسترهای این لیگ یکسان می‌ماند.</p>',
      '<button class="btn" data-act="posterShare">' + icon('share') + ' ارسال</button><button class="btn sec" data-act="posterSave">' + icon('download') + ' ذخیره</button><button class="btn sec" data-act="posterBg" data-id="' + pc.lid + '">' + icon('image') + ' ویرایش پس‌زمینه</button>');
    drawPoster();
  }
  A.poster = (d) => {
    const lg = league(ui.leagueId);
    if (!lg) return;
    ui.poster = { lid: lg.id, spec: { k: d.k, r: d.r === '' ? '' : parseInt(d.r, 10), g: d.g || '' }, opts: { scorers: true }, canvas: null };
    openPoster();
  };
  C.posterOpt = (el) => { if (ui.poster) { ui.poster.opts.scorers = el.checked; drawPoster(); } };
  const posterName = () => { const sp = ui.poster.spec; return 'futsal-' + sp.k + (sp.r !== '' ? '-' + sp.r : '') + '-' + Date.now() + '.png'; };
  const posterB64 = () => ui.poster.canvas.toDataURL('image/png').split(',')[1];
  function downloadFallback() {
    ui.poster.canvas.toBlob((b) => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(b); a.download = posterName();
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      toast('پوستر دانلود شد');
    }, 'image/png');
  }
  A.posterShare = async () => {
    if (!ui.poster || !ui.poster.canvas) return toast('پوستر هنوز آماده نیست');
    const name = posterName(), FS = capPlugin('Filesystem'), SH = capPlugin('Share');
    try {
      if (FS && SH) {
        const r = await FS.writeFile({ path: name, data: posterB64(), directory: 'CACHE' });
        await SH.share({ title: 'پوستر لیگ فوتسال', files: [r.uri], dialogTitle: 'ارسال پوستر' });
        return;
      }
      const blob = await new Promise((res) => ui.poster.canvas.toBlob(res, 'image/png'));
      const file = new File([blob], name, { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: 'پوستر لیگ فوتسال' }); return; }
      downloadFallback();
    } catch (e) {
      if (e && (e.name === 'AbortError' || /cancel/i.test(String(e.message || e)))) return;
      toast('ارسال انجام نشد. از «ذخیره» استفاده کن.');
    }
  };
  A.posterSave = async () => {
    if (!ui.poster || !ui.poster.canvas) return toast('پوستر هنوز آماده نیست');
    const FS = capPlugin('Filesystem');
    if (!FS) return downloadFallback();
    const name = posterName();
    try {
      try { await FS.requestPermissions(); } catch (e) { /* خالی */ }
      await FS.writeFile({ path: 'FutsalLeague/' + name, data: posterB64(), directory: 'DOCUMENTS', recursive: true });
      toast('ذخیره شد: پوشه Documents/FutsalLeague');
    } catch (e) {
      toast('ذخیره مستقیم ممکن نشد. از «ارسال» و گزینه ذخیره در منوی اشتراک استفاده کن.');
    }
  };

  /* ویرایش پس‌زمینه پوستر هر لیگ */
  function pickImage(file, max, type, q) {
    return new Promise((res, rej) => {
      const fr = new FileReader();
      fr.onerror = () => rej(new Error('read'));
      fr.onload = () => {
        const img = new Image();
        img.onerror = () => rej(new Error('img'));
        img.onload = () => {
          const k = Math.min(1, max / Math.max(img.width, img.height));
          const c = document.createElement('canvas');
          c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          let out = c.toDataURL(type, q), qq = q;
          while (type === 'image/jpeg' && out.length > 420000 && qq > 0.45) { qq -= 0.1; out = c.toDataURL(type, qq); }
          res(out);
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }
  let pvT;
  function drawDraftPreview() {
    clearTimeout(pvT);
    pvT = setTimeout(async () => {
      const box = document.getElementById('pd-prev');
      if (!box || !ui.pd) return;
      const lg = league(ui.pdLid);
      const sample = { heading: 'نتایج هفته ' + fa(1), sub: L.weekday(L.today()) + ' ' + L.fmtDate(L.today()), sections: [{ title: '', matches: [
        { home: 'تیم اول', away: 'تیم دوم', played: true, hg: 3, ag: 1, dateLine: 'ساعت ' + fa('18:00'), hs: 'علی احمدی (۲)، رضا کریمی', as: 'مهدی نوری' },
        { home: 'تیم سوم', away: 'تیم چهارم', played: true, hg: 2, ag: 2, dateLine: 'ساعت ' + fa('19:30'), hs: '', as: '' },
        { home: 'تیم پنجم', away: 'تیم ششم', played: false, state: 'postponed', dateLine: '', hs: '', as: '' }] }] };
      try {
        const cv = await window.Poster.render(sample, ui.pd, lg ? lg.name : '');
        if (!document.getElementById('pd-prev')) return;
        cv.className = 'pcanvas'; cv.removeAttribute('style');
        box.innerHTML = ''; box.appendChild(cv);
      } catch (e) { /* خالی */ }
    }, 120);
  }
  function editPosterForm(lid) {
    const lg = league(lid);
    ui.pdLid = lid; ui.pd = posterOf(lg);
    const d = ui.pd, T = window.Poster.THEMES, N = window.Poster.THEME_NAMES;
    const pick = (w, label, has) => '<div class="pick"><span class="grow"><b>' + label + '</b><small id="pk-' + w + '">' + (has ? 'انتخاب شده ✓' : 'انتخاب نشده') + '</small></span><label class="btn sec sm" for="pf-' + w + '">انتخاب</label><button class="btn danger sm" data-act="pdClear" data-w="' + w + '">حذف</button><input id="pf-' + w + '" type="file" accept="image/*" data-change="pdFile" data-w="' + w + '" hidden></div>';
    modal('پس‌زمینه پوستر ' + lg.name,
      '<div id="pd-prev" class="pbox small"></div>' +
      '<div class="card inner">' + pick('bg', 'عکس پس‌زمینه', d.bg) + pick('logo', 'لوگوی بالا', d.logo) + pick('logo2', 'لوگو یا اسپانسر پایین', d.logo2) + '</div>' +
      '<label class="field"><span>عنوان بالای پوستر (خالی = نام لیگ)</span><input id="pd-title" data-input="pdraft" value="' + esc(d.title) + '" maxlength="60" placeholder="' + esc(lg.name) + '" autocomplete="off"></label>' +
      '<label class="field"><span>زیرعنوان (مثلاً فصل، شهر، سالن)</span><input id="pd-sub" data-input="pdraft" value="' + esc(d.subtitle) + '" maxlength="80" autocomplete="off"></label>' +
      '<label class="field"><span>متن پایین (مثلاً اسپانسر یا کانال)</span><input id="pd-foot" data-input="pdraft" value="' + esc(d.footer) + '" maxlength="120" autocomplete="off"></label>' +
      '<div class="grid2"><label class="field"><span>رنگ (بدون عکس / تأکید)</span><select id="pd-theme" data-change="pdraft">' + Object.keys(T).map((k) => '<option value="' + k + '"' + (d.theme === k ? ' selected' : '') + '>' + N[k] + '</option>').join('') + '</select></label>' +
      '<label class="field"><span>تیرگی روی عکس</span><select id="pd-ov" data-change="pdraft">' + sel([[0, 'بدون'], [20, 'کم'], [40, 'متوسط'], [60, 'زیاد'], [80, 'خیلی زیاد']], d.overlay) + '</select></label></div>',
      '<button class="btn" data-act="savePoster" data-id="' + lid + '">ذخیره</button><button class="btn danger" data-act="resetPoster" data-id="' + lid + '">پیش‌فرض</button>');
    drawDraftPreview();
  }
  A.editPoster = (d) => { ui.afterPoster = false; editPosterForm(d.id); };
  A.posterBg = (d) => { ui.afterPoster = true; editPosterForm(d.id); };
  function readDraft() {
    if (!ui.pd) return;
    ui.pd.title = val('pd-title').trim(); ui.pd.subtitle = val('pd-sub').trim(); ui.pd.footer = val('pd-foot').trim();
    ui.pd.theme = val('pd-theme') || 'blue'; ui.pd.overlay = parseInt(val('pd-ov'), 10) || 0;
  }
  I.pdraft = () => { readDraft(); drawDraftPreview(); };
  C.pdraft = () => { readDraft(); drawDraftPreview(); };
  C.pdFile = async (el) => {
    const f = el.files && el.files[0], w = el.dataset.w;
    if (!f || !ui.pd) return;
    try {
      ui.pd[w] = w === 'bg' ? await pickImage(f, 1400, 'image/jpeg', 0.8) : await pickImage(f, 360, 'image/png');
      const t = document.getElementById('pk-' + w); if (t) t.textContent = 'انتخاب شده ✓';
      drawDraftPreview();
    } catch (e) { toast('این فایل عکس معتبر نیست'); }
    el.value = '';
  };
  A.pdClear = (d) => { if (!ui.pd) return; ui.pd[d.w] = ''; const t = document.getElementById('pk-' + d.w); if (t) t.textContent = 'انتخاب نشده'; drawDraftPreview(); };
  A.savePoster = (d) => {
    const lg = league(d.id);
    readDraft();
    lg.poster = Object.assign({}, ui.pd);
    const again = ui.afterPoster && ui.poster && ui.poster.lid === d.id;
    closeModal(); commit(); toast('پس‌زمینه پوستر ذخیره شد');
    if (again) setTimeout(openPoster, 80);
  };
  A.resetPoster = (d) => {
    if (!confirm('عکس‌ها و متن‌های پوستر این لیگ به حالت پیش‌فرض برگردد؟')) return;
    ui.pd = Object.assign({}, window.Poster.DEF);
    editPosterForm(d.id);
  };

  /* --- پروفایل و داده‌ها --- */
  A.demo = () => {
    if (lvl() !== 2) return toast('این کار فقط برای کاربر سطح ۲ است');
    if ((db.teams.length || db.leagues.length) && !confirm('داده‌های فعلی با داده نمونه جایگزین شود؟')) return;
    const keep = { user: db.user, dark: db.settings.dark };
    db = L.demo(); db.user = keep.user; db.settings = Object.assign({}, db.settings, { dark: keep.dark }); save(); location.hash = '#/home'; render(false);
  };
  A.resetAll = () => {
    if (lvl() !== 2) return toast('این کار فقط برای کاربر سطح ۲ است');
    if (!confirm('همه تیم‌ها، لیگ‌ها و نتایج حذف شود؟ این کار قابل بازگشت نیست.')) return;
    const dark = db.settings.dark, user = db.user; db = L.emptyDb(); db.settings.dark = dark; db.user = user; save(); render(false); toast('همه داده‌ها حذف شد');
  };
  A.exportDb = () => {
    if (lvl() > 2) return toast('اجازه این کار را نداری');
    modal('پشتیبان‌گیری', '<p class="note">این متن را کپی کن و جایی امن نگه دار (مثلاً در پیام‌های ذخیره‌شده).</p><label class="field"><textarea id="x-json" readonly>' + esc(JSON.stringify(db)) + '</textarea></label>', '<button class="btn" data-act="copyDb">کپی متن</button>');
  };
  A.copyDb = () => {
    const t = document.getElementById('x-json'); t.select();
    try { if (navigator.clipboard) navigator.clipboard.writeText(t.value); else document.execCommand('copy'); toast('کپی شد'); } catch (e) { toast('متن را به‌صورت دستی کپی کن'); }
  };
  A.importDb = () => {
    if (lvl() > 2) return toast('اجازه این کار را نداری');
    modal('بازیابی', '<p class="note">متن پشتیبان را اینجا بچسبان. داده‌های فعلی جایگزین می‌شود.</p><label class="field"><textarea id="x-json"></textarea></label>', '<button class="btn" data-act="importDo">بازیابی</button>');
  };
  A.importDo = () => {
    if (lvl() > 2) return toast('اجازه این کار را نداری');
    try {
      const d = JSON.parse(val('x-json'));
      if (!d || !Array.isArray(d.teams) || !Array.isArray(d.leagues) || !Array.isArray(d.matches)) throw new Error('bad');
      const mine = db.user;
      if (lvl() === 1) {
        // مالک: فقط اضافه یا جایگزین می‌شود تا داده سایر کاربران پاک نشود
        const keep = db.settings;
        KINDS.forEach((k) => (d[k] || []).forEach((o) => { const i = db[k].findIndex((x) => x.id === o.id); if (i >= 0) db[k][i] = o; else db[k].push(o); }));
        db = L.normalize(db); db.settings = keep; db.user = mine;
        save(); closeModal(); render(false); toast('بازیابی انجام شد'); return;
      }
      db = L.normalize(d);
      if (!d.user) db.user = mine;
      save(); closeModal(); render(false); toast('بازیابی انجام شد');
    } catch (e) { toast('متن پشتیبان معتبر نیست'); }
  };

  /* ---------- رویدادها ---------- */
  I.teamSearch = (el) => {
    ui.q = el.value;
    const l = document.getElementById('teamList'); if (l) l.innerHTML = teamItems();
    const n = document.getElementById('teamNote'); if (n) n.innerHTML = ui.q.trim() ? '' : (league(ui.teamTab) ? leagueNote(league(ui.teamTab)) : '');
  };
  I.goals = () => drawScorers();
  C.fmtChange = () => I.fmtChange();
  C.scorerSel = (el) => { if (ui.edit) ui.edit[el.dataset.side][parseInt(el.dataset.i, 10)] = el.value; };
  C.cardSel = (el) => { if (ui.edit) ui.edit.cards[parseInt(el.dataset.i, 10)][el.dataset.k] = el.value; };
  C.gMode = (el) => { const m = document.getElementById('g-manual'); if (m) m.style.display = el.value === 'manual' ? '' : 'none'; };
  C.koAdv = () => updAdvSum();
  C.noDate = (el) => { const b = document.getElementById('w-datebox'); if (b) b.style.display = el.checked ? 'none' : ''; };
  C.bestPlayer = (el) => {
    if (!Auth.can('league.best')) { toast(denyMsg); render(true); return; } if (!Auth.can('league.best')) { toast('اجازه انجام این کار را نداری'); render(true); return; } const lg = league(el.dataset.id); lg.bestPlayerId = el.value || null; save(); toast('ذخیره شد'); };
  C.dark = (el) => { db.settings.dark = el.checked; save(); render(true); };

  const GUARD = {
    addTeam: 'team.create', editTeam: 'team.edit', delTeam: 'team.delete', editStaff: 'team.edit', saveStaff: 'team.edit',
    addPlayer: 'player.create', editPlayer: 'player.edit', delPlayer: 'player.delete',
    addLeague: 'league.create', editLeague: 'league.edit', delLeague: 'league.delete',
    draw: 'league.draw', drawAuto: 'league.draw', drawManual: 'league.draw', autoGroupMatches: 'league.draw', saveGroups: 'league.draw', advSetup: 'league.draw', makeKo: 'league.draw', saveAdv: 'league.draw', fillPairs: 'league.draw', savePairs: 'league.draw', addWeek: 'league.draw', saveWeek: 'league.draw',
    applyPromo: 'league.promote', roundDate: 'match.schedule', saveRoundDate: 'match.schedule', autoDates: 'match.schedule', saveAutoDates: 'match.schedule', saveDate: 'match.schedule', setState: 'match.schedule',
    delMatch: 'match.delete', clearMatch: 'match.result_edit', editPoster: 'league.poster', posterBg: 'league.poster', savePoster: 'league.poster', resetPoster: 'league.poster',
    poster: 'poster.export', posterShare: 'poster.export', posterSave: 'poster.export',
    saveTeam: (d) => (d.id ? 'team.edit' : 'team.create'), savePlayer: (d) => (d.id ? 'player.edit' : 'player.create'), saveLeague: (d) => (d.id ? 'league.edit' : 'league.create'),
    saveMatch: (d) => { const m = db.matches.find((x) => x.id === d.id); return m && m.played ? 'match.result_edit' : 'match.result'; }
  };
  // دسترسی هر دکمه؛ سرور هم همین را بررسی می‌کند (اینجا فقط برای جلوگیری از باز شدن فرم بی‌اجازه است)
  const draw = 'league.draw';
  const PERM_OF = {
    addLeague: 'league.create', editLeague: 'league.edit', delLeague: 'league.delete',
    saveLeague: (d) => (d.id ? 'league.edit' : 'league.create'),
    draw, drawAuto: draw, drawManual: draw, autoGroupMatches: draw, saveGroups: draw, advSetup: draw, makeKo: draw, saveAdv: draw, fillPairs: draw, savePairs: draw,
    autoDates: 'match.schedule', saveAutoDates: 'match.schedule', roundDate: 'match.schedule', saveRoundDate: 'match.schedule', addWeek: draw, saveWeek: draw,
    applyPromo: 'league.promote', editPoster: 'league.poster', savePoster: 'league.poster', resetPoster: 'league.poster',
    poster: 'poster.export', posterShare: 'poster.export', posterSave: 'poster.export',
    addTeam: 'team.create', editTeam: 'team.edit', editStaff: 'team.edit', saveStaff: 'team.edit', delTeam: 'team.delete',
    saveTeam: (d) => (d.id ? 'team.edit' : 'team.create'),
    addPlayer: 'player.create', editPlayer: 'player.edit', delPlayer: 'player.delete',
    savePlayer: (d) => (d.id ? 'player.edit' : 'player.create'),
    saveMatch: (d) => { const m = db.matches.find((x) => x.id === d.id); return m && m.played ? 'match.result_edit' : 'match.result'; },
    clearMatch: 'match.result_edit', setState: 'match.schedule', saveDate: 'match.schedule', delMatch: 'match.delete'
  };
  const denyMsg = 'مدیر این کار را برای حساب تو فعال نکرده است';
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-act]');
    if (!el || el.disabled) return;
    const need = PERM_OF[el.dataset.act];
    if (need) { const pm = typeof need === 'function' ? need(el.dataset) : need; if (pm && !Auth.can(pm)) { toast(denyMsg); return; } }
    const f = A[el.dataset.act];
    const g = GUARD[el.dataset.act];
    if (g && Auth.current()) { const need = typeof g === 'function' ? g(el.dataset) : g; if (need && !Auth.can(need)) return toast('اجازه انجام این کار را نداری'); }
    if (f) f(el.dataset, el);
  });
  /* کشیدن انگشت چپ/راست روی صفحه: رفتن به تب بعدی یا قبلی (خانه: روز بازی، تیم‌ها: لیگ، لیگ: گروه یا تب، پروفایل: تب) */
  (function swipeTabs() {
    let t0 = null;
    const blocked = (el) => {
      if (!el || !el.closest) return true;
      if (el.closest('.chiprow, .tabs, input, select, textarea, label.search, #modal, #drawer, .fabwrap, table, .dt')) return true;
      for (let n = el; n && n !== document.body; n = n.parentElement) {
        if (n.scrollWidth > n.clientWidth + 4) { const ox = getComputedStyle(n).overflowX; if (ox === 'auto' || ox === 'scroll') return true; }
      }
      return false;
    };
    document.addEventListener('touchstart', (e) => {
      const t = e.touches[0];
      t0 = e.touches.length === 1 && !blocked(e.target) && t.clientX > 28 && t.clientX < window.innerWidth - 28 ? { x: t.clientX, y: t.clientY, at: Date.now() } : null;
    }, { passive: true });
    document.addEventListener('touchcancel', () => { t0 = null; }, { passive: true });
    document.addEventListener('touchend', (e) => {
      if (!t0 || document.body.classList.contains('lock')) { t0 = null; return; }
      const t = e.changedTouches[0], dx = t.clientX - t0.x, dy = t.clientY - t0.y, dt = Date.now() - t0.at;
      t0 = null;
      if (Math.abs(dx) < 70 || Math.abs(dy) > Math.abs(dx) * 0.55 || dt > 700) return;
      // ردیف گروه‌ها/لیگ‌ها/روزها در اولویت است، بعد تب‌های بالای صفحه
      const strips = [document.querySelector('main .chiprow'), document.querySelector('main .tabs')].filter(Boolean);
      const strip = strips.find((r) => r.querySelector('[data-act]'));
      if (!strip) return;
      const btns = Array.prototype.slice.call(strip.querySelectorAll('button[data-act]'));
      const i = btns.findIndex((b) => b.classList.contains('on'));
      if (i < 0) return;
      // صفحه راست‌به‌چپ است: تب بعدی سمت چپ تب فعلی است؛ کشیدن به راست = تب بعدی
      const to = btns[i + (dx > 0 ? 1 : -1)];
      if (to) to.click();
    }, { passive: true });
  })();
  document.addEventListener('input', (e) => { const f = e.target.dataset && I[e.target.dataset.input]; if (f) f(e.target); });
  document.addEventListener('change', (e) => { const f = e.target.dataset && C[e.target.dataset.change]; if (f) f(e.target); });
  window.addEventListener('hashchange', () => { closeModal(true); closeDrawer(); render(false); });
  window.addEventListener('popstate', () => {
    if (skipPop > 0) { skipPop--; return; }
    const m = document.getElementById('modal');
    if (m) { m.remove(); document.body.classList.remove('lock'); modalPushed = false; }
  });

  /* دکمه برگشت گوشی: اول بستن برگه، بعد صفحه والد، در خانه خروج */
  function getCapApp() {
    const C = window.Capacitor;
    if (!C) return null;
    try {
      if (C.Plugins && C.Plugins.App) return C.Plugins.App;
      if (C.isNativePlatform && C.isNativePlatform() && C.registerPlugin) return C.registerPlugin('App');
    } catch (e) { /* خالی */ }
    return null;
  }
  function parentRoute() {
    const r = (location.hash.replace(/^#\/?/, '') || 'home').split('/')[0];
    return r === 'home' ? null : r === 'league' ? '#/leagues' : r === 'team' ? '#/teams' : '#/home';
  }
  const capApp = getCapApp();
  if (capApp && capApp.addListener) {
    nativeBack = true;
    capApp.addListener('backButton', () => {
      if (document.getElementById('modal')) { closeModal(); return; }
      if (closeDrawer()) return;
      const p = parentRoute();
      if (p) location.replace(p); else if (capApp.exitApp) capApp.exitApp();
    });
  }

  if (!location.hash) location.replace('#/home');
  render(false);
  if (Auth.current()) doSync();
})();
