/* رابط کاربری برنامه لیگ فوتسال */
(function () {
  'use strict';
  const L = window.Logic;
  const fa = L.fa;
  const KEY = 'futsal_db_v1';
  const POS = ['دروازه‌بان', 'فیکسو', 'آلا', 'پیوت'];
  const ROLES = [['manager', 'سرپرست'], ['head', 'سرمربی'], ['coach', 'مربی'], ['assistant', 'کمک‌مربی'], ['media', 'مسئول رسانه']];
  const FORMATS = { league: 'لیگی', knockout: 'حذفی (جام)', groups: 'گروهی + حذفی' };
  const STATUS = { upcoming: 'به‌زودی', running: 'در حال برگزاری', finished: 'تمام‌شده' };
  const MAX_PLAYERS = 30;

  let db = load();
  const ui = { dayIdx: 0, tab: 'matches', q: '', leagueId: null, edit: null };
  const app = document.getElementById('app');

  /* ---------- ذخیره‌سازی ---------- */
  function load() {
    try {
      const d = JSON.parse(localStorage.getItem(KEY));
      if (d && Array.isArray(d.teams)) return Object.assign(L.emptyDb(), d, { settings: Object.assign({ dark: false }, d.settings) });
    } catch (e) { /* خالی */ }
    return L.emptyDb();
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) { toast('ذخیره‌سازی انجام نشد'); }
  }
  function commit() { save(); render(true); }

  /* ---------- ابزارها ---------- */
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const val = (id) => { const el = document.getElementById(id); return el ? el.value : ''; };
  const team = (id) => db.teams.find((t) => t.id === id);
  const player = (id) => db.players.find((p) => p.id === id);
  const players = (tid) => db.players.filter((p) => p.teamId === tid).sort((a, b) => a.number - b.number);
  const tn = (id) => (team(id) ? esc(team(id).name) : '<em>مشخص نشده</em>');
  const goalsOf = (pid) => db.events.filter((e) => e.playerId === pid && e.type === 'goal').length;

  const ICONS = {
    home: '<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14c2.8 0 4.5 1.9 4.5 4.5"/>',
    trophy: '<path d="M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M7 6H4v2a3 3 0 0 0 3 3M17 6h3v2a3 3 0 0 1-3 3M12 14v4M8 21h8M10 18h4"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    back: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    search: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4-4"/>',
    chevL: '<path d="M15 6l-6 6 6 6"/>',
    chevR: '<path d="M9 6l6 6-6 6"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>'
  };
  const icon = (n) => '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICONS[n] + '</svg>';

  let tt;
  function toast(msg) {
    let el = document.getElementById('toast');
    if (!el) { el = document.createElement('div'); el.id = 'toast'; document.body.appendChild(el); }
    el.textContent = msg; el.className = 'show';
    clearTimeout(tt); tt = setTimeout(() => { el.className = ''; }, 2600);
  }
  function modal(title, body, actions) {
    closeModal();
    const el = document.createElement('div');
    el.className = 'backdrop'; el.id = 'modal';
    el.innerHTML = '<div class="sheet" role="dialog" aria-label="' + esc(title) + '"><div class="sheet-h"><b>' + esc(title) + '</b><button class="icon-btn" data-act="closeModal" aria-label="بستن">' + icon('x') + '</button></div><div class="sheet-b">' + body + '</div>' + (actions ? '<div class="sheet-f">' + actions + '</div>' : '') + '</div>';
    el.addEventListener('click', (e) => { if (e.target === el) closeModal(); });
    document.body.appendChild(el);
    document.body.classList.add('lock');
  }
  function closeModal() {
    const m = document.getElementById('modal');
    if (m) m.remove();
    document.body.classList.remove('lock');
  }
  const empty = (t, p, actions) => '<div class="empty"><b>' + t + '</b>' + (p ? '<p>' + p + '</p>' : '') + (actions || '') + '</div>';
  const head = (title, back) => '<header class="top">' + (back ? '<a class="icon-btn" href="' + back + '" aria-label="بازگشت">' + icon('back') + '</a>' : '') + '<h1>' + esc(title) + '</h1></header>';
  function nav(tab) {
    const items = [['home', 'خانه', 'home'], ['teams', 'تیم‌ها', 'users'], ['leagues', 'لیگ‌ها', 'trophy'], ['profile', 'پروفایل', 'user']];
    return '<nav class="nav">' + items.map(([k, l, i]) => '<a href="#/' + k + '" class="' + (k === tab ? 'on' : '') + '">' + icon(i) + '<span>' + l + '</span></a>').join('') + '</nav>';
  }
  function dateInput(id, iso) {
    const j = L.toJalali(iso || L.today());
    return '<div class="dt" id="' + id + '"><input type="number" inputmode="numeric" class="dd" value="' + j.d + '" aria-label="روز">' +
      '<select class="dm" aria-label="ماه">' + L.JM.map((n, i) => '<option value="' + (i + 1) + '"' + (i + 1 === j.m ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>' +
      '<input type="number" inputmode="numeric" class="dy" value="' + j.y + '" aria-label="سال"></div>';
  }
  function readDate(id) {
    const el = document.getElementById(id);
    if (!el) return null;
    return L.fromJalali(parseInt(el.querySelector('.dy').value, 10), parseInt(el.querySelector('.dm').value, 10), parseInt(el.querySelector('.dd').value, 10));
  }

  /* ---------- نمایش‌ها ---------- */
  function render(keep) {
    const y = window.scrollY;
    const h = location.hash.replace(/^#\/?/, '') || 'home';
    const parts = h.split('/');
    let v;
    switch (parts[0]) {
      case 'teams': v = vTeams(); break;
      case 'team': v = vTeam(parts[1]); break;
      case 'leagues': v = vLeagues(); break;
      case 'league': v = vLeague(parts[1]); break;
      case 'profile': v = vProfile(); break;
      default: v = vHome();
    }
    document.documentElement.dataset.theme = db.settings.dark ? 'dark' : 'light';
    app.innerHTML = v.html + nav(v.tab);
    window.scrollTo(0, keep ? y : 0);
  }

  function matchRow(m) {
    const sc = m.played
      ? '<span class="score"><b>' + fa(m.hg) + '</b><i>:</i><b>' + fa(m.ag) + '</b></span>'
      : '<span class="score off"><b>–</b></span>';
    const meta = [];
    if (m.played && m.hp != null) meta.push('پنالتی ' + fa(m.hp) + ' - ' + fa(m.ap));
    if (m.date) meta.push(L.fmtDate(m.date));
    return '<button class="match" data-act="openMatch" data-id="' + m.id + '"><span class="mt">' + tn(m.home) + '</span>' + sc + '<span class="mt away">' + tn(m.away) + '</span>' +
      (meta.length ? '<span class="meta">' + meta.join(' • ') + '</span>' : '') + '</button>';
  }

  function vHome() {
    let h = head('خانه') + '<main class="page">';
    const days = Array.from(new Set(db.matches.filter((m) => m.played && !m.bye && m.date).map((m) => m.date))).sort().reverse();
    if (!db.teams.length && !db.leagues.length) {
      h += empty('هنوز چیزی اضافه نکرده‌ای', 'اول چند تیم و یک لیگ بساز، یا با داده نمونه برنامه را امتحان کن.',
        '<a class="btn" href="#/teams">افزودن تیم</a> <button class="btn sec" data-act="demo">داده نمونه</button>');
      return { tab: 'home', html: h + '</main>' };
    }
    h += '<h3 class="sub">نتایج آخرین روز بازی</h3>';
    if (!days.length) {
      h += '<div class="card">' + empty('هنوز نتیجه‌ای ثبت نشده', 'بعد از ثبت نتیجه بازی‌ها، نتایج آخرین روز اینجا نمایش داده می‌شود.') + '</div>';
    } else {
      ui.dayIdx = Math.min(Math.max(ui.dayIdx, 0), days.length - 1);
      const day = days[ui.dayIdx];
      h += '<div class="daynav"><button class="icon-btn" data-act="dayOlder" aria-label="روز قبل"' + (ui.dayIdx >= days.length - 1 ? ' disabled' : '') + '>' + icon('chevR') + '</button>' +
        '<div class="daytitle"><b>' + L.weekday(day) + '</b><span>' + L.fmtDate(day) + '</span></div>' +
        '<button class="icon-btn" data-act="dayNewer" aria-label="روز بعد"' + (ui.dayIdx <= 0 ? ' disabled' : '') + '>' + icon('chevL') + '</button></div>';
      const by = {};
      db.matches.filter((m) => m.date === day && m.played && !m.bye).forEach((m) => { (by[m.leagueId] = by[m.leagueId] || []).push(m); });
      Object.keys(by).forEach((id) => {
        const lg = db.leagues.find((x) => x.id === id);
        h += '<h3 class="sub">' + esc(lg ? lg.name : 'لیگ') + '</h3>' + by[id].map(matchRow).join('');
      });
    }
    const act = db.leagues.filter((l) => l.status !== 'finished');
    if (act.length) {
      h += '<h3 class="sub">لیگ‌های فعال</h3>';
      act.forEach((lg) => {
        let line = FORMATS[lg.format];
        if (lg.format === 'league') {
          const st = L.standings(lg.teamIds, db.matches.filter((m) => m.leagueId === lg.id));
          if (st.length && st[0].p > 0) line = 'صدرنشین: ' + (team(st[0].teamId) ? team(st[0].teamId).name : '') + ' (' + fa(st[0].pts) + ' امتیاز)';
        }
        h += '<a class="item" href="#/league/' + lg.id + '"><span class="item-main"><span class="av">' + icon('trophy') + '</span><span class="grow"><b>' + esc(lg.name) + '</b><small>' + esc(line) + '</small></span></span></a>';
      });
    }
    return { tab: 'home', html: h + '</main>' };
  }

  /* --- تیم‌ها --- */
  function teamItems() {
    const q = ui.q.trim();
    const list = db.teams.filter((t) => !q || t.name.indexOf(q) >= 0);
    if (!list.length) return empty(db.teams.length ? 'تیمی پیدا نشد' : 'هنوز تیمی ندارید', db.teams.length ? '' : 'با دکمه پایین اولین تیم را اضافه کن.');
    return list.map((t) => '<div class="item"><a class="item-main" href="#/team/' + t.id + '"><span class="av">' + esc((t.name.trim()[0] || '؟')) + '</span><span class="grow"><b>' + esc(t.name) + '</b><small>' + fa(players(t.id).length) + ' بازیکن</small></span></a>' +
      '<button class="icon-btn" data-act="editTeam" data-id="' + t.id + '" aria-label="ویرایش">' + icon('edit') + '</button>' +
      '<button class="icon-btn bad" data-act="delTeam" data-id="' + t.id + '" aria-label="حذف">' + icon('trash') + '</button></div>').join('');
  }
  function vTeams() {
    return {
      tab: 'teams',
      html: head('تیم‌ها') + '<main class="page has-dock"><label class="search">' + icon('search') + '<input data-input="teamSearch" placeholder="جستجوی تیم" value="' + esc(ui.q) + '"></label><div id="teamList">' + teamItems() + '</div></main>' +
        '<div class="dock"><button class="btn block" data-act="addTeam">' + icon('plus') + ' افزودن تیم</button></div>'
    };
  }
  function vTeam(id) {
    const t = team(id);
    if (!t) return { tab: 'teams', html: head('تیم', '#/teams') + '<main class="page">' + empty('این تیم پیدا نشد', '', '<a class="btn" href="#/teams">بازگشت</a>') + '</main>' };
    const pl = players(id);
    let h = head(t.name, '#/teams') + '<main class="page has-dock"><h3 class="sub">کادر فنی</h3><div class="card">';
    ROLES.forEach(([k, l]) => { h += '<div class="kv"><span>' + l + '</span><span>' + (t.staff && t.staff[k] ? esc(t.staff[k]) : '—') + '</span></div>'; });
    h += '<div class="row-btns"><button class="btn sec" data-act="editStaff" data-id="' + id + '">' + icon('edit') + ' ویرایش کادر فنی</button></div></div>';
    h += '<h3 class="sub">بازیکنان (' + fa(pl.length) + ' از ' + fa(MAX_PLAYERS) + ')</h3>';
    h += pl.length ? pl.map((p) => '<div class="item"><span class="num">' + fa(p.number) + '</span><span class="grow"><b>' + esc(p.name) + '</b><small>' + esc(p.pos) + ' • ' + fa(goalsOf(p.id)) + ' گل</small></span>' +
      '<button class="icon-btn" data-act="editPlayer" data-id="' + p.id + '" aria-label="ویرایش">' + icon('edit') + '</button>' +
      '<button class="icon-btn bad" data-act="delPlayer" data-id="' + p.id + '" aria-label="حذف">' + icon('trash') + '</button></div>').join('') : '<div class="card">' + empty('بازیکنی ثبت نشده', 'تا ۳۰ بازیکن می‌توانی اضافه کنی.') + '</div>';
    return { tab: 'teams', html: h + '</main><div class="dock"><button class="btn block" data-act="addPlayer" data-id="' + id + '"' + (pl.length >= MAX_PLAYERS ? ' disabled' : '') + '>' + icon('plus') + ' افزودن بازیکن</button></div>' };
  }

  /* --- لیگ‌ها --- */
  function vLeagues() {
    let h = head('لیگ‌ها') + '<main class="page has-dock">';
    if (!db.leagues.length) h += empty('هنوز لیگی نساخته‌ای', 'یک لیگ جدید بساز و تیم‌ها را به آن اضافه کن.');
    db.leagues.forEach((lg) => {
      const p = L.podium(db, lg);
      h += '<div class="item"><a class="item-main" href="#/league/' + lg.id + '"><span class="av">' + icon('trophy') + '</span><span class="grow"><b>' + esc(lg.name) + '</b>' +
        '<small>' + esc([lg.province, lg.venue].filter(Boolean).join(' • ') || FORMATS[lg.format]) + '</small>' +
        '<span class="chips"><span class="badge">' + FORMATS[lg.format] + '</span><span class="badge ' + lg.status + '">' + STATUS[lg.status] + '</span><span class="badge">' + fa(lg.teamIds.length) + ' تیم</span></span>' +
        (p.champion ? '<small>قهرمان: ' + tn(p.champion) + '</small>' : '') + '</span></a>' +
        '<button class="icon-btn" data-act="editLeague" data-id="' + lg.id + '" aria-label="ویرایش">' + icon('edit') + '</button>' +
        '<button class="icon-btn bad" data-act="delLeague" data-id="' + lg.id + '" aria-label="حذف">' + icon('trash') + '</button></div>';
    });
    return { tab: 'leagues', html: h + '</main><div class="dock"><button class="btn block" data-act="addLeague">' + icon('plus') + ' افزودن لیگ</button></div>' };
  }

  function roundsBlock(ms) {
    const rs = Array.from(new Set(ms.map((m) => m.round))).sort((a, b) => a - b);
    return rs.map((r) => '<div class="round"><h4>هفته ' + fa(r) + '</h4>' + ms.filter((m) => m.round === r).map(matchRow).join('') + '</div>').join('');
  }
  function koBlock(ms) {
    const R = L.koRounds(ms);
    let h = '<h3 class="sub">مرحله حذفی</h3>';
    const third = ms.find((m) => m.stage === 'third');
    for (let r = 0; r < R; r++) {
      const rm = ms.filter((m) => m.stage === 'ko' && m.round === r).sort((a, b) => a.pos - b.pos);
      if (r === R - 1 && third) h += '<div class="round"><h4>' + third.roundName + '</h4>' + matchRow(third) + '</div>';
      h += '<div class="round"><h4>' + rm[0].roundName + '</h4>' + rm.map((m) => m.bye ? '<div class="bye">' + tn(m.home || m.away) + ' — بای (مستقیم صعود کرد)</div>' : matchRow(m)).join('') + '</div>';
    }
    return h;
  }
  function tabMatches(lg) {
    const ms = db.matches.filter((m) => m.leagueId === lg.id);
    if (!ms.length) {
      return empty('بازی‌ای ساخته نشده', fa(lg.teamIds.length) + ' تیم در این لیگ ثبت شده است.', '<button class="btn" data-act="draw" data-id="' + lg.id + '">' + (lg.format === 'league' ? 'ساخت برنامه بازی‌ها' : 'قرعه‌کشی') + '</button>');
    }
    let h = '';
    if (lg.format === 'league') h += roundsBlock(ms.filter((m) => m.stage === 'league'));
    if (lg.format === 'groups') lg.groups.forEach((g) => { h += '<h3 class="sub">' + esc(g.name) + '</h3>' + roundsBlock(ms.filter((m) => m.stage === 'group' && m.groupId === g.id)); });
    const ko = ms.filter((m) => m.stage === 'ko');
    if (ko.length) h += koBlock(ms);
    else if (lg.format === 'groups') {
      const done = ms.filter((m) => m.stage === 'group').every((m) => m.played);
      h += '<div class="card note-card">' + (done ? '<button class="btn block" data-act="makeKo" data-id="' + lg.id + '">ساخت مرحله حذفی</button>' : '<p class="note">بعد از پایان بازی‌های گروهی، مرحله حذفی را از اینجا می‌سازی.</p>') + '</div>';
    }
    h += '<div class="row-btns">';
    if (lg.format !== 'knockout') h += '<button class="btn sec" data-act="addMatch" data-id="' + lg.id + '">' + icon('plus') + ' افزودن بازی</button>';
    if (!ms.some((m) => m.played && !m.bye)) h += '<button class="btn sec" data-act="draw" data-id="' + lg.id + '">قرعه‌کشی مجدد</button>';
    return h + '</div>';
  }

  function tbl(rows, adv) {
    const sg = (n) => '\u200E' + (n > 0 ? '+' : '') + fa(n);
    return '<div class="tw"><table class="tbl"><thead><tr><th>#</th><th class="tn">تیم</th><th>بازی</th><th>برد</th><th>باخت</th><th>مساوی</th><th>زده</th><th>خورده</th><th>تفاضل</th><th>امتیاز</th></tr></thead><tbody>' +
      rows.map((r, i) => '<tr class="' + (adv && i < adv ? 'adv' : '') + '"><td>' + fa(i + 1) + '</td><td class="tn">' + tn(r.teamId) + '</td><td>' + fa(r.p) + '</td><td>' + fa(r.w) + '</td><td>' + fa(r.l) + '</td><td>' + fa(r.d) + '</td><td>' + fa(r.gf) + '</td><td>' + fa(r.ga) + '</td><td class="gd">' + sg(r.gd) + '</td><td class="pts">' + fa(r.pts) + '</td></tr>').join('') +
      '</tbody></table></div>';
  }
  function podiumCard(lg) {
    const p = L.podium(db, lg);
    const rows = [['قهرمان', p.champion], ['نایب‌قهرمان', p.runnerUp], ['تیم سوم', p.third], ['تیم چهارم', p.fourth]];
    return '<h3 class="sub">رده‌بندی نهایی</h3><div class="card">' + (p.champion ? rows.map((r, i) => r[1] ? '<div class="pod"><span class="rk r' + (i + 1) + '">' + fa(i + 1) + '</span><span class="l">' + r[0] + '</span><b>' + tn(r[1]) + '</b></div>' : '').join('') : '<p class="note">بعد از پایان لیگ، قهرمان و تیم‌های دوم تا چهارم اینجا نمایش داده می‌شوند.</p>') + '</div>';
  }
  function tabTable(lg) {
    const ms = db.matches.filter((m) => m.leagueId === lg.id);
    if (lg.format === 'league') return '<div class="card flush">' + tbl(L.standings(lg.teamIds, ms), 0) + '</div>' + podiumCard(lg);
    if (lg.format === 'groups') {
      if (!lg.groups.length) return empty('گروه‌بندی انجام نشده', 'اول از تب بازی‌ها قرعه‌کشی کن.');
      return lg.groups.map((g) => '<h3 class="sub">' + esc(g.name) + '</h3><div class="card flush">' + tbl(L.standings(g.teamIds, ms.filter((m) => m.stage === 'group' && m.groupId === g.id)), lg.advance) + '</div>').join('') +
        '<p class="legend">نوار سبز: تیم‌های صعودکننده (' + fa(lg.advance) + ' تیم اول هر گروه)</p>' + podiumCard(lg);
    }
    return podiumCard(lg);
  }
  function tabStats(lg) {
    const sc = L.topScorers(db, lg.id).slice(0, 10);
    const mv = L.mvpCounts(db, lg.id).slice(0, 10);
    const row = (r, i, unit) => { const p = player(r.playerId); return p ? '<div class="pod"><span class="rk r' + Math.min(i + 1, 4) + '">' + fa(i + 1) + '</span><span class="grow"><b>' + esc(p.name) + '</b><small>' + tn(p.teamId) + '</small></span><b>' + fa(r.n) + ' ' + unit + '</b></div>' : ''; };
    const pls = db.players.filter((p) => lg.teamIds.indexOf(p.teamId) >= 0);
    let h = '<h3 class="sub">آقای گل</h3><div class="card">' + (sc.length ? sc.map((r, i) => row(r, i, 'گل')).join('') : '<p class="note">گلزنان با ثبت نتیجه بازی‌ها پر می‌شوند.</p>') + '</div>';
    h += '<h3 class="sub">بهترین بازیکن بازی‌ها</h3><div class="card">' + (mv.length ? mv.map((r, i) => row(r, i, 'بار')).join('') : '<p class="note">در هر بازی می‌توانی بهترین بازیکن زمین را انتخاب کنی.</p>') + '</div>';
    h += '<h3 class="sub">بهترین بازیکن لیگ</h3><div class="card"><label class="field"><span>انتخاب نهایی (مثلاً بعد از پایان لیگ)</span><select data-change="bestPlayer" data-id="' + lg.id + '"><option value="">— انتخاب نشده —</option>' +
      db.teams.filter((t) => lg.teamIds.indexOf(t.id) >= 0).map((t) => '<optgroup label="' + esc(t.name) + '">' + players(t.id).map((p) => '<option value="' + p.id + '"' + (lg.bestPlayerId === p.id ? ' selected' : '') + '>' + esc(p.name) + '</option>').join('') + '</optgroup>').join('') + '</select></label>' +
      (mv[0] && player(mv[0].playerId) ? '<p class="note">پیشنهاد: ' + esc(player(mv[0].playerId).name) + ' (' + fa(mv[0].n) + ' بار بهترین بازیکن بازی)</p>' : '') + (pls.length ? '' : '<p class="note">برای انتخاب، اول بازیکن‌های تیم‌ها را اضافه کن.</p>') + '</div>';
    return h;
  }
  function tabInfo(lg) {
    const kv = (a, b) => '<div class="kv"><span>' + a + '</span><span>' + b + '</span></div>';
    return '<div class="card">' + kv('نوع لیگ', FORMATS[lg.format]) + kv('وضعیت', STATUS[lg.status]) + kv('استان', esc(lg.province) || '—') + kv('سالن', esc(lg.venue) || '—') + kv('تاریخ برگزاری', lg.date ? L.fmtDate(lg.date) : '—') + kv('تعداد تیم', fa(lg.teamIds.length)) +
      (lg.format === 'groups' ? kv('تعداد گروه', fa(lg.groupCount)) + kv('صعود از هر گروه', fa(lg.advance)) : '') +
      (lg.format !== 'knockout' ? kv('دوره', lg.double ? 'رفت و برگشت' : 'یک دوره') : '') +
      (lg.bestPlayerId && player(lg.bestPlayerId) ? kv('بهترین بازیکن', esc(player(lg.bestPlayerId).name)) : '') + '</div>' + podiumCard(lg) +
      '<div class="row-btns"><button class="btn sec" data-act="editLeague" data-id="' + lg.id + '">' + icon('edit') + ' ویرایش لیگ</button><button class="btn danger" data-act="delLeague" data-id="' + lg.id + '">' + icon('trash') + ' حذف لیگ</button></div>';
  }
  function vLeague(id) {
    const lg = db.leagues.find((x) => x.id === id);
    if (!lg) return { tab: 'leagues', html: head('لیگ', '#/leagues') + '<main class="page">' + empty('این لیگ پیدا نشد', '', '<a class="btn" href="#/leagues">بازگشت</a>') + '</main>' };
    if (ui.leagueId !== id) { ui.leagueId = id; ui.tab = 'matches'; }
    const tabs = [['matches', 'بازی‌ها'], ['table', lg.format === 'knockout' ? 'رده‌بندی' : 'جدول'], ['stats', 'آمار'], ['info', 'اطلاعات']];
    const body = ui.tab === 'table' ? tabTable(lg) : ui.tab === 'stats' ? tabStats(lg) : ui.tab === 'info' ? tabInfo(lg) : tabMatches(lg);
    return { tab: 'leagues', html: head(lg.name, '#/leagues') + '<main class="page"><div class="tabs">' + tabs.map(([k, l]) => '<button data-act="tab" data-t="' + k + '" class="' + (ui.tab === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>' + body + '</main>' };
  }

  function vProfile() {
    const lgCount = db.leagues.length;
    return {
      tab: 'profile',
      html: head('پروفایل') + '<main class="page"><div class="card"><div class="kv"><span>تیم‌ها</span><span>' + fa(db.teams.length) + '</span></div><div class="kv"><span>بازیکنان</span><span>' + fa(db.players.length) + '</span></div><div class="kv"><span>لیگ‌ها</span><span>' + fa(lgCount) + '</span></div>' +
        '<div class="kv"><span>بازی‌های ثبت‌شده</span><span>' + fa(db.matches.filter((m) => m.played && !m.bye).length) + '</span></div></div>' +
        '<div class="card"><label class="check"><input type="checkbox" data-change="dark"' + (db.settings.dark ? ' checked' : '') + '><span>حالت تاریک</span></label></div>' +
        '<h3 class="sub">داده‌ها</h3><div class="card"><p class="note">اطلاعات روی همین گوشی ذخیره می‌شود. برای نگهداری یا انتقال، پشتیبان بگیر.</p><div class="row-btns"><button class="btn sec" data-act="exportDb">پشتیبان‌گیری</button><button class="btn sec" data-act="importDb">بازیابی</button><button class="btn sec" data-act="demo">داده نمونه</button><button class="btn danger" data-act="resetAll">حذف همه داده‌ها</button></div></div>' +
        '<p class="note" style="text-align:center;margin-top:16px">لیگ فوتسال • نسخه ۱٫۰</p></main>'
    };
  }

  /* ---------- فرم‌ها و عملیات ---------- */
  const A = {};
  A.closeModal = closeModal;
  A.dayOlder = () => { ui.dayIdx++; render(true); };
  A.dayNewer = () => { ui.dayIdx--; render(true); };
  A.tab = (d) => { ui.tab = d.t; render(false); };

  /* تیم */
  function teamForm(id) {
    const t = id && team(id);
    modal(t ? 'ویرایش تیم' : 'افزودن تیم', '<label class="field"><span>نام تیم</span><input id="f-name" value="' + esc(t ? t.name : '') + '" maxlength="40" autocomplete="off"></label>',
      '<button class="btn" data-act="saveTeam" data-id="' + (t ? t.id : '') + '">ذخیره</button>');
    setTimeout(() => { const i = document.getElementById('f-name'); if (i) i.focus(); }, 60);
  }
  A.addTeam = () => teamForm();
  A.editTeam = (d) => teamForm(d.id);
  A.saveTeam = (d) => {
    const name = val('f-name').trim();
    if (!name) return toast('نام تیم را وارد کن');
    if (db.teams.some((t) => t.name === name && t.id !== d.id)) return toast('این نام قبلاً ثبت شده');
    if (d.id) team(d.id).name = name;
    else db.teams.push({ id: L.uid(), name, staff: { manager: '', head: '', coach: '', assistant: '', media: '' } });
    closeModal(); commit();
  };
  A.delTeam = (d) => {
    const t = team(d.id);
    if (db.leagues.some((l) => l.teamIds.indexOf(d.id) >= 0)) return toast('این تیم در یک لیگ شرکت دارد. اول از لیگ حذفش کن.');
    if (!confirm('تیم «' + t.name + '» و بازیکنانش حذف شود؟')) return;
    db.teams = db.teams.filter((x) => x.id !== d.id);
    db.players = db.players.filter((p) => p.teamId !== d.id);
    commit();
  };
  A.editStaff = (d) => {
    const t = team(d.id);
    modal('کادر فنی ' + t.name, ROLES.map(([k, l]) => '<label class="field"><span>' + l + '</span><input id="s-' + k + '" value="' + esc(t.staff && t.staff[k]) + '" maxlength="40" autocomplete="off"></label>').join(''),
      '<button class="btn" data-act="saveStaff" data-id="' + d.id + '">ذخیره</button>');
  };
  A.saveStaff = (d) => {
    const t = team(d.id);
    t.staff = t.staff || {};
    ROLES.forEach(([k]) => { t.staff[k] = val('s-' + k).trim(); });
    closeModal(); commit();
  };

  /* بازیکن */
  function playerForm(tid, id) {
    const p = id && player(id);
    const used = players(tid).filter((x) => !p || x.id !== p.id).map((x) => x.number);
    let free = 1; while (used.indexOf(free) >= 0) free++;
    modal(p ? 'ویرایش بازیکن' : 'افزودن بازیکن',
      '<label class="field"><span>نام بازیکن</span><input id="p-name" value="' + esc(p ? p.name : '') + '" maxlength="40" autocomplete="off"></label>' +
      '<div class="grid2"><label class="field"><span>شماره پیراهن</span><input id="p-num" type="number" inputmode="numeric" min="0" max="99" value="' + (p ? p.number : free) + '"></label>' +
      '<label class="field"><span>پست</span><select id="p-pos">' + POS.map((x) => '<option' + (p && p.pos === x ? ' selected' : '') + '>' + x + '</option>').join('') + '</select></label></div>',
      '<button class="btn" data-act="savePlayer" data-id="' + (p ? p.id : '') + '" data-team="' + tid + '">ذخیره</button>');
    setTimeout(() => { const i = document.getElementById('p-name'); if (i) i.focus(); }, 60);
  }
  A.addPlayer = (d) => { if (players(d.id).length >= MAX_PLAYERS) return toast('حداکثر ۳۰ بازیکن'); playerForm(d.id); };
  A.editPlayer = (d) => playerForm(player(d.id).teamId, d.id);
  A.savePlayer = (d) => {
    const name = val('p-name').trim(); const num = parseInt(val('p-num'), 10); const pos = val('p-pos');
    if (!name) return toast('نام بازیکن را وارد کن');
    if (isNaN(num) || num < 0 || num > 99) return toast('شماره پیراهن بین ۰ تا ۹۹ باشد');
    if (players(d.team).some((p) => p.number === num && p.id !== d.id)) return toast('این شماره قبلاً استفاده شده');
    if (d.id) { const p = player(d.id); p.name = name; p.number = num; p.pos = pos; }
    else { if (players(d.team).length >= MAX_PLAYERS) return toast('حداکثر ۳۰ بازیکن'); db.players.push({ id: L.uid(), teamId: d.team, name, number: num, pos }); }
    closeModal(); commit();
  };
  A.delPlayer = (d) => {
    const p = player(d.id);
    if (!confirm('بازیکن «' + p.name + '» حذف شود؟' + (goalsOf(d.id) ? ' گل‌های او در آمار بدون نام می‌شود.' : ''))) return;
    db.events.forEach((e) => { if (e.playerId === d.id) e.playerId = null; });
    db.awards = db.awards.filter((a) => a.playerId !== d.id);
    db.leagues.forEach((l) => { if (l.bestPlayerId === d.id) l.bestPlayerId = null; });
    db.players = db.players.filter((x) => x.id !== d.id);
    commit();
  };

  /* لیگ */
  function leagueForm(id) {
    const lg = id && db.leagues.find((x) => x.id === id);
    const locked = !!(lg && db.matches.some((m) => m.leagueId === lg.id));
    const f = lg || { name: '', province: '', venue: '', status: 'upcoming', date: L.today(), format: 'league', double: false, groupCount: 2, advance: 2, teamIds: [] };
    const sel = (opts, cur) => opts.map(([v, l]) => '<option value="' + v + '"' + (String(cur) === String(v) ? ' selected' : '') + '>' + l + '</option>').join('');
    const teamsHtml = db.teams.length ? db.teams.map((t) => '<label class="check"><input type="checkbox" class="chk-team" value="' + t.id + '"' + (f.teamIds.indexOf(t.id) >= 0 ? ' checked' : '') + (locked ? ' disabled' : '') + '><span>' + esc(t.name) + '</span></label>').join('') : '<p class="note" style="padding:10px 0">اول از بخش تیم‌ها، تیم اضافه کن.</p>';
    modal(lg ? 'ویرایش لیگ' : 'افزودن لیگ',
      '<label class="field"><span>نام لیگ</span><input id="l-name" value="' + esc(f.name) + '" maxlength="60" autocomplete="off"></label>' +
      '<div class="grid2"><label class="field"><span>استان</span><input id="l-prov" value="' + esc(f.province) + '" maxlength="30"></label><label class="field"><span>سالن</span><input id="l-venue" value="' + esc(f.venue) + '" maxlength="40"></label></div>' +
      '<label class="field"><span>وضعیت</span><select id="l-status">' + sel([['upcoming', STATUS.upcoming], ['running', STATUS.running], ['finished', STATUS.finished]], f.status) + '</select></label>' +
      '<div class="field"><span>تاریخ برگزاری</span>' + dateInput('l-date', f.date) + '</div>' +
      '<label class="field"><span>نوع لیگ</span><select id="l-fmt" data-change="fmtChange"' + (locked ? ' disabled' : '') + '>' + sel([['league', FORMATS.league + ' (همه با همه)'], ['knockout', FORMATS.knockout], ['groups', FORMATS.groups]], f.format) + '</select></label>' +
      (locked ? '<p class="note">بعد از ساخت بازی‌ها، نوع لیگ و تیم‌ها قابل تغییر نیست.</p>' : '') +
      '<label class="check" id="o-double"><input type="checkbox" id="l-double"' + (f.double ? ' checked' : '') + (locked ? ' disabled' : '') + '><span>رفت و برگشت</span></label>' +
      '<div class="grid2" id="o-groups"><label class="field"><span>تعداد گروه</span><select id="l-gc"' + (locked ? ' disabled' : '') + '>' + sel([2, 3, 4, 5, 6, 7, 8].map((n) => [n, fa(n)]), f.groupCount) + '</select></label>' +
      '<label class="field"><span>صعود از هر گروه</span><select id="l-adv"' + (locked ? ' disabled' : '') + '>' + sel([1, 2, 3, 4].map((n) => [n, fa(n)]), f.advance) + '</select></label></div>' +
      '<div class="field"><span>تیم‌های لیگ</span><div class="teamlist">' + teamsHtml + '</div></div>',
      '<button class="btn" data-act="saveLeague" data-id="' + (lg ? lg.id : '') + '">ذخیره</button>');
    I.fmtChange();
  }
  const I = {};
  I.fmtChange = () => {
    const fmt = val('l-fmt');
    const d = document.getElementById('o-double'), g = document.getElementById('o-groups');
    if (d) d.style.display = fmt === 'knockout' ? 'none' : '';
    if (g) g.style.display = fmt === 'groups' ? '' : 'none';
  };
  A.addLeague = () => leagueForm();
  A.editLeague = (d) => leagueForm(d.id);
  A.saveLeague = (d) => {
    const lg = d.id && db.leagues.find((x) => x.id === d.id);
    const locked = !!(lg && db.matches.some((m) => m.leagueId === lg.id));
    const name = val('l-name').trim();
    if (!name) return toast('نام لیگ را وارد کن');
    const date = readDate('l-date');
    if (!date) return toast('تاریخ معتبر نیست');
    const fmt = locked ? lg.format : val('l-fmt');
    const ids = locked ? lg.teamIds : Array.prototype.map.call(document.querySelectorAll('.chk-team:checked'), (c) => c.value);
    const gc = parseInt(val('l-gc'), 10), adv = parseInt(val('l-adv'), 10);
    if (!locked) {
      if (ids.length < 2) return toast('حداقل دو تیم انتخاب کن');
      if (fmt === 'groups' && ids.length < gc * 2) return toast('برای ' + fa(gc) + ' گروه حداقل ' + fa(gc * 2) + ' تیم لازم است');
      if (fmt === 'groups' && adv * gc < 2) return toast('حداقل دو تیم باید صعود کنند');
    }
    const o = { name, province: val('l-prov').trim(), venue: val('l-venue').trim(), status: val('l-status'), date };
    if (!locked) Object.assign(o, { format: fmt, double: !!document.getElementById('l-double').checked, groupCount: gc, advance: adv, teamIds: ids });
    if (lg) { Object.assign(lg, o); if (o.status === 'finished') lg.autoFinished = false; closeModal(); commit(); }
    else {
      const n = Object.assign({ id: L.uid(), groups: [], bestPlayerId: null, autoFinished: false }, o);
      db.leagues.push(n); save(); closeModal(); location.hash = '#/league/' + n.id;
    }
  };
  A.delLeague = (d) => {
    const lg = db.leagues.find((x) => x.id === d.id);
    if (!confirm('لیگ «' + lg.name + '» با همه بازی‌ها و نتایجش حذف شود؟')) return;
    db.leagues = db.leagues.filter((x) => x.id !== d.id);
    db.matches = db.matches.filter((m) => m.leagueId !== d.id);
    db.events = db.events.filter((e) => e.leagueId !== d.id);
    db.awards = db.awards.filter((a) => a.leagueId !== d.id);
    save();
    if (location.hash.indexOf('#/league/') === 0) location.hash = '#/leagues'; else render(true);
  };
  A.draw = (d) => {
    const lg = db.leagues.find((x) => x.id === d.id);
    const old = db.matches.filter((m) => m.leagueId === lg.id);
    if (old.some((m) => m.played && !m.bye)) return toast('بعد از ثبت نتیجه، قرعه‌کشی مجدد ممکن نیست.');
    if (old.length && !confirm('بازی‌های فعلی حذف و دوباره قرعه‌کشی شود؟')) return;
    db.matches = db.matches.filter((m) => m.leagueId !== lg.id);
    if (lg.format === 'league') db.matches = db.matches.concat(L.genLeagueMatches(lg));
    else if (lg.format === 'knockout') db.matches = db.matches.concat(L.buildBracket(lg.id, L.shuffle(lg.teamIds)));
    else { const r = L.genGroups(lg); lg.groups = r.groups; db.matches = db.matches.concat(r.matches); }
    L.syncStatus(db, lg);
    ui.tab = 'matches'; commit(); toast('بازی‌ها ساخته شد');
  };
  A.makeKo = (d) => {
    const lg = db.leagues.find((x) => x.id === d.id);
    const r = L.groupsToKo(db, lg);
    if (r.error) return toast(r.error);
    db.matches = db.matches.concat(r.matches); commit(); toast('مرحله حذفی ساخته شد');
  };
  A.addMatch = (d) => {
    const lg = db.leagues.find((x) => x.id === d.id);
    const opts = lg.teamIds.map((id) => '<option value="' + id + '">' + tn(id) + '</option>').join('');
    modal('افزودن بازی', '<label class="field"><span>تیم میزبان</span><select id="x-h">' + opts + '</select></label><label class="field"><span>تیم مهمان</span><select id="x-a">' + opts + '</select></label><label class="field"><span>شماره هفته</span><input id="x-r" type="number" inputmode="numeric" min="1" value="1"></label>',
      '<button class="btn" data-act="saveMatchNew" data-id="' + lg.id + '">افزودن</button>');
    const a = document.getElementById('x-a'); if (a && a.options[1]) a.selectedIndex = 1;
  };
  A.saveMatchNew = (d) => {
    const lg = db.leagues.find((x) => x.id === d.id);
    const h = val('x-h'), a = val('x-a'), r = parseInt(val('x-r'), 10) || 1;
    if (h === a) return toast('دو تیم باید متفاوت باشند');
    const m = { leagueId: lg.id, stage: 'league', round: r, home: h, away: a };
    if (lg.format === 'groups') {
      const g = lg.groups.find((x) => x.teamIds.indexOf(h) >= 0 && x.teamIds.indexOf(a) >= 0);
      if (!g) return toast('دو تیم باید در یک گروه باشند');
      m.stage = 'group'; m.groupId = g.id;
    }
    db.matches.push(L.newMatch(m)); closeModal(); commit();
  };

  /* نتیجه بازی */
  function syncEdit() {
    const me = ui.edit;
    ['h', 'a'].forEach((side) => {
      const n = Math.min(30, Math.max(0, parseInt(val(side === 'h' ? 'm-hg' : 'm-ag'), 10) || 0));
      me[side] = me[side].slice(0, n);
      while (me[side].length < n) me[side].push('');
    });
  }
  function drawScorers() {
    const me = ui.edit, m = me.m;
    syncEdit();
    const box = document.getElementById('scorers');
    if (!box) return;
    box.innerHTML = ['h', 'a'].map((side) => {
      const tid = side === 'h' ? m.home : m.away;
      if (!me[side].length) return '';
      const pl = players(tid);
      return '<div class="sc-group"><h4>گلزنان ' + tn(tid) + '</h4>' + me[side].map((v, i) => '<select data-change="scorerSel" data-side="' + side + '" data-i="' + i + '" aria-label="گلزن"><option value="">گلزن نامشخص</option><option value="og"' + (v === 'og' ? ' selected' : '') + '>گل به خودی (از تیم حریف)</option>' +
        pl.map((p) => '<option value="' + p.id + '"' + (v === p.id ? ' selected' : '') + '>' + fa(p.number) + ' - ' + esc(p.name) + '</option>').join('') + '</select>').join('') + '</div>';
    }).join('');
    const ko = m.stage === 'ko' || m.stage === 'third';
    const eq = val('m-hg') !== '' && val('m-hg') === val('m-ag');
    document.getElementById('pens').style.display = ko && eq ? '' : 'none';
  }
  A.openMatch = (d) => {
    const m = db.matches.find((x) => x.id === d.id);
    if (!m || m.bye) return;
    const lg = db.leagues.find((x) => x.id === m.leagueId);
    if (!m.home || !m.away) return modal(m.roundName || 'بازی', '<p class="note">تیم‌های این بازی بعد از پایان دور قبل مشخص می‌شوند.</p>');
    const evs = db.events.filter((e) => e.matchId === m.id);
    const side = (tid) => evs.filter((e) => e.teamId === tid).map((e) => (e.type === 'og' ? 'og' : (e.playerId || '')));
    ui.edit = { m, h: side(m.home), a: side(m.away) };
    const mv = db.awards.find((a) => a.matchId === m.id && a.type === 'mvp');
    const mvOpts = [m.home, m.away].map((tid) => '<optgroup label="' + esc(team(tid).name) + '">' + players(tid).map((p) => '<option value="' + p.id + '"' + (mv && mv.playerId === p.id ? ' selected' : '') + '>' + esc(p.name) + '</option>').join('') + '</optgroup>').join('');
    const body = '<div class="vs"><label>' + tn(m.home) + '<input id="m-hg" data-input="goals" type="number" inputmode="numeric" min="0" max="99" value="' + (m.played ? m.hg : '') + '" placeholder="۰"></label>' +
      '<label>' + tn(m.away) + '<input id="m-ag" data-input="goals" type="number" inputmode="numeric" min="0" max="99" value="' + (m.played ? m.ag : '') + '" placeholder="۰"></label></div>' +
      '<div id="pens" style="display:none"><div class="grid2"><label class="field"><span>پنالتی ' + tn(m.home) + '</span><input id="m-hp" type="number" inputmode="numeric" min="0" value="' + (m.hp != null ? m.hp : '') + '"></label><label class="field"><span>پنالتی ' + tn(m.away) + '</span><input id="m-ap" type="number" inputmode="numeric" min="0" value="' + (m.ap != null ? m.ap : '') + '"></label></div></div>' +
      '<div id="scorers"></div>' +
      '<label class="field"><span>بهترین بازیکن زمین (اختیاری)</span><select id="m-mvp"><option value="">— انتخاب نشده —</option>' + mvOpts + '</select></label>' +
      '<div class="field"><span>تاریخ بازی</span>' + dateInput('m-date', m.date || L.today()) + '</div>';
    let act = '<button class="btn" data-act="saveMatch" data-id="' + m.id + '">ذخیره نتیجه</button>';
    if (m.played) act += '<button class="btn danger" data-act="clearMatch" data-id="' + m.id + '">پاک کردن نتیجه</button>';
    if (m.stage === 'league' || m.stage === 'group') act += '<button class="btn danger" data-act="delMatch" data-id="' + m.id + '">حذف بازی</button>';
    modal((m.roundName ? m.roundName + ' • ' : '') + (lg ? lg.name : 'بازی'), body, act);
    drawScorers();
  };
  A.saveMatch = (d) => {
    const m = db.matches.find((x) => x.id === d.id);
    const hg = parseInt(val('m-hg'), 10), ag = parseInt(val('m-ag'), 10);
    if (isNaN(hg) || isNaN(ag) || hg < 0 || ag < 0) return toast('گل هر دو تیم را وارد کن');
    const date = readDate('m-date');
    if (!date) return toast('تاریخ معتبر نیست');
    syncEdit();
    const events = [];
    [['h', m.home], ['a', m.away]].forEach(([side, tid]) => ui.edit[side].forEach((v) => events.push({ teamId: tid, playerId: v && v !== 'og' ? v : null, type: v === 'og' ? 'og' : 'goal' })));
    const hp = val('m-hp'), ap = val('m-ap');
    const err = L.saveResult(db, m, { hg, ag, hp: hp === '' ? null : parseInt(hp, 10), ap: ap === '' ? null : parseInt(ap, 10), date, events, mvp: val('m-mvp') || null });
    if (err) return toast(err);
    closeModal(); commit(); toast('نتیجه ذخیره شد');
  };
  A.clearMatch = (d) => {
    const m = db.matches.find((x) => x.id === d.id);
    if (!confirm('نتیجه این بازی پاک شود؟')) return;
    const err = L.clearResult(db, m);
    if (err) return toast(err);
    closeModal(); commit(); toast('نتیجه پاک شد');
  };
  A.delMatch = (d) => {
    if (!confirm('این بازی حذف شود؟')) return;
    db.matches = db.matches.filter((x) => x.id !== d.id);
    db.events = db.events.filter((e) => e.matchId !== d.id);
    db.awards = db.awards.filter((a) => a.matchId !== d.id);
    const m = db.leagues; m.forEach((lg) => L.syncStatus(db, lg));
    closeModal(); commit();
  };

  /* پروفایل و داده‌ها */
  A.demo = () => {
    if ((db.teams.length || db.leagues.length) && !confirm('داده‌های فعلی با داده نمونه جایگزین شود؟')) return;
    db = L.demo(); db.settings.dark = false; save(); location.hash = '#/home'; render(false);
  };
  A.resetAll = () => {
    if (!confirm('همه تیم‌ها، لیگ‌ها و نتایج حذف شود؟ این کار قابل بازگشت نیست.')) return;
    const dark = db.settings.dark; db = L.emptyDb(); db.settings.dark = dark; save(); render(false); toast('همه داده‌ها حذف شد');
  };
  A.exportDb = () => {
    modal('پشتیبان‌گیری', '<p class="note">این متن را کپی کن و جایی امن نگه دار (مثلاً در پیام‌های ذخیره‌شده).</p><label class="field"><textarea id="x-json" readonly>' + esc(JSON.stringify(db)) + '</textarea></label>', '<button class="btn" data-act="copyDb">کپی متن</button>');
  };
  A.copyDb = () => {
    const t = document.getElementById('x-json'); t.select();
    try { if (navigator.clipboard) navigator.clipboard.writeText(t.value); else document.execCommand('copy'); toast('کپی شد'); } catch (e) { toast('متن را به‌صورت دستی کپی کن'); }
  };
  A.importDb = () => {
    modal('بازیابی', '<p class="note">متن پشتیبان را اینجا بچسبان. داده‌های فعلی جایگزین می‌شود.</p><label class="field"><textarea id="x-json"></textarea></label>', '<button class="btn" data-act="importDo">بازیابی</button>');
  };
  A.importDo = () => {
    try {
      const d = JSON.parse(val('x-json'));
      if (!d || !Array.isArray(d.teams) || !Array.isArray(d.leagues) || !Array.isArray(d.matches)) throw new Error('bad');
      db = Object.assign(L.emptyDb(), d, { settings: Object.assign({ dark: false }, d.settings) });
      save(); closeModal(); render(false); toast('بازیابی انجام شد');
    } catch (e) { toast('متن پشتیبان معتبر نیست'); }
  };

  /* ---------- رویدادها ---------- */
  I.teamSearch = (el) => { ui.q = el.value; const l = document.getElementById('teamList'); if (l) l.innerHTML = teamItems(); };
  I.goals = () => drawScorers();
  const C = {};
  C.fmtChange = () => I.fmtChange();
  C.scorerSel = (el) => { if (ui.edit) ui.edit[el.dataset.side][parseInt(el.dataset.i, 10)] = el.value; };
  C.bestPlayer = (el) => { const lg = db.leagues.find((x) => x.id === el.dataset.id); lg.bestPlayerId = el.value || null; save(); toast('ذخیره شد'); };
  C.dark = (el) => { db.settings.dark = el.checked; save(); render(true); };

  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-act]');
    if (!el || el.disabled) return;
    const f = A[el.dataset.act];
    if (f) f(el.dataset, el);
  });
  document.addEventListener('input', (e) => { const f = e.target.dataset && I[e.target.dataset.input]; if (f) f(e.target); });
  document.addEventListener('change', (e) => { const f = e.target.dataset && C[e.target.dataset.change]; if (f) f(e.target); });
  window.addEventListener('hashchange', () => { closeModal(); render(false); });

  if (!location.hash) location.replace('#/home');
  render(false);
})();
