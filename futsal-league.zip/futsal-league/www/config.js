/* آدرس API سرور. روی سایت (مرورگر) نسبی است؛ در APK باید آدرس کامل سایت باشد. */
(function () {
  var isApk = location.hostname === 'localhost' && !location.port && location.protocol === 'https:';
  window.APP_API = isApk ? 'https://saigroup.ir/league/api/index.php' : 'api/index.php';
})();
