/* اجرای آفلاینِ نسخه وب: فایل‌های برنامه ذخیره می‌شوند؛ درخواست‌های API هرگز ذخیره نمی‌شوند */
const CACHE = 'futsal-shell-v20';
const SHELL = ['./', 'index.html', 'style.css', 'logic.js', 'config.js', 'auth.js', 'poster.js', 'app.js', 'manifest.json', 'icon-192.png', 'fonts/Vazirmatn-Variable.woff2'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin || u.pathname.indexOf('/api/') >= 0) return;
  e.respondWith(fetch(e.request).then((r) => { const cp = r.clone(); caches.open(CACHE).then((c) => c.put(e.request, cp)); return r; }).catch(() => caches.match(e.request).then((m) => m || caches.match('index.html'))));
});
