/* ساخت پوستر نتایج و جدول (Canvas) - بدون وابستگی خارجی */
(function (root) {
  'use strict';
  const L = root.Logic, fa = L.fa;
  const W = 1080, PAD = 50, CW = W - 2 * PAD;
  const FONT = '"Vazirmatn","Noto Naskh Arabic","Noto Sans Arabic",Tahoma,"DejaVu Sans",system-ui,sans-serif';
  const P = {};

  // [تیره، روشن، رنگ تأکید]
  P.THEMES = { blue: ['#0B3F94', '#2F78E8', '#F5B82E'], green: ['#0B5D3B', '#25A56B', '#F5D547'], red: ['#8E1B1B', '#E04B3A', '#FFD166'], purple: ['#3D1A78', '#8A52E0', '#FFC857'], dark: ['#0B0F1A', '#27324A', '#4DA3FF'], gold: ['#4A3200', '#C99A1D', '#FFFFFF'] };
  P.THEME_NAMES = { blue: 'آبی', green: 'سبز', red: 'قرمز', purple: 'بنفش', dark: 'مشکی', gold: 'طلایی' };
  P.DEF = { theme: 'blue', overlay: 40, bg: '', logo: '', logo2: '', title: '', subtitle: '', footer: '' };
  const STATE = { notheld: 'برگزار نشد', cancelled: 'لغو شد', postponed: 'به تعویق افتاد' };
  const STATE_COLOR = { notheld: '#62718A', cancelled: '#D6453A', postponed: '#C98A00' };

  const cache = {};
  function loadImg(src) {
    if (!src) return Promise.resolve(null);
    if (cache[src]) return cache[src];
    if (Object.keys(cache).length > 8) Object.keys(cache).forEach((k) => delete cache[k]);
    cache[src] = new Promise((res) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = src; });
    return cache[src];
  }
  const font = (size, w) => (w || 'normal') + ' ' + size + 'px ' + FONT;
  function rr(c, x, y, w, h, r) {
    c.beginPath();
    c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
  }
  function wrap(c, text, maxW) {
    const words = String(text || '').split(/\s+/).filter(Boolean);
    const lines = []; let cur = '';
    words.forEach((w) => {
      const t = cur ? cur + ' ' + w : w;
      if (c.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t;
    });
    if (cur) lines.push(cur);
    return lines;
  }
  // کوچک کردن فونت تا متن جا شود
  function fit(c, text, maxW, size, min, w) {
    let s = size;
    c.font = font(s, w);
    while (s > min && c.measureText(text).width > maxW) { s -= 2; c.font = font(s, w); }
    let t = String(text);
    while (t.length > 1 && c.measureText(t).width > maxW) t = t.slice(0, -1);
    return { size: s, text: t === String(text) ? t : t + '…' };
  }
  function txt(c, s, x, y, f, color, align, shadow) {
    c.font = f; c.fillStyle = color; c.textAlign = align || 'center'; c.textBaseline = 'middle';
    if (shadow) { c.shadowColor = 'rgba(0,0,0,.45)'; c.shadowBlur = 12; c.shadowOffsetY = 2; }
    c.fillText(s, x, y);
    if (shadow) { c.shadowColor = 'transparent'; c.shadowBlur = 0; c.shadowOffsetY = 0; }
  }
  function card(c, x, y, w, h, r, fill) {
    c.save();
    c.shadowColor = 'rgba(0,0,0,.2)'; c.shadowBlur = 20; c.shadowOffsetY = 6;
    c.fillStyle = fill || 'rgba(255,255,255,.93)'; rr(c, x, y, w, h, r || 28); c.fill();
    c.restore();
  }

  /* content:
     { heading, sub, sections:[{title, matches:[{home, away, played, hg, ag, hp, ap, state, dateLine, hs, as}]}] }
     یا { heading, sub, table:{ rows:[{rank, team, p, w, d, l, gf, ga, gd, pts, cls}], legend } } */
  P.render = async function (content, st, leagueName) {
    st = Object.assign({}, P.DEF, st || {});
    const th = P.THEMES[st.theme] || P.THEMES.blue;
    // فونت وزیرمتن باید قبل از نقاشی روی بوم بارگذاری شده باشد
    try { await Promise.all([document.fonts.load('normal 30px Vazirmatn'), document.fonts.load('bold 30px Vazirmatn')]); } catch (e) { /* خالی */ }
    const [bg, logo, logo2] = await Promise.all([loadImg(st.bg), loadImg(st.logo), loadImg(st.logo2)]);
    const m = document.createElement('canvas').getContext('2d');
    m.direction = 'rtl';
    const ops = [];
    let y = 56;

    /* سربرگ */
    if (logo) {
      const s = Math.min(280 / logo.width, 150 / logo.height), w = logo.width * s, h = logo.height * s, yy = y;
      ops.push((c) => c.drawImage(logo, (W - w) / 2, yy, w, h));
      y += h + 22;
    }
    m.font = font(66, 'bold');
    wrap(m, st.title || leagueName || '', CW).slice(0, 2).forEach((line) => { const yy = y + 40; ops.push((c) => txt(c, line, W / 2, yy, font(66, 'bold'), '#fff', 'center', true)); y += 82; });
    if (st.subtitle) {
      m.font = font(34);
      wrap(m, st.subtitle, CW).slice(0, 2).forEach((line) => { const yy = y + 22; ops.push((c) => txt(c, line, W / 2, yy, font(34), 'rgba(255,255,255,.92)', 'center', true)); y += 46; });
    }
    y += 16;
    m.font = font(50, 'bold');
    const hw = Math.min(CW, m.measureText(content.heading).width + 120), hy = y;
    ops.push((c) => { c.save(); c.shadowColor = 'rgba(0,0,0,.25)'; c.shadowBlur = 14; c.fillStyle = th[2]; rr(c, (W - hw) / 2, hy, hw, 96, 48); c.fill(); c.restore(); txt(c, content.heading, W / 2, hy + 49, font(50, 'bold'), th[2] === '#FFFFFF' ? '#2a1d00' : '#1b1b1b', 'center'); });
    y += 96;
    if (content.sub) { const yy = y + 36; ops.push((c) => txt(c, content.sub, W / 2, yy, font(32), '#fff', 'center', true)); y += 62; }
    y += 30;

    /* بدنه: بازی‌ها */
    (content.sections || []).forEach((sec) => {
      if (sec.title) {
        const yy = y; m.font = font(36, 'bold');
        const tw = m.measureText(sec.title).width + 90;
        ops.push((c) => { c.fillStyle = 'rgba(0,0,0,.35)'; rr(c, W / 2 - tw / 2, yy, tw, 64, 32); c.fill(); txt(c, sec.title, W / 2, yy + 33, font(36, 'bold'), '#fff', 'center'); });
        y += 84;
      }
      sec.matches.forEach((mt) => {
        const showSc = mt.hs || mt.as;
        m.font = font(26);
        const hl = mt.hs ? wrap(m, 'گلزنان: ' + mt.hs, 420) : [], al = mt.as ? wrap(m, 'گلزنان: ' + mt.as, 420) : [];
        const nl = Math.max(hl.length, al.length);
        const y0 = y;
        let h = 24 + 92 + (mt.dateLine ? 44 : 0) + (mt.hp != null && mt.played ? 40 : 0) + (showSc ? nl * 36 + 10 : 0) + 20;
        ops.push((c) => {
          card(c, PAD, y0, CW, h, 28);
          const cy = y0 + 24 + 46, cx = W / 2, nameW = (CW - 250 - 60) / 2;
          const hn = fit(c, mt.home, nameW, 40, 26, 'bold'), an = fit(c, mt.away, nameW, 40, 26, 'bold');
          txt(c, hn.text, PAD + CW - 28, cy, font(hn.size, 'bold'), '#14233B', 'right');
          txt(c, an.text, PAD + 28, cy, font(an.size, 'bold'), '#14233B', 'left');
          if (mt.played) {
            c.fillStyle = th[0]; rr(c, cx - 100, cy - 44, 200, 88, 24); c.fill();
            txt(c, fa(mt.hg), cx + 50, cy + 2, font(58, 'bold'), '#fff', 'center');
            txt(c, ':', cx, cy - 2, font(50, 'bold'), 'rgba(255,255,255,.65)', 'center');
            txt(c, fa(mt.ag), cx - 50, cy + 2, font(58, 'bold'), '#fff', 'center');
          } else if (mt.state) {
            const lab = STATE[mt.state]; c.font = font(28, 'bold');
            const bw = Math.min(240, Math.max(150, c.measureText(lab).width + 40));
            c.fillStyle = STATE_COLOR[mt.state]; rr(c, cx - bw / 2, cy - 30, bw, 60, 30); c.fill();
            txt(c, lab, cx, cy + 1, font(28, 'bold'), '#fff', 'center');
          } else {
            c.fillStyle = '#E7EFFC'; rr(c, cx - 70, cy - 36, 140, 72, 22); c.fill();
            txt(c, '—', cx, cy, font(44, 'bold'), '#62718A', 'center');
          }
          let yy = y0 + 24 + 92;
          if (mt.dateLine) { txt(c, mt.dateLine, cx, yy + 18, font(28), '#62718A', 'center'); yy += 44; }
          if (mt.hp != null && mt.played) { txt(c, 'پنالتی ' + fa(mt.hp) + ' - ' + fa(mt.ap), cx, yy + 18, font(28, 'bold'), '#14233B', 'center'); yy += 40; }
          if (showSc) {
            hl.forEach((s, i) => txt(c, s, PAD + CW - 28, yy + 22 + i * 36, font(26), '#3A4660', 'right'));
            al.forEach((s, i) => txt(c, s, PAD + 28, yy + 22 + i * 36, font(26), '#3A4660', 'left'));
          }
        });
        y += h + 18;
      });
    });

    /* بدنه: جدول */
    if (content.table) {
      const rows = content.table.rows, hh = 84, rh = 84, y0 = y, ch = hh + rows.length * rh + 12;
      const cols = ['بازی', 'برد', 'مساوی', 'باخت', 'زده', 'خورده', 'تفاضل', 'امتیاز'];
      const cx = (i) => 640 - 36.9 - i * 73.75;
      ops.push((c) => {
        card(c, PAD, y0, CW, ch, 28);
        c.save(); rr(c, PAD, y0, CW, ch, 28); c.clip();
        c.fillStyle = th[0]; c.fillRect(PAD, y0, CW, hh);
        txt(c, '#', PAD + CW - 55, y0 + hh / 2, font(28, 'bold'), '#fff', 'center');
        txt(c, 'تیم', PAD + CW - 110, y0 + hh / 2, font(28, 'bold'), '#fff', 'right');
        cols.forEach((t, i) => txt(c, t, cx(i), y0 + hh / 2, font(22, 'bold'), '#fff', 'center'));
        rows.forEach((r, i) => {
          const ry = y0 + hh + i * rh;
          if (r.cls === 'adv') { c.fillStyle = 'rgba(20,147,95,.2)'; c.fillRect(PAD, ry, CW, rh); }
          else if (r.cls === 'down') { c.fillStyle = 'rgba(214,69,58,.2)'; c.fillRect(PAD, ry, CW, rh); }
          else if (i % 2) { c.fillStyle = 'rgba(11,63,148,.05)'; c.fillRect(PAD, ry, CW, rh); }
          if (r.cls) { c.fillStyle = r.cls === 'adv' ? '#14935F' : '#D6453A'; c.fillRect(PAD + CW - 8, ry, 8, rh); }
          const mid = ry + rh / 2, tn = fit(c, r.team, 275, 34, 22, 'bold');
          txt(c, fa(r.rank), PAD + CW - 55, mid, font(32, 'bold'), '#14233B', 'center');
          txt(c, tn.text, PAD + CW - 110, mid, font(tn.size, 'bold'), '#14233B', 'right');
          const vals = [r.p, r.w, r.d, r.l, r.gf, r.ga, '‎' + (r.gd > 0 ? '+' : '') + fa(r.gd), r.pts];
          vals.forEach((v, k) => txt(c, typeof v === 'number' ? fa(v) : v, cx(k), mid, k === 7 ? font(38, 'bold') : font(32), k === 7 ? th[0] : '#14233B', 'center'));
        });
        c.restore();
      });
      y += ch + 18;
      if (content.table.legend) { const yy = y + 20; ops.push((c) => txt(c, content.table.legend, W / 2, yy, font(28), '#fff', 'center', true)); y += 50; }
    }

    /* پاورقی */
    let fh = 0;
    m.font = font(34, 'bold');
    const fl = st.footer ? wrap(m, st.footer, CW).slice(0, 3) : [];
    let l2h = 0, l2w = 0;
    if (logo2) { const s = Math.min(320 / logo2.width, 120 / logo2.height); l2w = logo2.width * s; l2h = logo2.height * s; fh += l2h + 16; }
    fh += fl.length * 48;
    const H = Math.min(6000, Math.max(1350, Math.ceil(y + fh + (fh ? 70 : 60))));

    const cv = document.createElement('canvas');
    cv.width = W; cv.height = H;
    const c = cv.getContext('2d');
    c.direction = 'rtl';
    // پس‌زمینه
    if (bg) {
      const s = Math.max(W / bg.width, H / bg.height);
      c.drawImage(bg, (W - bg.width * s) / 2, (H - bg.height * s) / 2, bg.width * s, bg.height * s);
      c.fillStyle = 'rgba(0,0,0,' + (Math.max(0, Math.min(90, st.overlay)) / 100) + ')'; c.fillRect(0, 0, W, H);
    } else {
      const g = c.createLinearGradient(0, 0, W * 0.6, H);
      g.addColorStop(0, th[0]); g.addColorStop(1, th[1]);
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      c.fillStyle = 'rgba(255,255,255,.07)';
      c.beginPath(); c.arc(W - 80, 120, 260, 0, 7); c.fill();
      c.beginPath(); c.arc(120, H - 160, 320, 0, 7); c.fill();
    }
    ops.forEach((op) => op(c));
    let fy = H - fh - 40;
    if (logo2) { c.drawImage(logo2, (W - l2w) / 2, fy, l2w, l2h); fy += l2h + 16; }
    fl.forEach((line, i) => txt(c, line, W / 2, fy + 24 + i * 48, font(34, 'bold'), '#fff', 'center', true));
    return cv;
  };

  root.Poster = P;
})(window);
