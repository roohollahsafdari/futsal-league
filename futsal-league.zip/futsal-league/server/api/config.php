<?php
// ===== تنظیمات سرور: این فایل را قبل از نصب ویرایش کن =====
// اطلاعات دیتابیس را از cPanel ← MySQL Databases بگیر
define('DB_HOST', 'localhost');
define('DB_NAME', 'نام_دیتابیس');
define('DB_USER', 'نام_کاربر_دیتابیس');
define('DB_PASS', 'رمز_دیتابیس');

// کلید نصب: فقط کسی که این کلید را بداند می‌تواند install.php را اجرا کند
define('INSTALL_KEY', 'یک-کلید-طولانی-و-دلخواه-بنویس');

// حساب مدیر اصلی (فقط هنگام نصب ساخته می‌شود؛ بعد از نصب، رمز را از داخل برنامه عوض کن)
define('OWNER_USER', 'roohollahsafdari@gmail.com');
define('OWNER_PASS', 'taniyaaa123');
define('OWNER_FIRST', 'روح‌الله');
define('OWNER_LAST', 'صفدری');

// مدت اعتبار نشست: بدون «مرا به خاطر بسپار» ۲۴ ساعت، با آن ۹۰ روز
define('SESSION_SHORT', 86400);
define('SESSION_LONG', 90 * 86400);
