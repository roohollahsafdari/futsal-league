<?php
// ساخت و ارتقای خودکار جدول‌ها. هم install.php و هم index.php از این فایل استفاده می‌کنند.
// اگر دیتابیس نسخه قدیمی باشد، اولین درخواست بعد از آپلود، خودش ستون‌های تازه را اضافه می‌کند (نیازی به اجرای دوباره install.php نیست).
const SCHEMA_VERSION = 4;

function schema_migrate($pdo) {
    $T = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $tables = [
"CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(120) NOT NULL, pass_hash VARCHAR(255) NOT NULL, first_name VARCHAR(40) NOT NULL DEFAULT '', last_name VARCHAR(40) NOT NULL DEFAULT '', phone VARCHAR(20) NOT NULL DEFAULT '', email VARCHAR(120) NOT NULL DEFAULT '', role_title VARCHAR(40) NOT NULL DEFAULT '', role VARCHAR(10) NOT NULL DEFAULT 'user', level TINYINT NOT NULL DEFAULT 3, parent_id INT NOT NULL DEFAULT 0, max_sub INT NOT NULL DEFAULT 0, sub_start INT NULL, sub_end INT NULL, sub_done TINYINT NOT NULL DEFAULT 0, active TINYINT NOT NULL DEFAULT 1, require_approval TINYINT NOT NULL DEFAULT 1, perms TEXT, pending_rev INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0, updated_at INT NOT NULL DEFAULT 0, UNIQUE KEY uq_username(username)) $T",
"CREATE TABLE IF NOT EXISTS sessions(id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, token_hash CHAR(64) NOT NULL, login_at INT NOT NULL, last_seen INT NOT NULL, expires_at INT NOT NULL, logout_at INT NULL, logout_reason VARCHAR(20) NOT NULL DEFAULT '', ip VARCHAR(64) NOT NULL DEFAULT '', ua VARCHAR(250) NOT NULL DEFAULT '', UNIQUE KEY uq_tok(token_hash), KEY k_user(user_id)) $T",
"CREATE TABLE IF NOT EXISTS entities(seq BIGINT AUTO_INCREMENT PRIMARY KEY, kind VARCHAR(16) NOT NULL, id VARCHAR(64) NOT NULL, tenant INT NOT NULL DEFAULT 0, data MEDIUMTEXT, updated_at INT NOT NULL DEFAULT 0, updated_by INT NOT NULL DEFAULT 0, UNIQUE KEY uq_ent(kind,id), KEY k_tenant(tenant)) $T",
"CREATE TABLE IF NOT EXISTS changes(id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, tenant INT NOT NULL DEFAULT 0, approver_id INT NOT NULL DEFAULT 0, kind VARCHAR(16) NOT NULL, entity_id VARCHAR(64) NOT NULL, op VARCHAR(8) NOT NULL, data MEDIUMTEXT, label VARCHAR(600) NOT NULL DEFAULT '', grp VARCHAR(90) NULL, status VARCHAR(10) NOT NULL DEFAULT 'pending', created_at INT NOT NULL DEFAULT 0, updated_at INT NOT NULL DEFAULT 0, decided_at INT NULL, decided_by INT NULL, seen TINYINT NOT NULL DEFAULT 0, KEY k_us(user_id,status), KEY k_st(status), KEY k_ap(approver_id,status)) $T",
"CREATE TABLE IF NOT EXISTS activity(id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NULL, username VARCHAR(120) NOT NULL DEFAULT '', display_name VARCHAR(100) NOT NULL DEFAULT '', action VARCHAR(16) NOT NULL, entity VARCHAR(16) NOT NULL DEFAULT '', text VARCHAR(700) NOT NULL DEFAULT '', ip VARCHAR(64) NOT NULL DEFAULT '', created_at INT NOT NULL, KEY k_u(user_id), KEY k_fail(action,ip,created_at)) $T",
"CREATE TABLE IF NOT EXISTS meta(k VARCHAR(20) PRIMARY KEY, v VARCHAR(60) NOT NULL) $T",
"CREATE TABLE IF NOT EXISTS backups(id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0, mailed TINYINT NOT NULL DEFAULT 0, reason VARCHAR(80) NOT NULL DEFAULT '', data LONGTEXT, KEY k_bu(user_id)) $T",
    ];
    foreach ($tables as $s) $pdo->exec($s);

    $has = function ($t, $c) use ($pdo) { return (bool)$pdo->query("SHOW COLUMNS FROM `$t` LIKE '$c'")->fetch(); };
    $add = function ($t, $c, $def) use ($pdo, $has) {
        if ($has($t, $c)) return false;
        try { $pdo->exec("ALTER TABLE `$t` ADD COLUMN `$c` $def"); return true; } catch (Exception $e) { return false; }
    };
    $newLevel = $add('users', 'level', 'TINYINT NOT NULL DEFAULT 3');
    $add('users', 'parent_id', 'INT NOT NULL DEFAULT 0');
    $add('users', 'max_sub', 'INT NOT NULL DEFAULT 0');
    $add('users', 'sub_start', 'INT NULL');
    $add('users', 'sub_end', 'INT NULL');
    $add('users', 'sub_done', 'TINYINT NOT NULL DEFAULT 0');
    $newTenant = $add('entities', 'tenant', 'INT NOT NULL DEFAULT 0');
    if ($newTenant) { try { $pdo->exec('ALTER TABLE entities ADD KEY k_tenant(tenant)'); } catch (Exception $e) { /* خالی */ } }
    $newChTenant = $add('changes', 'tenant', 'INT NOT NULL DEFAULT 0');
    $newAppr = $add('changes', 'approver_id', 'INT NOT NULL DEFAULT 0');

    // انتقال داده‌های نسخه قبل (فقط یک‌بار): همه داده‌ها و کاربران قبلی زیر نظر مدیر اصلی می‌مانند
    $adm = (int)$pdo->query("SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1")->fetchColumn();
    if ($adm) {
        if ($newLevel) {
            $pdo->exec("UPDATE users SET level=1 WHERE role='admin'");
            $st = $pdo->prepare("UPDATE users SET level=3, parent_id=? WHERE role<>'admin'");
            $st->execute([$adm]);
        }
        if ($newTenant) { $st = $pdo->prepare('UPDATE entities SET tenant=?'); $st->execute([$adm]); }
        if ($newChTenant || $newAppr) { $st = $pdo->prepare('UPDATE changes SET tenant=?, approver_id=?'); $st->execute([$adm, $adm]); }
    }
    $st = $pdo->prepare("INSERT INTO meta(k,v) VALUES('schema',?) ON DUPLICATE KEY UPDATE v=VALUES(v)");
    $st->execute([(string)SCHEMA_VERSION]);
}
