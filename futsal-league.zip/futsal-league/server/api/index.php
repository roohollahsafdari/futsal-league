<?php
// API برنامه لیگ فوتسال (PHP + MySQL). منطق دقیقاً مطابق سرور مرجع آزمایشی است.
require __DIR__ . '/config.php';
mb_internal_encoding('UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }

const KINDS = ['leagues', 'teams', 'players', 'matches', 'events', 'awards'];
const PERMS = [
 ['league.create','ایجاد لیگ جدید','لیگ‌ها'],['league.edit','ویرایش مشخصات لیگ','لیگ‌ها'],['league.delete','حذف لیگ','لیگ‌ها'],
 ['league.draw','قرعه‌کشی و ساخت برنامه بازی‌ها','لیگ‌ها'],['league.promote','اعمال صعود و سقوط','لیگ‌ها'],
 ['league.poster','ویرایش پس‌زمینه پوستر لیگ','لیگ‌ها'],['league.best','انتخاب بهترین بازیکن لیگ','لیگ‌ها'],
 ['team.create','افزودن تیم','تیم‌ها'],['team.edit','ویرایش تیم و کادر فنی','تیم‌ها'],['team.delete','حذف تیم','تیم‌ها'],
 ['player.create','افزودن بازیکن','بازیکنان'],['player.edit','ویرایش بازیکن','بازیکنان'],['player.delete','حذف بازیکن','بازیکنان'],
 ['match.schedule','زمان‌بندی بازی و تغییر وضعیت (تعویق/لغو)','بازی‌ها'],['match.result','ثبت نتیجه بازی','بازی‌ها'],
 ['match.result_edit','ویرایش یا حذف نتیجه ثبت‌شده','بازی‌ها'],['match.delete','حذف بازی','بازی‌ها'],
 ['poster.export','ساخت و ارسال پوستر نتایج و جدول','سایر']];
const AUTO_L = ['groups', 'autoFinished', 'promotionApplied', 'status', 'teamIds'];
const CONTENT = ['league.edit','league.draw','league.promote','team.create','team.edit','team.delete','match.result','match.result_edit'];

function pk() { static $k = null; if ($k === null) { $k = array_map(function ($p) { return $p[0]; }, PERMS); } return $k; }
function out($r) { echo is_string($r) ? $r : json_encode($r, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
function now() { return time(); }
function pdo() {
    static $p = null;
    if ($p === null) $p = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
    return $p;
}
function q($sql, $params = []) { $s = pdo()->prepare($sql); $s->execute($params); return $s; }
function one($sql, $params = []) { $r = q($sql, $params)->fetch(); return $r === false ? null : $r; }
function all($sql, $params = []) { return q($sql, $params)->fetchAll(); }
function scalar($sql, $params = []) { $r = q($sql, $params)->fetch(PDO::FETCH_NUM); return $r ? $r[0] : null; }
function jd($s) { $v = json_decode((string)$s, true); return $v; }
function norm($v) {
    if (!is_array($v)) return $v;
    $isList = array_keys($v) === range(0, count($v) - 1);
    $o = [];
    foreach ($v as $k => $x) $o[$k] = norm($x);
    if (!$isList) ksort($o);
    return $o;
}
function canon($v) { return json_encode(norm($v), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); }
function fa($s) { return strtr((string)$s, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']); }
function lower($s) { return mb_strtolower((string)$s, 'UTF-8'); }
function cut($s, $n) { return mb_substr((string)$s, 0, $n, 'UTF-8'); }
function pubver() { $v = scalar("SELECT v FROM meta WHERE k='pub'"); return $v === null ? 0 : (int)$v; }
function bump_pub() { q("INSERT INTO meta(k,v) VALUES('pub','1') ON DUPLICATE KEY UPDATE v = v + 1"); }
function bump_rev($uid) { q('UPDATE users SET pending_rev = pending_rev + 1 WHERE id=?', [$uid]); }
function dname_of($u) { $n = trim(($u['first_name'] ?? '') . ' ' . ($u['last_name'] ?? '')); return $n !== '' ? $n : $u['username']; }
function logact($u, $action, $entity, $text, $ip = '', $uname = null, $dname = null) {
    q('INSERT INTO activity(user_id,username,display_name,action,entity,text,ip,created_at) VALUES(?,?,?,?,?,?,?,?)',
      [$u ? $u['id'] : null, $uname !== null ? $uname : ($u ? $u['username'] : ''), $dname !== null ? $dname : ($u ? dname_of($u) : ''), $action, $entity, cut($text, 690), $ip, now()]);
}
function perms_of($u) {
    if ($u['role'] === 'admin') return pk();
    $l = jd($u['perms']); if (!is_array($l)) $l = [];
    return array_values(array_filter($l, function ($p) { return in_array($p, pk(), true); }));
}
function me_of($u) {
    return ['id' => (int)$u['id'], 'username' => $u['username'], 'first_name' => $u['first_name'], 'last_name' => $u['last_name'], 'phone' => $u['phone'], 'email' => $u['email'], 'role_title' => $u['role_title'], 'role' => $u['role'], 'perms' => perms_of($u), 'require_approval' => (bool)$u['require_approval'], 'active' => (bool)$u['active']];
}
function published() {
    $o = []; foreach (KINDS as $k) $o[$k] = [];
    foreach (all('SELECT kind,id,data FROM entities ORDER BY seq') as $r) if (isset($o[$r['kind']])) $o[$r['kind']][(string)$r['id']] = $r['data'];
    return $o;
}
function effective($uid) {
    $o = published();
    foreach (all("SELECT kind,entity_id,op,data FROM changes WHERE user_id=? AND status='pending' ORDER BY id", [$uid]) as $r) {
        if ($r['op'] === 'delete') unset($o[$r['kind']][(string)$r['entity_id']]);
        else $o[$r['kind']][(string)$r['entity_id']] = $r['data'];
    }
    return $o;
}
function db_json($eff) {
    $parts = [];
    foreach (KINDS as $k) $parts[] = '"' . $k . '":[' . implode(',', array_values($eff[$k])) . ']';
    return '{' . implode(',', $parts) . '}';
}
function keys_changed($a, $b) {
    $a = is_array($a) ? $a : []; $b = is_array($b) ? $b : [];
    $ks = array_unique(array_merge(array_keys($a), array_keys($b)));
    $o = [];
    foreach ($ks as $k) if (canon($a[$k] ?? null) !== canon($b[$k] ?? null)) $o[] = (string)$k;
    return $o;
}
function subset($arr, $allowed) { foreach ($arr as $x) if (!in_array($x, $allowed, true)) return false; return true; }

function needs($kind, $cur, $new) {
    if ($kind === 'leagues') {
        if ($cur === null) return ['league.create'];
        if ($new === null) return ['league.delete'];
        $ch = keys_changed($cur, $new);
        if (subset($ch, ['bestPlayerId'])) return ['league.best'];
        if (subset($ch, ['poster'])) return ['league.poster'];
        if (subset($ch, AUTO_L)) return CONTENT;
        return ['league.edit'];
    }
    if ($kind === 'teams' || $kind === 'players') {
        $n = $kind === 'teams' ? 'team' : 'player';
        if ($cur === null) return [$n . '.create'];
        if ($new === null) return [$n . '.delete'];
        if ($kind === 'teams' && subset(keys_changed($cur, $new), ['leagueId'])) return [$n . '.edit', 'league.promote'];
        return [$n . '.edit'];
    }
    if ($kind === 'matches') {
        if ($cur === null) return ['league.draw'];
        if ($new === null) return ['match.delete', 'league.delete', 'league.draw'];
        $ch = keys_changed($cur, $new);
        $cp = !empty($cur['played']); $np = !empty($new['played']);
        if (!$cp && $np) return !empty($new['bye']) ? ['league.draw', 'match.result'] : ['match.result'];
        if ($cp && !$np) return ['match.result_edit'];
        if ($cp && $np && array_intersect($ch, ['hg', 'ag', 'hp', 'ap'])) return ['match.result_edit'];
        if (subset($ch, ['home', 'away'])) return ['match.result', 'match.result_edit', 'league.draw'];
        return ['match.schedule'];
    }
    return ['match.result', 'match.result_edit', 'match.delete', 'league.delete', 'league.draw'];
}
function nm($maps, $kind, $id) {
    foreach ($maps as $m) {
        $r = $m[$kind][(string)$id] ?? null;
        if ($r) { $j = jd($r); if (is_array($j) && !empty($j['name'])) return $j['name']; }
    }
    return 'نامشخص';
}
function describe($ch, $maps) {
    $kind = $ch['kind']; $b = $ch['before']; $a = $ch['after'];
    $lbl = function ($m) use ($maps) { return '«' . nm($maps, 'teams', $m['home']) . ' - ' . nm($maps, 'teams', $m['away']) . '» در ' . nm($maps, 'leagues', $m['leagueId']); };
    if ($kind === 'leagues') {
        if ($b === null) return ['create', 'لیگ «' . $a['name'] . '» ایجاد شد', false, null];
        if ($a === null) return ['delete', 'لیگ «' . $b['name'] . '» حذف شد', false, null];
        return ['edit', 'لیگ «' . $a['name'] . '» ویرایش شد', false, null];
    }
    if ($kind === 'teams' || $kind === 'players') {
        $noun = $kind === 'teams' ? 'تیم' : 'بازیکن';
        $o = $a !== null ? $a : $b;
        $name = ($o['name'] ?? '') . ($kind === 'teams' ? '' : ' (' . nm($maps, 'teams', $o['teamId'] ?? '') . ')');
        $act = $b === null ? 'create' : ($a === null ? 'delete' : 'edit');
        $v = ['create' => 'ایجاد', 'delete' => 'حذف', 'edit' => 'ویرایش'][$act];
        return [$act, $noun . ' «' . $name . '» ' . $v . ' شد', false, null];
    }
    if ($kind === 'matches') {
        $m = $a !== null ? $a : $b;
        if ($b === null) return ['create', 'ساخت برنامه بازی‌ها برای لیگ «' . nm($maps, 'leagues', $m['leagueId']) . '»', false, 'mk:' . $m['leagueId']];
        if ($a === null) return ['delete', 'حذف بازی ' . $lbl($m), false, 'md:' . $m['leagueId']];
        $g = 'm:' . $a['id'];
        if (!empty($a['bye'])) return ['edit', 'بازی ' . $lbl($a) . ' ویرایش شد', true, $g];
        $sc = function ($x) { return fa($x['hg'] ?? '') . ' - ' . fa($x['ag'] ?? '') . (isset($x['hp']) && $x['hp'] !== null ? ' (پنالتی ' . fa($x['hp']) . ' - ' . fa($x['ap'] ?? '') . ')' : ''); };
        $bp = !empty($b['played']); $ap = !empty($a['played']);
        if (!$bp && $ap) return ['result', 'نتیجه بازی ' . $lbl($a) . ' ثبت شد: ' . $sc($a), false, $g];
        if ($bp && !$ap) return ['result', 'نتیجه بازی ' . $lbl($a) . ' حذف شد', false, $g];
        if ($bp && $ap && array_intersect(keys_changed($b, $a), ['hg', 'ag', 'hp', 'ap'])) return ['result', 'نتیجه بازی ' . $lbl($a) . ' ویرایش شد: ' . $sc($b) . ' ← ' . $sc($a), false, $g];
        if (($b['state'] ?? null) !== ($a['state'] ?? null)) return ['edit', 'وضعیت بازی ' . $lbl($a) . ' تغییر کرد', false, $g];
        if (($b['date'] ?? null) !== ($a['date'] ?? null) || ($b['time'] ?? null) !== ($a['time'] ?? null)) return ['edit', 'زمان بازی ' . $lbl($a) . ' تغییر کرد', false, $g];
        return ['edit', 'بازی ' . $lbl($a) . ' ویرایش شد', true, $g];
    }
    $o = $a !== null ? $a : $b;
    $mid = $o['matchId'] ?? '';
    $mm = null;
    $r = $maps[0]['matches'][(string)$mid] ?? ($maps[1]['matches'][(string)$mid] ?? null);
    if ($r) $mm = jd($r);
    return ['result', 'گلزنان / کارت‌ها / بهترین بازیکن بازی ' . ($mm ? $lbl($mm) : '') . ' ویرایش شد', false, 'm:' . $mid];
}
function make_activity(&$accepted, $maps) {
    $out = []; $seen = []; $res = false;
    foreach ($accepted as $i => $ch) $accepted[$i]['d'] = describe($ch, $maps);
    foreach ($accepted as $ch) if ($ch['d'][0] === 'result') $res = true;
    foreach ($accepted as $ch) {
        list($act, $text, $gen, $grp) = $ch['d'];
        if ($gen && $res) continue;
        $isEv = in_array($ch['kind'], ['events', 'awards'], true);
        if ($isEv) {
            if (isset($seen[$grp])) continue;
            $dup = false;
            foreach ($accepted as $x) if ($x['kind'] === 'matches' && $x['d'][3] === $grp) $dup = true;
            if ($dup) continue;
        }
        $mkmd = $grp !== null && (strpos($grp, 'mk:') === 0 || strpos($grp, 'md:') === 0);
        if ($mkmd || $isEv) {
            if (isset($seen[$grp])) continue;
            $seen[$grp] = 1;
            if ($mkmd) {
                $n = 0; foreach ($accepted as $x) if ($x['kind'] === 'matches' && $x['d'][3] === $grp) $n++;
                $lid = substr($grp, 3);
                $text = strpos($grp, 'mk:') === 0 ? 'برنامه بازی‌ها (' . fa($n) . ' بازی) برای لیگ «' . nm($maps, 'leagues', $lid) . '» ایجاد شد' : fa($n) . ' بازی از لیگ «' . nm($maps, 'leagues', $lid) . '» حذف شد';
            }
        }
        $out[] = [$act, $ch['kind'], $text];
    }
    if (count($out) > 8) return [['edit', 'bulk', 'تغییرات گروهی روی داده‌ها (' . fa(count($out)) . ' مورد)']];
    return $out;
}
function apply_pub($kind, $id, $op, $raw, $uid, $t) {
    if ($op === 'delete') { q('DELETE FROM entities WHERE kind=? AND id=?', [$kind, $id]); return; }
    if (scalar('SELECT 1 FROM entities WHERE kind=? AND id=?', [$kind, $id])) q('UPDATE entities SET data=?,updated_at=?,updated_by=? WHERE kind=? AND id=?', [$raw, $t, $uid, $kind, $id]);
    else q('INSERT INTO entities(kind,id,data,updated_at,updated_by) VALUES(?,?,?,?,?)', [$kind, $id, $raw, $t, $uid]);
}
function do_sync($u, $body, $ip) {
    $direct = $u['role'] === 'admin' || !$u['require_approval'];
    $perms = perms_of($u);
    $eff = effective($u['id']);
    $newm = $eff;
    $accepted = []; $denied = [];
    $chs = isset($body['changes']) && is_array($body['changes']) ? $body['changes'] : [];
    foreach ($chs as $ch) {
        if (!is_array($ch)) continue;
        $kind = $ch['kind'] ?? null; $id = (string)($ch['id'] ?? ''); $op = $ch['op'] ?? null;
        if (!in_array($kind, KINDS, true) || $id === '' || strlen($id) > 64 || !in_array($op, ['upsert', 'delete'], true)) continue;
        $curRaw = $newm[$kind][$id] ?? null; $cur = $curRaw ? jd($curRaw) : null;
        if ($op === 'delete') {
            if ($cur === null) continue;
            $raw = null; $after = null;
        } else {
            $raw = $ch['json'] ?? null;
            $after = is_string($raw) ? jd($raw) : null;
            if (!is_array($after)) continue;
            if ($cur !== null && canon($cur) === canon($after)) continue;
        }
        if ($u['role'] !== 'admin') {
            $need = needs($kind, $cur, $after);
            if (!array_intersect($need, $perms)) { $denied[] = $kind . ' ' . $id; continue; }
        }
        $accepted[] = ['kind' => $kind, 'id' => $id, 'op' => $op, 'raw' => $raw, 'before' => $cur, 'after' => $after];
        if ($op === 'delete') unset($newm[$kind][$id]); else $newm[$kind][$id] = $raw;
    }
    if ($accepted) {
        $maps = [$newm, $eff];
        $acts = make_activity($accepted, $maps);
        $pub = published(); $t = now(); $changedPub = false;
        foreach ($accepted as $ch) {
            $k = $ch['kind']; $id = $ch['id'];
            if ($direct) {
                apply_pub($k, $id, $ch['op'], $ch['raw'], $u['id'], $t);
                q("DELETE FROM changes WHERE user_id=? AND kind=? AND entity_id=? AND status='pending'", [$u['id'], $k, $id]);
                $changedPub = true;
            } else {
                $p = $pub[$k][$id] ?? null;
                $same = ($ch['op'] === 'delete' && $p === null) || ($ch['op'] === 'upsert' && $p !== null && canon(jd($p)) === canon($ch['after']));
                $row = one("SELECT id FROM changes WHERE user_id=? AND kind=? AND entity_id=? AND status='pending'", [$u['id'], $k, $id]);
                if ($same) {
                    if ($row) q('DELETE FROM changes WHERE id=?', [$row['id']]);
                } else {
                    $pb = $p !== null ? jd($p) : null;
                    $d = describe(['kind' => $k, 'op' => $ch['op'], 'before' => $ch['op'] === 'upsert' ? $pb : ($pb !== null ? $pb : $ch['before']), 'after' => $ch['op'] === 'upsert' ? $ch['after'] : null], $maps);
                    if ($row) q('UPDATE changes SET op=?,data=?,label=?,grp=?,updated_at=? WHERE id=?', [$ch['op'], $ch['raw'], cut($d[1], 590), $d[3], $t, $row['id']]);
                    else q('INSERT INTO changes(user_id,kind,entity_id,op,data,label,grp,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)', [$u['id'], $k, $id, $ch['op'], $ch['raw'], cut($d[1], 590), $d[3], $t, $t]);
                }
            }
        }
        if ($changedPub) bump_pub();
        if (!$direct) bump_rev($u['id']);
        foreach ($acts as $a) logact($u, $a[0], $a[1], $a[2], $ip);
    }
    $rev = pubver() . '-' . (int)scalar('SELECT pending_rev FROM users WHERE id=?', [$u['id']]);
    $dec = all("SELECT id,status,label FROM changes WHERE user_id=? AND status IN('approved','rejected') AND seen=0", [$u['id']]);
    if ($dec) q("UPDATE changes SET seen=1 WHERE user_id=? AND status IN('approved','rejected')", [$u['id']]);
    $res = ['ok' => true, 'rev' => $rev, 'me' => me_of($u), 'denied' => $denied, 'decided' => $dec,
            'pending' => (int)scalar("SELECT COUNT(*) FROM changes WHERE user_id=? AND status='pending'", [$u['id']])];
    if ($u['role'] === 'admin') {
        $res['pending_total'] = (int)scalar("SELECT COUNT(*) FROM changes WHERE status='pending'");
        $res['catalog'] = array_map(function ($p) { return ['key' => $p[0], 'label' => $p[1], 'group' => $p[2]]; }, PERMS);
    }
    if ($accepted || ($body['rev'] ?? null) !== $rev) {
        $j = json_encode($res, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        return substr($j, 0, -1) . ',"db":' . db_json(effective($u['id'])) . '}';
    }
    $res['same'] = true;
    return $res;
}
function kill_sessions($uid, $reason) { q('UPDATE sessions SET logout_at=?,logout_reason=? WHERE user_id=? AND logout_at IS NULL', [now(), $reason, $uid]); }
function s($v, $n) { return cut(trim((string)($v ?? '')), $n); }

function handle($body, $ip, $ua) {
    $a = $body['a'] ?? '';
    if ($a === 'login') {
        $uname = lower(trim((string)($body['u'] ?? ''))); $pw = (string)($body['p'] ?? '');
        if ((int)scalar("SELECT COUNT(*) FROM activity WHERE action='fail' AND ip=? AND created_at>?", [$ip, now() - 600]) >= 8)
            return ['ok' => false, 'error' => 'تلاش‌های ناموفق زیاد بود. چند دقیقه بعد دوباره امتحان کن'];
        $u = one('SELECT * FROM users WHERE username=?', [$uname]);
        if (!$u) $u = one('SELECT * FROM users WHERE LOWER(username)=?', [$uname]);
        if (!$u || !password_verify($pw, $u['pass_hash'])) {
            logact(null, 'fail', 'auth', 'تلاش ناموفق برای ورود با «' . cut($uname, 60) . '»', $ip, cut($uname, 60), '');
            return ['ok' => false, 'error' => 'نام کاربری یا رمز عبور درست نیست'];
        }
        if (!$u['active']) return ['ok' => false, 'error' => 'این حساب غیرفعال شده است'];
        $tok = bin2hex(random_bytes(32));
        $exp = now() + (!empty($body['remember']) ? SESSION_LONG : SESSION_SHORT);
        q('INSERT INTO sessions(user_id,token_hash,login_at,last_seen,expires_at,ip,ua) VALUES(?,?,?,?,?,?,?)', [$u['id'], hash('sha256', $tok), now(), now(), $exp, $ip, cut($ua, 250)]);
        logact($u, 'login', 'auth', 'وارد برنامه شد', $ip);
        return ['ok' => true, 'token' => $tok, 'me' => me_of($u), 'expires_at' => $exp];
    }
    if ($a === 'ping') return ['ok' => true, 'time' => now()];
    $th = hash('sha256', (string)($body['token'] ?? ''));
    $s = one('SELECT * FROM sessions WHERE token_hash=?', [$th]);
    $u = $s ? one('SELECT * FROM users WHERE id=?', [$s['user_id']]) : null;
    if (!$s || !$u) return ['ok' => false, 'code' => 'auth', 'reason' => 'invalid'];
    if ($s['logout_at'] !== null) return ['ok' => false, 'code' => 'auth', 'reason' => $s['logout_reason'] ?: 'logout'];
    if (!$u['active']) return ['ok' => false, 'code' => 'auth', 'reason' => 'disabled'];
    if (now() > (int)$s['expires_at']) return ['ok' => false, 'code' => 'auth', 'reason' => 'expired'];
    if (now() - (int)$s['last_seen'] > 60) q('UPDATE sessions SET last_seen=? WHERE id=?', [now(), $s['id']]);
    $admin = $u['role'] === 'admin';

    if ($a === 'logout') {
        q('UPDATE sessions SET logout_at=?,logout_reason=? WHERE id=?', [now(), 'logout', $s['id']]);
        logact($u, 'logout', 'auth', 'از برنامه خارج شد', $ip);
        return ['ok' => true];
    }
    if ($a === 'sync') return do_sync($u, $body, $ip);
    if ($a === 'profile') {
        $phone = s($body['phone'] ?? '', 20); $em = s($body['email'] ?? '', 120); $rt = s($body['role_title'] ?? '', 40);
        if ($em !== '' && strpos($em, '@') === false) return ['ok' => false, 'error' => 'ایمیل معتبر نیست'];
        q('UPDATE users SET phone=?,email=?,role_title=?,updated_at=? WHERE id=?', [$phone, $em, $rt, now(), $u['id']]);
        logact($u, 'edit', 'profile', 'شماره تماس، ایمیل یا سمت خودش را ویرایش کرد', $ip);
        return ['ok' => true, 'me' => me_of(one('SELECT * FROM users WHERE id=?', [$u['id']]))];
    }
    if ($a === 'activity') {
        $uid = $admin ? (int)($body['user_id'] ?? 0) : (int)$u['id'];
        $w = []; $p = [];
        if ($uid) { $w[] = 'user_id=?'; $p[] = $uid; }
        if (!empty($body['type'])) { $w[] = 'action=?'; $p[] = (string)$body['type']; }
        if (!$admin) $w[] = "action<>'fail'";
        $wh = $w ? 'WHERE ' . implode(' AND ', $w) : '';
        $off = max(0, (int)($body['offset'] ?? 0));
        $tot = (int)scalar('SELECT COUNT(*) FROM activity ' . $wh, $p);
        $rows = all('SELECT * FROM activity ' . $wh . ' ORDER BY id DESC LIMIT 40 OFFSET ' . $off, $p);
        return ['ok' => true, 'rows' => $rows, 'total' => $tot];
    }
    if (!$admin) return ['ok' => false, 'error' => 'دسترسی نداری'];

    if ($a === 'users') {
        $rows = [];
        foreach (all('SELECT * FROM users ORDER BY id') as $r) {
            $m = me_of($r);
            $m['created_at'] = (int)$r['created_at'];
            $m['last_login'] = scalar('SELECT MAX(login_at) FROM sessions WHERE user_id=?', [$r['id']]);
            $m['last_login'] = $m['last_login'] === null ? null : (int)$m['last_login'];
            $m['pending'] = (int)scalar("SELECT COUNT(*) FROM changes WHERE user_id=? AND status='pending'", [$r['id']]);
            $rows[] = $m;
        }
        return ['ok' => true, 'users' => $rows];
    }
    if ($a === 'user_save') {
        $uid = (int)($body['id'] ?? 0); $un = trim((string)($body['username'] ?? ''));
        if (mb_strlen($un) < 3 || preg_match('/\s/u', $un)) return ['ok' => false, 'error' => 'نام کاربری حداقل ۳ حرف و بدون فاصله باشد'];
        if (one('SELECT id FROM users WHERE LOWER(username)=? AND id<>?', [lower($un), $uid])) return ['ok' => false, 'error' => 'این نام کاربری قبلاً ثبت شده'];
        $pw = (string)($body['password'] ?? '');
        $pr = array_values(array_filter(is_array($body['perms'] ?? null) ? $body['perms'] : [], function ($p) { return in_array($p, pk(), true); }));
        $fields = [s($body['first_name'] ?? '', 40), s($body['last_name'] ?? '', 40), s($body['phone'] ?? '', 20), s($body['email'] ?? '', 120), s($body['role_title'] ?? '', 40)];
        if ($uid) {
            $t = one('SELECT * FROM users WHERE id=?', [$uid]);
            if (!$t) return ['ok' => false, 'error' => 'کاربر پیدا نشد'];
            if ($pw !== '' && mb_strlen($pw) < 6) return ['ok' => false, 'error' => 'رمز عبور حداقل ۶ کاراکتر باشد'];
            $active = ($t['role'] === 'admin' || !empty($body['active'])) ? 1 : 0;
            $req = (!empty($body['require_approval']) && $t['role'] !== 'admin') ? 1 : 0;
            q('UPDATE users SET username=?,first_name=?,last_name=?,phone=?,email=?,role_title=?,active=?,require_approval=?,perms=?,updated_at=? WHERE id=?',
              [$un, $fields[0], $fields[1], $fields[2], $fields[3], $fields[4], $active, $req, json_encode($pr), now(), $uid]);
            if ($pw !== '') { q('UPDATE users SET pass_hash=? WHERE id=?', [password_hash($pw, PASSWORD_DEFAULT), $uid]); kill_sessions($uid, 'password'); }
            elseif ($un !== $t['username']) kill_sessions($uid, 'username');
            elseif (!$active) kill_sessions($uid, 'disabled');
            else bump_rev($uid);
            logact($u, 'edit', 'user', 'کاربر «' . $un . '» را ویرایش کرد', $ip);
        } else {
            if (mb_strlen($pw) < 6) return ['ok' => false, 'error' => 'رمز عبور حداقل ۶ کاراکتر باشد'];
            q("INSERT INTO users(username,pass_hash,first_name,last_name,phone,email,role_title,role,active,require_approval,perms,created_at,updated_at) VALUES(?,?,?,?,?,?,?,'user',?,?,?,?,?)",
              [$un, password_hash($pw, PASSWORD_DEFAULT), $fields[0], $fields[1], $fields[2], $fields[3], $fields[4], !empty($body['active']) ? 1 : 0, !empty($body['require_approval']) ? 1 : 0, json_encode($pr), now(), now()]);
            logact($u, 'create', 'user', 'کاربر «' . $un . '» را ساخت', $ip);
        }
        return ['ok' => true];
    }
    if ($a === 'user_logout') { kill_sessions((int)($body['id'] ?? 0), 'forced'); logact($u, 'edit', 'user', 'کاربر را از برنامه خارج کرد', $ip); return ['ok' => true]; }
    if ($a === 'user_delete') {
        $uid = (int)($body['id'] ?? 0); $t = one('SELECT * FROM users WHERE id=?', [$uid]);
        if (!$t || $t['role'] === 'admin') return ['ok' => false, 'error' => 'این حساب قابل حذف نیست'];
        kill_sessions($uid, 'deleted');
        q("DELETE FROM changes WHERE user_id=? AND status='pending'", [$uid]);
        q('DELETE FROM users WHERE id=?', [$uid]);
        logact($u, 'delete', 'user', 'حساب «' . $t['username'] . '» را حذف کرد', $ip);
        return ['ok' => true];
    }
    if ($a === 'sessions') {
        $rows = all('SELECT s.id,s.user_id,s.login_at,s.last_seen,s.logout_at,s.logout_reason,s.ip,s.ua,u.username,u.first_name,u.last_name FROM sessions s LEFT JOIN users u ON u.id=s.user_id ORDER BY s.id DESC LIMIT 150');
        return ['ok' => true, 'rows' => $rows, 'now' => now()];
    }
    if ($a === 'pending') {
        return ['ok' => true, 'rows' => all("SELECT c.id,c.user_id,c.kind,c.entity_id,c.op,c.label,c.grp,c.created_at,c.updated_at,u.username,u.first_name,u.last_name FROM changes c LEFT JOIN users u ON u.id=c.user_id WHERE c.status='pending' ORDER BY c.id")];
    }
    if ($a === 'decide') {
        $ids = array_map('intval', is_array($body['ids'] ?? null) ? $body['ids'] : []);
        $ok = ($body['decision'] ?? '') === 'approve'; $t = now(); $n = 0; $users = [];
        foreach ($ids as $i) {
            $r = one("SELECT * FROM changes WHERE id=? AND status='pending'", [$i]);
            if (!$r) continue;
            if ($ok) apply_pub($r['kind'], $r['entity_id'], $r['op'], $r['data'], $r['user_id'], $t);
            q('UPDATE changes SET status=?,decided_at=?,decided_by=?,seen=0 WHERE id=?', [$ok ? 'approved' : 'rejected', $t, $u['id'], $i]);
            $users[$r['user_id']] = 1; $n++;
        }
        if ($n) {
            if ($ok) bump_pub();
            foreach (array_keys($users) as $x) bump_rev($x);
            logact($u, 'edit', 'approval', ($ok ? 'تایید' : 'رد') . ' ' . fa($n) . ' تغییر کاربران', $ip);
        }
        return ['ok' => true, 'count' => $n];
    }
    if ($a === 'export') return ['ok' => true, 'raw' => db_json(published())];
    return ['ok' => false, 'error' => 'درخواست نامعتبر'];
}

try {
    $raw = file_get_contents('php://input');
    $body = json_decode($raw, true);
    if (!is_array($body)) $body = [];
    $ip = substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 64);
    $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
    pdo()->beginTransaction();
    $r = handle($body, $ip, $ua);
    pdo()->commit();
    out($r);
} catch (Throwable $e) {
    if (pdo_in_tx()) { try { pdo()->rollBack(); } catch (Throwable $x) {} }
    error_log('futsal api: ' . $e->getMessage());
    http_response_code(200);
    out(['ok' => false, 'error' => 'خطای سرور. اگر تازه نصب کرده‌ای install.php را اجرا کن.']);
}
function pdo_in_tx() { try { return pdo()->inTransaction(); } catch (Throwable $e) { return false; } }
