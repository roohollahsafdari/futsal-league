<?php
// اجرای یک‌باره: https://saigroup.ir/league/api/install.php?key=کلید-نصب
// بعد از نصب موفق، این فایل را از هاست حذف کن.
require __DIR__ . '/config.php';
header('Content-Type: text/html; charset=utf-8');
echo '<!DOCTYPE html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>نصب</title><body style="font-family:Tahoma,sans-serif;max-width:560px;margin:30px auto;line-height:2">';
if (!isset($_GET['key']) || !hash_equals(INSTALL_KEY, (string)$_GET['key'])) { http_response_code(403); echo '<h3>کلید نصب درست نیست.</h3><p>آدرس باید به این شکل باشد: install.php?key=کلید-داخل-config.php</p>'; exit; }
try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (Exception $e) { echo '<h3>اتصال به دیتابیس برقرار نشد.</h3><p>نام دیتابیس، کاربر و رمز را در config.php بررسی کن.</p>'; exit; }
$T = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
$sql = [
"CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(120) NOT NULL, pass_hash VARCHAR(255) NOT NULL, first_name VARCHAR(40) NOT NULL DEFAULT '', last_name VARCHAR(40) NOT NULL DEFAULT '', phone VARCHAR(20) NOT NULL DEFAULT '', email VARCHAR(120) NOT NULL DEFAULT '', role_title VARCHAR(40) NOT NULL DEFAULT '', role VARCHAR(10) NOT NULL DEFAULT 'user', active TINYINT NOT NULL DEFAULT 1, require_approval TINYINT NOT NULL DEFAULT 1, perms TEXT, pending_rev INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0, updated_at INT NOT NULL DEFAULT 0, UNIQUE KEY uq_username(username)) $T",
"CREATE TABLE IF NOT EXISTS sessions(id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, token_hash CHAR(64) NOT NULL, login_at INT NOT NULL, last_seen INT NOT NULL, expires_at INT NOT NULL, logout_at INT NULL, logout_reason VARCHAR(20) NOT NULL DEFAULT '', ip VARCHAR(64) NOT NULL DEFAULT '', ua VARCHAR(250) NOT NULL DEFAULT '', UNIQUE KEY uq_tok(token_hash), KEY k_user(user_id)) $T",
"CREATE TABLE IF NOT EXISTS entities(seq BIGINT AUTO_INCREMENT PRIMARY KEY, kind VARCHAR(16) NOT NULL, id VARCHAR(64) NOT NULL, data MEDIUMTEXT, updated_at INT NOT NULL DEFAULT 0, updated_by INT NOT NULL DEFAULT 0, UNIQUE KEY uq_ent(kind,id)) $T",
"CREATE TABLE IF NOT EXISTS changes(id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, kind VARCHAR(16) NOT NULL, entity_id VARCHAR(64) NOT NULL, op VARCHAR(8) NOT NULL, data MEDIUMTEXT, label VARCHAR(600) NOT NULL DEFAULT '', grp VARCHAR(90) NULL, status VARCHAR(10) NOT NULL DEFAULT 'pending', created_at INT NOT NULL DEFAULT 0, updated_at INT NOT NULL DEFAULT 0, decided_at INT NULL, decided_by INT NULL, seen TINYINT NOT NULL DEFAULT 0, KEY k_us(user_id,status), KEY k_st(status)) $T",
"CREATE TABLE IF NOT EXISTS activity(id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NULL, username VARCHAR(120) NOT NULL DEFAULT '', display_name VARCHAR(100) NOT NULL DEFAULT '', action VARCHAR(16) NOT NULL, entity VARCHAR(16) NOT NULL DEFAULT '', text VARCHAR(700) NOT NULL DEFAULT '', ip VARCHAR(64) NOT NULL DEFAULT '', created_at INT NOT NULL, KEY k_u(user_id), KEY k_fail(action,ip,created_at)) $T",
"CREATE TABLE IF NOT EXISTS meta(k VARCHAR(20) PRIMARY KEY, v VARCHAR(60) NOT NULL) $T",
];
try {
    foreach ($sql as $s) $pdo->exec($s);
    $n = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    if ($n === 0) {
        $st = $pdo->prepare("INSERT INTO users(username,pass_hash,first_name,last_name,role,active,require_approval,perms,created_at,updated_at) VALUES(?,?,?,?,'admin',1,0,'[]',?,?)");
        $st->execute([OWNER_USER, password_hash(OWNER_PASS, PASSWORD_DEFAULT), OWNER_FIRST, OWNER_LAST, time(), time()]);
        echo '<h3>✅ نصب انجام شد و حساب مدیر اصلی ساخته شد.</h3>';
    } else { echo '<h3>✅ جدول‌ها بررسی شد (کاربر از قبل وجود داشت).</h3>'; }
    echo '<p><b>مهم:</b> همین حالا فایل <code>install.php</code> را از هاست حذف کن و بعد از اولین ورود، رمز مدیر را عوض کن.</p>';
} catch (Exception $e) { echo '<h3>خطا در ساخت جدول‌ها</h3><pre dir="ltr">' . htmlspecialchars($e->getMessage()) . '</pre>'; }
