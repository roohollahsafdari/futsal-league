<?php
// اجرای یک‌باره: https://saigroup.ir/league/api/install.php?key=کلید-نصب
// بعد از نصب موفق، این فایل را از هاست حذف کن.
require __DIR__ . '/config.php';
header('Content-Type: text/html; charset=utf-8');
echo '<!DOCTYPE html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>نصب</title><body style="font-family:Tahoma,sans-serif;max-width:560px;margin:30px auto;line-height:2">';
if (!isset($_GET['key']) || !hash_equals(INSTALL_KEY, (string)$_GET['key'])) { http_response_code(403); echo '<h3>کلید نصب درست نیست.</h3><p>آدرس باید به این شکل باشد: install.php?key=کلید-داخل-config.php</p>'; exit; }
try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (Exception $e) { echo '<h3>اتصال به دیتابیس برقرار نشد.</h3><p>نام دیتابیس، کاربر و رمز را در config.php بررسی کن.</p>'; exit; }
require __DIR__ . '/schema.php';
try {
    schema_migrate($pdo);
    $n = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    if ($n === 0) {
        $st = $pdo->prepare("INSERT INTO users(username,pass_hash,first_name,last_name,role,level,active,require_approval,perms,created_at,updated_at) VALUES(?,?,?,?,'admin',1,1,0,'[]',?,?)");
        $st->execute([OWNER_USER, password_hash(OWNER_PASS, PASSWORD_DEFAULT), OWNER_FIRST, OWNER_LAST, time(), time()]);
        echo '<h3>✅ نصب انجام شد و حساب مدیر اصلی ساخته شد.</h3>';
    } else { echo '<h3>✅ جدول‌ها بررسی شد (کاربر از قبل وجود داشت).</h3>'; }
    echo '<p><b>مهم:</b> همین حالا فایل <code>install.php</code> را از هاست حذف کن و بعد از اولین ورود، رمز مدیر را عوض کن.</p>';
} catch (Exception $e) { echo '<h3>خطا در ساخت جدول‌ها</h3><pre dir="ltr">' . htmlspecialchars($e->getMessage()) . '</pre>'; }
